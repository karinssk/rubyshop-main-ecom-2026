<!DOCTYPE html>
<html lang="th">
<head>


  <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KNXZGMDN');</script>
<!-- End Google Tag Manager -->

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0PWGSWH0P4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-0PWGSWH0P4');
</script>







<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-NHBT4DYH7D"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-NHBT4DYH7D');
</script>











 <!-- Basic Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เครื่องพ่นปูนฉาบ RUBYSHOP รุ่น RB-M30L | ประหยัดแรง ประหยัดเวลา งานฉาบไว<</title>
    <script src="https://analytics.ahrefs.com/analytics.js" data-key="+yln8X9wf8523X4GDZmCqA" async></script>
    <!-- Preload critical assets -->
    <link rel="preload" href="https://res.cloudinary.com/dhcsqglul/image/upload/v1745228863/rb-m30l_ml6cqm.webp" as="image" fetchpriority="high">
    <link rel="preload" href="https://www.rubyshop.co.th/storage/logo/rubyshop-no-bg-250pxx100px.jpg" as="image">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" media="print" onload="this.media='all'">
    <noscript>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap">
    </noscript>
    
    <!-- Meta Tags -->
    <meta name="description" content="เครื่องพ่นปูนฉาบ RUBYSHOP รุ่น RB-M30L - ประหยัดแรง ประหยัดเวลา งานฉาบไว มืออาชีพต้องเลือก! เร็วกว่าแรงงานมือ 5 เท่า ใช้งานง่าย ไม่ต้องเติมปูนบ่อย กำลังมอเตอร์ 4000W ความจุถัง 30 ลิตร รับประกัน 1 ปี">
    <meta name="keywords" content="เครื่องพ่นปูนฉาบ, RUBYSHOP, RB-M30L, Cement Mortar Spraying Machine, เครื่องพ่นปูน, อุปกรณ์ก่อสร้าง, เครื่องมือช่าง, ผู้รับเหมา, ช่างก่อสร้าง, ปูนฉาบ, งานฉาบ">
    <meta name="author" content="Ruby Shop">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://www.rubyshop.co.th/promotion/rb-m30l-rubyshop">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="เครื่องพ่นปูนฉาบ RUBYSHOP รุ่น RB-M30L | ประหยัดแรง ประหยัดเวลา งานฉาบไว">
    <meta property="og:description" content="เครื่องพ่นปูนฉาบ RUBYSHOP รุ่น RB-M30L - ประหยัดแรง ประหยัดเวลา งานฉาบไว มืออาชีพต้องเลือก! เร็วกว่าแรงงานมือ 5 เท่า ใช้งานง่าย ไม่ต้องเติมปูนบ่อย กำลังมอเตอร์ 4000W ความจุถัง 30 ลิตร รับประกัน 1 ปี">
    <meta property="og:image" content="https://www.rubyshop.co.th/storage/ads/m30l-hero.webp"">
    <meta property="og:url" content="https://www.rubyshop.co.th/promotion/rb-m30l-rubyshop">
    <link rel="canonical" href="https://www.rubyshop.co.th/promotion/rb-m30l-rubyshop">
    <meta property="og:site_name" content="RUBYSHOP">
    






         
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="เครื่องพ่นปูนฉาบ RUBYSHOP รุ่น RB-M30L | ประหยัดแรง ประหยัดเวลา งานฉาบไว">
    <meta name="twitter:description" content="เครื่องพ่นปูนฉาบ RUBYSHOP รุ่น RB-M30L - ประหยัดแรง ประหยัดเวลา งานฉาบไว มืออาชีพต้องเลือก! เร็วกว่าแรงงานมือ 5 เท่า ใช้งานง่าย ไม่ต้องเติมปูนบ่อย กำลังมอเตอร์ 4000W ความจุถัง 30 ลิตร รับประกัน 1 ปี">
    <meta name="twitter:image" content="https://res.cloudinary.com/dhcsqglul/image/upload/v1745201666/%E0%B8%9E%E0%B9%88%E0%B8%99%E0%B8%9B%E0%B8%B9%E0%B8%99_RB-M30L_1280px_ixjdfh.jpg">
    <meta name="twitter:site" content="@RUBYSHOP168">
   











<!-- Language and Direction -->
<meta http-equiv="content-language" content="th-TH">
<meta name="language" content="Thai">

<!-- Theme Color for Browser UI -->
<meta name="theme-color" content="#ED1D24">

<!-- Favicon -->
<link rel="icon" type="image/png" href="https://www.rubyshop.co.th/storage/logo/icon-rubyshop-ico.png">

    
    
    
    
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">




    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'ruby': '#ed1d24',
                        'ruby-dark': '#CC0000',
                        'ruby-light': '#FF3355',
                    },
                    animation: {
                        'pulse-fast': 'pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                        'bounce-slow': 'bounce 2s infinite',
                    },
                    keyframes: {
                        wiggle: {
                            '0%, 100%': { transform: 'rotate(-3deg)' },
                            '50%': { transform: 'rotate(3deg)' },
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Prompt', sans-serif;
        }
        .text-shadow {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .glow {
            box-shadow: 0 0 15px rgba(255, 0, 34, 0.7);
        }
        .shake {
            animation: wiggle 1s ease-in-out infinite;
        }
        .gradient-text {
            background: linear-gradient(90deg, #FF0022, #FF6600);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .price-tag {
            position: relative;
            background: #FF0022;
            color: white;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 5px;
            transform: rotate(-5deg);
        }
        .price-tag:after {
            content: '';
            position: absolute;
            top: 0;
            right: -15px;
            width: 0;
            height: 0;
            border-top: 15px solid transparent;
            border-bottom: 15px solid transparent;
            border-left: 15px solid #FF0022;
        }
        .countdown-box {
            background: linear-gradient(135deg, #000000, #333333);
            border-radius: 8px;
            padding: 5px 10px;
            color: white;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        }
        .hero-gradient {
            background: linear-gradient(135deg, #000000 0%, #222222 100%);
        }
        .feature-card {
            transition: all 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .testimonial-card {
            transition: all 0.3s ease;
        }
        .testimonial-card:hover {
            transform: scale(1.03);
        }
        .cta-button {
            transition: all 0.2s ease;
        }
        .cta-button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(255, 0, 34, 0.8);
        }
        .ribbon {
            position: absolute;
            top: 0;
            right: 0;
            width: 150px;
            height: 150px;
            overflow: hidden;
        }
        .ribbon-content {
            position: absolute;
            top: 30px;
            right: -35px;
            transform: rotate(45deg);
            background: #FF0022;
            color: white;
            font-weight: bold;
            padding: 8px 50px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
        }

        html {
            scroll-behavior: smooth;
        }
    </style>
</head>
<body class="bg-gray-50">


    <!-- Sticky Header -->
    <div class="sticky top-0 z-50 bg-ruby text-white py-2 shadow-md relative">
        <div class="container mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center">
                <i class="fas fa-bolt text-ruby mr-2"></i>
                <span class="font-bold">โปรโมชั่นพิเศษ! ลด 10% เฉพาะวันนี้เท่านั้น</span>
            </div>
            <div class="flex items-center">
                <span class="mr-2">เหลือเวลา:</span>
                <div class="flex space-x-1">
                    <div id="hours" class="countdown-box">05</div>
                    <span>:</span>
                    <div id="minutes" class="countdown-box">00</div>
                    <span>:</span>
                    <div id="seconds" class="countdown-box">00</div>
                </div>
            </div>
        </div>
    </div>


     






    <!-- Header --><!-- Header -->
  <header class="fixed left-0 w-full bg-white shadow-md z-50 mb-10">
  <div class="container mx-auto px-4 py-4 flex justify-between items-center">
    <a href="/" class="logo">
      <img src="https://www.rubyshop.co.th/storage/logo/new-logo.png" alt="RUBYSHOP Logo" class="h-12">
    </a>
    
    <!-- Desktop navigation -->
    <nav class="hidden lg:block relative">
      <ul class="flex">
        <li class="ml-8"><a href="/" class="font-medium text-dark hover:text-primary relative after:absolute after:bottom-[-5px] after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">หน้าหลัก</a></li>
        <li class="ml-8"><a href="#features" class="font-medium text-dark hover:text-primary relative after:absolute after:bottom-[-5px] after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">คุณสมบัติเด่น</a></li>
        <li class="ml-8"><a href="#comparison-table" class="font-medium text-dark hover:text-primary relative after:absolute after:bottom-[-5px] after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">ตารางเปรียบเทียบ</a></li>
        <li class="ml-8"><a href="#video" class="font-medium text-dark hover:text-primary relative after:absolute after:bottom-[-5px] after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">วิดีโอสาธิต</a></li>
        <li class="ml-8"><a href="#contact" class="font-medium text-dark hover:text-primary relative after:absolute after:bottom-[-5px] after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">สั่งซื้อ</a></li>
      </ul>
    </nav>
    
    <!-- Hamburger button - Fixed the syntax issue here -->
    <button 
      id="mobile-menu-btn"
      class="flex flex-col lg:hidden cursor-pointer"
      aria-label="Toggle menu"
      aria-expanded="false"
    >
      <span class="w-7 h-0.5 bg-black my-0.5 transition-all duration-300"></span>
      <span class="w-7 h-0.5 bg-black my-0.5 transition-all duration-300"></span>
      <span class="w-7 h-0.5 bg-black my-0.5 transition-all duration-300"></span>
    </button>
  </div>
  
  <!-- Mobile sidebar menu -->
  <div id="mobile-menu" class="fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform -translate-x-full transition-transform duration-300 ease-in-out z-50 lg:hidden">
    <div class="p-4 border-b border-gray-200">
      <a href="/" class="logo block">
        <img src="https://www.rubyshop.co.th/storage/logo/new-logo.png" alt="RUBYSHOP Logo" class="h-12">
      </a>
      <button id="close-sidebar" class="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
    <ul class="py-4">
      <li class="py-2 border-b border-gray-100">
        <a href="/" class="block px-4 font-medium text-dark hover:text-primary">หน้าหลัก</a>
      </li>
      <li class="py-2 border-b border-gray-100">
        <a href="#features" class="block px-4 font-medium text-dark hover:text-primary">คุณสมบัติเด่น</a>
      </li>
      <li class="py-2 border-b border-gray-100">
        <a href="#video" class="block px-4 font-medium text-dark hover:text-primary">วิดีโอสาธิต</a>
      </li>
      <li class="py-2 border-b border-gray-100">
        <a href="#comparison-table" class="block px-4 font-medium text-dark hover:text-primary">ตารางเปรียบเทียบ</a>
      </li>
   
      <li class="py-2">
        <a href="#contact" class="block px-4 font-medium text-dark hover:text-primary">สั่งซื้อ</a>
      </li>
    </ul>
  </div>
  
  <!-- Overlay for mobile menu -->
  <div id="sidebar-overlay" class="hidden fixed inset-0 bg-black bg-opacity-50 opacity-0 pointer-events-none transition-opacity duration-300 ease-in-out z-40 lg:hidden"></div>
</header>

<!-- JavaScript for mobile menu functionality -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  const closeSidebarBtn = document.getElementById('close-sidebar');
  const sidebarOverlay = document.getElementById('sidebar-overlay');
  
  // Toggle mobile sidebar
  mobileMenuBtn.addEventListener('click', function() {
    // Show the menu
    mobileMenu.classList.toggle('-translate-x-full');
    
    // Show the overlay
    sidebarOverlay.classList.toggle('hidden');
    sidebarOverlay.classList.toggle('opacity-0');
    sidebarOverlay.classList.toggle('pointer-events-none');
    
    // Update aria-expanded attribute
    const isExpanded = !mobileMenu.classList.contains('-translate-x-full');
    mobileMenuBtn.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
    
    // Animate hamburger to X
    const spans = mobileMenuBtn.querySelectorAll('span');
    if (isExpanded) {
      // Transform to X
      spans[0].classList.add('rotate-45', 'translate-y-[0.3rem]');
      spans[1].classList.add('opacity-0');
      spans[2].classList.add('-rotate-45', '-translate-y-[0.3rem]');
    } else {
      // Reset to hamburger
      spans[0].classList.remove('rotate-45', 'translate-y-[0.3rem]');
      spans[1].classList.remove('opacity-0');
      spans[2].classList.remove('-rotate-45', '-translate-y-[0.3rem]');
    }
  });
  
  // Close sidebar when clicking the close button
  closeSidebarBtn.addEventListener('click', function() {
    closeSidebar();
  });
  
  // Close sidebar when clicking the overlay
  sidebarOverlay.addEventListener('click', function() {
    closeSidebar();
  });
  
  // Close sidebar when clicking on a link
  const mobileLinks = mobileMenu.querySelectorAll('a');
  mobileLinks.forEach(link => {
    link.addEventListener('click', function() {
      closeSidebar();
    });
  });
  
  function closeSidebar() {
    mobileMenu.classList.add('-translate-x-full');
    sidebarOverlay.classList.add('hidden', 'opacity-0', 'pointer-events-none');
    mobileMenuBtn.setAttribute('aria-expanded', 'false');
    
    // Reset hamburger icon
    const spans = mobileMenuBtn.querySelectorAll('span');
    spans[0].classList.remove('rotate-45', 'translate-y-[0.3rem]');
    spans[1].classList.remove('opacity-0');
    spans[2].classList.remove('-rotate-45', '-translate-y-[0.3rem]');
  }
  
  // Handle smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        // Get the height of the navbar
        const navbarHeight = document.querySelector('header').offsetHeight;
        
        // Calculate the position to scroll to (element position - navbar height)
        const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navbarHeight;
        
        // Smooth scroll to the target
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });
});
</script>

   






<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KNXZGMDN"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->





















   <!-- Hero Section -->
   <section class="hero-gradient text-white py-16 relative overflow-hidden relative">
        <div class="absolute inset-0 bg-black opacity-60"></div>
        <div class="container mx-auto px-4 relative z-10">
            <div class="flex flex-col md:flex-row items-center">
                <div class="md:w-1/2 mb-10 md:mb-10">
                    <div class="inline-block bg-ruby px-4 py-1 rounded-full mb-4 animate-pulse-fast mt-10">
                        <span class="text-sm font-bold">เหลือเพียง <span id="remaining-count" class="text-yellow-300">2</span> เครื่องสุดท้าย!</span>
                    </div>
                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 leading-tight text-shadow">
                    เครื่องพ่นปูนฉาบ <span class="text-ruby">RUBYSHOP</span> <br>
                        <span class="">ประสิทธิภาพเหนือระดับ</span>
                    </h1>
                    <p class="text-xl mb-8 text-gray-200">
                    เครื่องพ่นปูนแบบไฟฟ้ารุ่นใหม่ที่ทรงพลัง ช่วยให้งานก่อสร้างรวดเร็วขึ้นกว่า 5 เท่า <br>
                        <span class="font-bold text-yellow-300">รับประกัน 1 ปีเต็ม พร้อมของแถมมูลค่า 3,500 บาท!</span>
                    </p>
                    <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                        <a href="#contact" class="cta-button bg-ruby hover:bg-ruby-dark text-white font-bold py-4 px-8 rounded-lg text-xl text-center glow shake">
                            สั่งซื้อเลย 10% OFF
                        </a>
                        <a href="#features" class="bg-white text-gray-800 font-bold py-4 px-8 rounded-lg text-xl text-center hover:bg-gray-100 transition">
                            ดูรายละเอียด
                        </a>
                    </div>
                    <div class="mt-6 flex items-center hidden">
                        <div class="flex text-yellow-400">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <span class="ml-2">4.9/5 จาก 358 รีวิว</span>
                    </div>
                </div>
                <div class="md:w-1/2 relative mt-4">
                    <div class="relative">
                        <img src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745228863/rb-m30l_ml6cqm.webp" 
                        alt="เครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" class="rounded-lg shadow-2xl">
                        <div class="ribbon">
                            <div class="ribbon-content">ลด 10%</div>
                        </div>
                        <div class="absolute -bottom-5 -left-5 price-tag text-2xl">
                            <span class="line-through text-gray-300 text-lg">฿99,000</span>
                            <span>฿89,000</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
















   
   




















<!-- Features Section -->
<section id="features" class="py-20 bg-gradient-to-b from-gray-50 to-gray-100">
    <div class="container mx-auto px-4">
        <div class="text-center mb-16">
            <span class="inline-block  bg-opacity-10 text-ruby px-4 py-2 rounded-full text-sm font-bold mb-4">คุณสมบัติเด่น</span>
            <h2 class="text-4xl md:text-5xl font-bold mb-6">ทำไมต้องเลือก <span class="text-ruby">เครื่องพ่นปูนฉาบ</span> รุ่น RB-M30L</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">เครื่องพ่นปูนฉาบคุณภาพสูง ที่ช่างมืออาชีพทั่วประเทศไว้วางใจ</p>
        </div>

        <!-- Main Features Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div class="feature-card group bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
                <div class="h-3 bg-ruby"></div>
                <div class="p-8">
                    <div class="w-20 h-20  bg-opacity-10 rounded-full flex items-center justify-center mb-6 group-hover:bg-ruby group-hover:text-white transition-all duration-300">
                        <i class="fas fa-bolt text-ruby text-3xl group-hover:text-white"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">เร็วกว่าแรงงานมือ 5 เท่า</h3>
                    <p class="text-gray-600">ทำงานได้รวดเร็ว ประหยัดเวลา ลดต้นทุนค่าแรงงาน เสร็จงานเร็วกว่ากำหนด</p>
                    <div class="mt-6 pt-6 border-t border-gray-100">
                        <div class="flex items-center">
                            <div class="w-12 h-2 bg-ruby rounded-full"></div>
                            <div class="w-8 h-2 bg-ruby rounded-full "></div>
                            <div class="w-4 h-2 bg-gray-200 rounded-full ml-1"></div>
                        </div>
                        <p class="text-sm text-gray-500 mt-2">เร็วกว่าแรงงานมือ 5 เท่า</p>
                    </div>
                </div>
            </div>

            <div class="feature-card group bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
                <div class="h-3 bg-ruby"></div>
                <div class="p-8">
                    <div class="w-20 h-20 bg-opacity-10 rounded-full flex items-center justify-center mb-6 group-hover:bg-ruby group-hover:text-white transition-all duration-300">
                        <i class="fas fa-tachometer-alt text-ruby text-3xl group-hover:text-white"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">ใช้งานง่าย ไม่ต้องมีทักษะสูง</h3>
                    <p class="text-gray-600">ควบคุมง่าย ปรับแต่งได้ตามต้องการ แม้ช่างมือใหม่ก็ใช้งานได้อย่างมีประสิทธิภาพ</p>
                    <div class="mt-6 pt-6 border-t border-gray-100">
                        <div class="flex items-center">
                            <div class="w-12 h-2 bg-ruby rounded-full"></div>
                            <div class="w-12 h-2 bg-ruby rounded-full ml-1"></div>
                            <div class="w-4 h-2 bg-gray-200 rounded-full ml-1"></div>
                        </div>
                        <p class="text-sm text-gray-500 mt-2">ใช้งานง่าย ไม่ยุ่งยาก</p>
                    </div>
                </div>
            </div>

            <div class="feature-card group bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl">
                <div class="h-3 bg-ruby"></div>
                <div class="p-8">
                    <div class="w-20 h-20  bg-opacity-10 rounded-full flex items-center justify-center mb-6 group-hover:bg-ruby group-hover:text-white transition-all duration-300  hover:text-white">
                        <i class="fas fa-money-bill-wave text-ruby text-3xl group-hover:text-white"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">ประหยัดวัสดุ คุ้มค่าระยะยาว</h3>
                    <p class="text-gray-600">ลดการสูญเสียวัสดุ ควบคุมปริมาณการใช้ปูนได้แม่นยำ คืนทุนเร็วกว่าที่คิด</p>
                    <div class="mt-6 pt-6 border-t border-gray-100">
                        <div class="flex items-center">
                            <div class="w-12 h-2 bg-ruby rounded-full"></div>
                            <div class="w-12 h-2 bg-ruby rounded-full ml-1"></div>
                            <div class="w-12 h-2 bg-ruby rounded-full ml-1"></div>
                        </div>
                        <p class="text-sm text-gray-500 mt-2">ประหยัดคุ้มค่า</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Video and Specs -->
        <div class="grid grid-cols-1 lg:grid-cols-5 gap-8" id="video">
            <!-- Video Section - Takes 3/5 of the width on large screens -->
            <div class="lg:col-span-3 bg-white rounded-xl shadow-lg overflow-hidden">
                <div class="relative" style="padding-top: 56.25%;">
                    <!-- 16:9 Aspect Ratio (9/16 = 0.5625 or 56.25%) -->
                    <iframe 
                        src="https://www.youtube.com/embed/uHx5D2FPD5o"
                        title="เครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                        frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                        allowfullscreen
                        class="absolute top-0 left-0 w-full h-full"
                    ></iframe>
                </div>
                <div class="p-8">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-ruby bg-opacity-10 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-play text-ruby"></i>
                        </div>
                        <div>
                            <h3 class="text-2xl font-bold">ดูวิดีโอสาธิตการใช้งาน</h3>
                            <p class="text-gray-600">เห็นประสิทธิภาพจริงก่อนตัดสินใจซื้อ</p>
                        </div>
                    </div>
                    <div class="flex flex-wrap gap-3 mt-4">
                        <span class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">#พ่นปูนฉาบ</span>
                        <span class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">#งานก่อสร้าง</span>
                        <span class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">#ช่างมืออาชีพ</span>
                    </div>
                </div>
            </div>

         <!-- Specs Section - Takes 2/5 of the width on large screens -->
<div class="lg:col-span-2">
    <div class="bg-white rounded-xl shadow-lg overflow-hidden h-full">
        <!-- Header with gradient background -->
        <div class="bg-gradient-to-r from-ruby to-red-700 p-6 text-white" id="specs">
            <div class="flex items-center">
                <div class="w-12 h-12 bg-white bg-opacity-20 backdrop-blur-sm rounded-full flex items-center justify-center mr-4">
                    <i class="fa fa-clipboard-list text-white text-xl"></i>
                </div>
                <div>
                    <h3 class="text-2xl font-bold">ข้อมูลจำเพาะ</h3>
                    <p class="text-white text-opacity-80 text-sm">สเปคครื่องพ่นปูนฉาบ รุ่น RB-M30L</p>
                </div>
            </div>
        </div>
        
        <!-- Specs content -->
        <div class="p-6">
            <!-- Model -->
            <!-- <div class="mb-6 pb-6 border-b border-gray-100">
                <div class="flex">
                    <div class="w-10 h-10  bg-opacity-0 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                        <i class="fa fa-tag text-ruby"></i>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">รุ่น</span>
                        <h4 class="font-bold text-lg">RB-WE02</h4>
                        <div class="flex items-center mt-1">
                            <span class="bg-ruby text-white text-xs px-2 py-0.5 rounded-full">ใหม่ล่าสุด 2025</span>
                        </div>
                    </div>
                </div>
            </div> -->
            
            <!-- Power -->
            <div class="mb-6 pb-6 border-b border-gray-100">
                <div class="flex">
                    <div class="w-10 h-10  bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                        <i class="fa fa-bolt text-ruby"></i>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">ใช้ไฟ 1 เฟส</span>
                        <h4 class="font-bold text-lg">220V</h4>
                        <div class="flex items-center mt-1">
                            <div class="w-24 h-2 bg-gray-200 rounded-full">
                                <div class="h-2 bg-ruby rounded-full" style="width: 100%"></div>
                            </div>
                            <span class="text-xs text-gray-500 ml-2">ใช้ได้ทุหน้างาน</span>
                        </div>
                    </div>
                </div>
            </div>
            



             <!-- Power -->
             <div class="mb-6 pb-6 border-b border-gray-100">
                <div class="flex">
                    <div class="w-10 h-10  bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                        <i class="fa fa-bolt text-ruby"></i>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">กำลังมอเตอร์ 5.5 แรงม้า</span>
                        <h4 class="font-bold text-lg">4000W</h4>
                        <div class="flex items-center mt-1">
                            <div class="w-24 h-2 bg-gray-200 rounded-full">
                                <div class="h-2 bg-ruby rounded-full" style="width: 90%"></div>
                            </div>
                            <span class="text-xs text-gray-500 ml-2">ตอบโจทย์ไซต์งานขนาดเล็ก-กลาง</span>
                        </div>
                    </div>
                </div>
            </div>








            <!-- Flow Rate -->
            <div class="mb-6 pb-6 border-b border-gray-100">
                <div class="flex">
                    <div class="w-10 h-10  bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                        <i class="fa fa-tachometer-alt text-ruby"></i>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">ปั้มลม 3 HP </span>
                        <h4 class="font-bold text-lg">2000W</h4>
                        <div class="flex items-center mt-1">
                            <div class="w-24 h-2 bg-gray-200 rounded-full">
                                <div class="h-2 bg-ruby rounded-full" style="width: 95%"></div>
                            </div>
                            <span class="text-xs text-gray-500 ml-2">ช่วยให้พปูนแห้งไวกว่าการขึ้นปูนด้วยมือ</span>
                        </div>
                    </div>
                </div>
            </div>
            
          

            <!-- Flow Rate -->
            <div class="mb-6 pb-6 border-b border-gray-100">
                <div class="flex">
                    <div class="w-10 h-10  bg-opacity-10 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                        <i class="fa fa-area-chart text-ruby"></i>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">พื้นที่การทำงานต่อวัน</span>
                        <h4 class="font-bold text-lg"> 600-800 ต.รม./วัน</h4>
                        <div class="flex items-center mt-1">
                            <div class="w-24 h-2 bg-gray-200 rounded-full">
                                <div class="h-2 bg-ruby rounded-full" style="width: 95%"></div>
                            </div>
                            <span class="text-xs text-gray-500 ml-2">ประหยัดแรง ประหยัดเวลา</span>
                        </div>
                    </div>
                </div>
            </div>
            
            
        
        <!-- Footer with CTA -->
        <div class="bg-gray-50 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-gray-500 text-sm">ต้องการข้อมูลเพิ่มเติม?</span>
                    <h4 class="font-bold">ดาวน์โหลดคู่มือฟรี</h4>
                </div>
                <a href="https://drive.google.com/uc?export=download&id=1zO0QOeXPug23FfAv0-h5AehhLpLvCGID" 
                class="inline-flex items-center bg-ruby hover:bg-ruby-dark text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 transform hover:-translate-y-1"
                target="_blank" 
                rel="noopener noreferrer">
                <i class="fa fa-file-pdf mr-2"></i>
                <span>ดาวน์โหลด PDF</span>
              </a>

            </div>
        </div>
    </div>
</div>

        </div>
    </div>
</section>



















<!-- Before/After Results Section -->
<section class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <span class="inline-block bg-ruby/10 text-ruby px-4 py-1 rounded-full text-sm font-medium mb-4">
                    ผลลัพธ์ที่ได้
                </span>
                <h2 class="text-3xl md:text-4xl font-bold mb-6">ก่อนและหลังการใช้งาน</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    ดูความแตกต่างของผนังก่อนและหลังการใช้เครื่องพ่นปูนฉาบ รุ่น RB-M30L
                </p>
            </div>
            
            <div class="grid md:grid-cols-2 gap-8">
                <div class="bg-gray-100 rounded-xl overflow-hidden shadow-lg">
                    <div class="relative">
                        <img src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745216460/bfefore_after_brightness_30l_tgame7.webp" 
                        alt="ก่อนใช้งาน เครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L"
                         class="w-full"
                         loading="lazy"
                         >
                        <div class="absolute top-4 left-4 bg-gray-800 text-white px-3 py-1 rounded-lg text-sm font-medium">
                            ก่อน
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-2">ผนังอิฐแดงก่อนพ่นปูน</h3>
                        <p class="text-gray-600">
                            หลังก่อสร้างอิฐแดงด้วยมือ และเตรียมรอพ่นปูนฉาบ
                        </p>
                    </div>
                </div>
                
                <div class="bg-gray-100 rounded-xl overflow-hidden shadow-lg">
                    <div class="relative">
                        <img src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745216333/30l_after_m2kixb.webp" alt="หลังใช้งาน เครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" class="w-full" loading="lazy">
                        <div class="absolute top-4 left-4 bg-ruby text-white px-3 py-1 rounded-lg text-sm font-medium">
                            หลัง
                        </div>
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-2">ภาพจากการพ่นปูนฉาบ</h3>
                        <p class="text-gray-600">
                            หลังพ่นปูนเสร็จแล้ว สามารถใช้เกรียงฉาปต่อได้เลย
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="mt-12 text-center">
                <div class="inline-block bg-gray-100 rounded-lg p-4 max-w-2xl">
                    <p class="text-gray-700 italic">
                        "ผลลัพธ์อาจแตกต่างกันไปตามสภาพผนังและทักษะของผู้ใช้งาน แต่เครื่องพ่นปูนฉาบ รุ่น RB-M30L ช่วยให้งานพ่นปูนฉาบง่ายขึ้นและมีประสิทธิภาพมากขึ้นอย่างแน่นอน"
                    </p>
                </div>
            </div>
        </div>
    </section>



















    <!-- Comparison Table -->
    <section class="py-16 bg-white" id="comparison-table">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold mb-4">เปรียบเทียบให้เห็นชัด</h2>
                <p class="text-xl text-gray-600 max-w-3xl mx-auto">เครื่องพ่นปูนฉาบ รุ่น RB-M30L ถึงเหนือกว่าคู่แข่งในท้องตลาด</p>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full border-collapse">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="p-4 text-left border">คุณสมบัติ</th>
                            <th class="p-4 text-center border bg-ruby text-white">RUBYSHOP รุ่น RB-M30L</th>
                            <th class="p-4 text-center border">แบรนด์อื่นๆในตลาด</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="p-4 border font-medium">กำลังมอเตอร์</td>
                            <td class="p-4 border text-center font-bold text-green-500">4000W (แรงม้า 5.5HP)</td>
                            <td class="p-4 border text-center">2000–3000W</td>
                        
                        </tr>
                        <tr>
                            <td class="p-4 border font-medium">แรงดันสูงสุด</td>
                            <td class="p-4 border text-center font-bold text-green-500">3000 PSI</td>
                            <td class="p-4 border text-center">1500-2500 PSI</td>
                        
                        </tr>
                        <tr>
                            <td class="p-4 border font-medium">ความจุถัง</td>
                            <td class="p-4 border text-center font-bold text-green-500"></i>30 ลิตร</td>
                            <td class="p-4 border text-center ">10–20 ลิตร</td>
                        </tr>
                        <tr>
                            <td class="p-4 border font-medium">ความเร็วในการพ่น</td>
                            <td class="p-4 border text-center font-bold text-green-500">เร็วกว่าการฉาบมือ 5 เท่า</td>
                            <td class="p-4 border text-center">เร็วกว่ามือ 2–3 เท่า</td>
                        </tr>
                        <tr>
                            <td class="p-4 border font-medium">คุณภาพวัสดุ</td>
                            <td class="p-4 border text-center font-bold text-green-500">แข็งแรง ทนทาน ใช้ได้นาน</td>
                            <td class="p-4 border text-center">	วัสดุทั่วไป เสื่อมสภาพเร็ว</td>
                        </tr>
                  
                        <tr>
                            <td class="p-4 border font-medium">การดูแลรักษา</td>
                            <td class="p-4 border text-center font-bold text-green-500">ง่าย มีคู่มือ + บริการหลังการขาย</td>
                            <td class="p-4 border text-center">ซับซ้อน </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

















<!-- Before/After Results -->
<section class="py-16 bg-gray-900 text-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold mb-4">เหมาะกับงานพ่นปูนฉาบทั่วไป</h2>
                <p class="text-xl text-gray-300 max-w-3xl mx-auto">พ่นได้ทั้งผนัง พื้น ฯลฯ </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="bg-gray-800 rounded-xl overflow-hidden">
                    <div class="relative h-80">
                        <img src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745216333/30l_after_m2kixb.webp" 
                        alt="ก่อนใช้ เครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                        class="w-full h-full object-cover"
                        loading="lazy"
                        >
                     
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-2">ผนังอิฐแดง</h3>
                        <p class="text-gray-400">ผนังอิฐแดงที่ก่อบ้านทั่วไป หรือผนังอาคาร</p>
                    </div>
                </div>

                <div class="bg-gray-800 rounded-xl overflow-hidden">
                    <div class="relative h-80">
                        <img src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745219182/30l_i30hph.webp" 
                        alt="หลังใช้ เครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" class="w-full h-full object-cover"
                        loading="lazy"
                        >
                 
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold mb-2">ผนังอิฐบล็อก</h3>
                        <p class="text-gray-400">ผนังอิฐบล็อกที่ก่อบ้านทั่วไป หรือผนังอาคารทั่วไป</p>
                    </div>
                </div>
            </div>

            <div class="mt-12 text-center">
                <a href="#buy-now" class="inline-block bg-ruby hover:bg-ruby-dark text-white font-bold py-4 px-8 rounded-lg text-xl transition cta-button">
                    รับข้อเสนอพิเศษวันนี้
                </a>
            </div>
        </div>
    </section>

 




























<!-- Customer Gallery Section -->
<section class="py-20 bg-gray-50" id="customer-gallery">
    <div class="container mx-auto px-4">
        <!-- Section Header -->
        <div class="text-center mb-12">
            <span class="inline-block  bg-opacity-10 text-ruby px-4 py-2 rounded-full text-sm font-bold mb-4">ลูกค้าของเรา</span>
            <h2 class="text-4xl md:text-5xl font-bold mb-6">ลูกค้าที่ไว้วางใจเรา</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                ภาพส่งสินค้าถึงมือลูกค้า พร้อมสาธิตการใช้งาน และการดูแลหลังใช้งาน
            </p>
        </div>

        <!-- Customer Gallery -->
        <div class="relative">
            <!-- Main Gallery Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Gallery Item 1 - Large Feature -->
                <div class="lg:col-span-2 lg:row-span-2 rounded-2xl overflow-hidden shadow-lg transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group">
                    <div class="relative h-full">
                        <img 
                            src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745220971/rb-30l_delivered_to_customer_01_zjuxqj.png" 
                            alt="ลูกค้าrubyshop รับเครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                            class="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                            <div class="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                <div class="flex items-center mb-2">
                                    <div class="flex">
                                 
                                    </div>
                                    <span class="ml-2 text-white font-bold"></span>
                                </div>
                                <h3 class="text-white text-xl font-bold">ส่งถึงปทุมธานี</h3>
                                <p class="text-white text-opacity-80 mt-2">
                                "ส่งถึงที่พร้อมสาธิตการใช้งาน"
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gallery Item 2 -->
                <div class="rounded-2xl overflow-hidden shadow-lg transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group">
                    <div class="relative h-full">
                        <img 
                            src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745220974/rb-30l_delivered_to_customer_05_cexvej.png" 
                            alt="ลูกค้าrubyshop รับเครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                            class="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                            <div class="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                <div class="flex items-center mb-2">
                                    <div class="flex">
                                       
                                    </div>
                                    <span class="ml-2 text-white font-bold"></span>
                                </div>
                                <h3 class="text-white text-xl font-bold">นิคมอุตสาหกรรมบางปู</h3>
                                <p class="text-white text-opacity-80 mt-2">
                                    "ส่งถึงที่พร้อมสาธิตการใช้งาน"
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gallery Item 3 -->
                <div class="rounded-2xl overflow-hidden shadow-lg transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group">
                    <div class="relative h-full">
                        <img 
                            src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745220971/rb-30l_delivered_to_customer_02_zoeeod.png" 
                            alt="ลูกค้าrubyshop รับเครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                            class="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                            <div class="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                <div class="flex items-center mb-2">
                                    <div class="flex">
                              
                                    </div>
                                    <span class="ml-2 text-white font-bold"></span>
                                </div>
                                <h3 class="text-white text-xl font-bold">ลาดพร้าว - วังหิน</h3>
                                <p class="text-white text-opacity-80 mt-2">
                                "ส่งถึงที่พร้อมสาธิตการใช้งาน"
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gallery Item 4 -->
                <div class="rounded-2xl overflow-hidden shadow-lg transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group">
                    <div class="relative h-full">
                        <img 
                            src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745220970/rb-30l_delivered_to_customer_04_rf9x4k.png" 
                            alt="ลูกค้าrubyshop รับเครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                            class="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                            <div class="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                <div class="flex items-center mb-2">
                                    <div class="flex">
                                 
                                    </div>
                                    <span class="ml-2 text-white font-bold"></span>
                                </div>
                                <h3 class="text-white text-xl font-bold">จ.สุราษฎร์ธานี !!</h3>
                                <p class="text-white text-opacity-80 mt-2">
                                       "ส่งถึงที่พร้อมสาธิตการใช้งาน"
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gallery Item 5 -->
                <div class="rounded-2xl overflow-hidden shadow-lg transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group">
                    <div class="relative h-full">
                        <img 
                            src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745220972/rb-30l_delivered_to_customer_03_xq9cj3.png" 
                            alt="ลูกค้าrubyshop รับเครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                            class="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                            <div class="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                <div class="flex items-center mb-2">
                                    <div class="flex">
                          
                                    </div>
                                    <span class="ml-2 text-white font-bold"></span>
                                </div>
                                <h3 class="text-white text-xl font-bold">ไซต์งานคุยแบบโหน่ง ถกก่อนสร้าง</h3>
                                <p class="text-white text-opacity-80 mt-2">
                                         "ส่งถึงที่พร้อมสาธิตการใช้งาน"
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
           
           
           
           
              <!-- Gallery Item 5 -->
              <div class="rounded-2xl overflow-hidden shadow-lg transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl group">
                    <div class="relative h-full">
                        <img 
                            src="https://res.cloudinary.com/dhcsqglul/image/upload/v1745222006/%E0%B8%AA%E0%B9%88%E0%B8%87%E0%B9%80%E0%B8%84%E0%B8%A3%E0%B8%B7%E0%B9%88%E0%B8%AD%E0%B8%87%E0%B8%9E%E0%B9%88%E0%B8%99%E0%B8%9B%E0%B8%B9%E0%B8%99%E0%B8%9A%E0%B8%B2%E0%B8%87%E0%B8%9B%E0%B8%B9_nce66j.webp" 
                            alt="ลูกค้าrubyshop รับเครื่องพ่นปูนฉาบ Cement Mortar Spraying Machine รุ่น RB-M30L" 
                            class="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                            loading="lazy"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                            <div class="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                <div class="flex items-center mb-2">
                                    <div class="flex">
                                    
                                    </div>
                                    <span class="ml-2 text-white font-bold"></span>
                                </div>
                                <h3 class="text-white text-xl font-bold">คุณทองดี จ.สมุทรปราการ</h3>
                                <p class="text-white text-opacity-80 mt-2">
                                "ส่งถึงที่พร้อมสาธิตการใช้งาน"  </p>
                            </div>
                        </div>
                    </div>
                </div>
           
           
           
           
           
           
           
           
           
           
            </div>

            <!-- Decorative Elements -->
            <div class="absolute -top-6 -left-6 w-12 h-12 bg-ruby rounded-full opacity-20 animate-pulse"></div>
            <div class="absolute -bottom-6 -right-6 w-20 h-20 bg-ruby rounded-full opacity-10 animate-pulse"></div>
        </div>

        <!-- Testimonial Stats -->
        <div class="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="text-4xl font-bold text-ruby mb-2">100+</div>
                <p class="text-gray-600">ส่งสินค้าถึงที่</p>
            </div>
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="text-4xl font-bold text-ruby mb-2">5.0</div>
                <p class="text-gray-600">คะแนนความพึงพอใจ</p>
            </div>
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="text-4xl font-bold text-ruby mb-2">98%</div>
                <p class="text-gray-600">กลับมาซื้อซ้ำ</p>
            </div>
            <div class="bg-white rounded-xl shadow-md p-6">
                <div class="text-4xl font-bold text-ruby mb-2">100%</div>
                <p class="text-gray-600">บริการหลังการขาย</p>
            </div>
        </div>

        <!-- Call to Action -->
                <!-- Call to Action -->
                <div class="mt-16 bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="grid grid-cols-1 md:grid-cols-2">
                <!-- CTA Text Content -->
                <div class="p-8 md:p-12 flex flex-col justify-center">
                    <h3 class="text-3xl font-bold mb-4">มาเป็นลูกค้าคนต่อไปของเรา</h3>
                    <p class="text-gray-600 mb-6">
                        คุณสามารถเลือกรับสินค้าด้วยตัวเองที่บริษัทของเรา หรือให้เราจัดส่งถึงบ้านคุณทั่วประเทศ 
                        พร้อมรับคำแนะนำการใช้งานจากทีมงานมืออาชีพ
                    </p>
                    <div class="space-y-4">
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                <i class="fa fa-check text-green-500"></i>
                            </div>
                            <span>รับประกันความพึงพอใจ 100%</span>
                        </div>
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                <i class="fa fa-check text-green-500"></i>
                            </div>
                            <span>รับประกันสินค้า 1 ปีเต็ม</span>
                        </div>
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                                <i class="fa fa-check text-green-500"></i>
                            </div>
                            <span>บริการหลังการขาย</span>
                        </div>
                    </div>
                    <div class="mt-8 flex md:text-sm">
                        <a href="#contact" class="inline-block bg-ruby hover:bg-ruby-dark text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                            ติดต่อเราเพื่อสั่งซื้อ
                        </a>
                        <a href="https://page.line.me/rubyshop168?openQrModal=true" class="inline-block ml-4 bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg">
                            <i class="fab fa-line mr-2"></i> แอดไลน์
                        </a>
                    </div>
                </div>
                
                <!-- Map/Location -->
                <div class="bg-gray-100 p-8 md:p-12 flex flex-col justify-center">
                    <div class="mb-6">
                        <h4 class="text-xl font-bold mb-2">ที่ตั้งบริษัท</h4>
                        <p class="text-gray-600">
                        หมู่4 97/60 โกสุมรวมใจ ซ. 39 แขวงดอนเมือง ดอนเมือง กรุงเทพมหานคร 10210
                        </p>
                    </div>
                    
                    <!-- Embedded Map (placeholder) -->
                    <div class="rounded-xl overflow-hidden shadow-lg h-64 bg-gray-300 relative">
                        <!-- Replace with actual Google Maps embed code -->
                        <div class="absolute inset-0 flex items-center justify-center">
                            <span class="text-gray-500">แผนที่บริษัท</span>
                        </div>
                        
         
                       
                        <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3872.80701893128!2d100.57166327564245!3d13.91048028649819!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e28301fbf17fbd%3A0x806362f26ffe576f!2z4Lir4LiI4LiBLuC4o-C4ueC4muC4teC5ieC4iuC5iuC4reC4mw!5e0!3m2!1sth!2sth!4v1743670761226!5m2!1sth!2sth"  
                            width="100%" 
                            height="100%" 
                            style="border:0;" 
                            allowfullscreen="" 
                            loading="lazy">
                        </iframe>
                       
                    </div>
                    
                    <div class="mt-6 flex items-center">
                        <div class="w-10 h-10  bg-opacity-10 rounded-full flex items-center justify-center mr-4">
                            <i class="fa fa-clock text-ruby"></i>
                        </div>
                        <div>
                            <h5 class="font-bold">เวลาทำการ</h5>
                            <p class="text-gray-600">จันทร์ - เสาร์: 8:30 - 17:30 น.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
    </div>
</section>


































    <section id="testimonials" class="testimonials py-16 bg-gray-50 gradient-bg text-primary">
  <div class="container mx-auto px-4">
    <div class="text-center mb-12 " data-aos="fade-up">
      <h2 class="text-3xl sm:text-4xl font-bold text-primary leading-tight">
        ลูกค้าของเรา
      </h2>
      <div class="w-24 h-1 bg-red-500 mx-auto mt-4 rounded-full"></div>
      <p class="text-white-600 mt-4 max-w-2xl mx-auto">
        เราภูมิใจที่ได้ร่วมงานกับบริษัทชั้นนำมากมาย
      </p>
    </div>

    <div class="logo-carousel-container relative overflow-hidden">
      <div class="logo-carousel flex items-center space-x-8 py-4 animate-scroll">
        <!-- Original logos -->
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="https://upload.wikimedia.org/wikipedia/en/thumb/7/70/Siam_Cement_Group_Logo.svg/1200px-Siam_Cement_Group_Logo.svg.png" 
            alt="Siam Cement Group" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <!-- Additional logos with actual URLs -->
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="https://semcon.co.th/uploads/N64pktqNQ20250128165116.webp" 
            alt="Thai Semcon M&E Engineering" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            loading="lazy"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATcAAACiCAMAAAATIHpEAAAAw1BMVEX////Bhz3l5eX//v////39///Bhz7///rBiDu+hz/AhTj58ua3gC+8gC/LnmjAgTLSsoXj07ju4MrdxKPAgS3jz6/DhjzDhj65eiT9+/C/iDvBhjbBgzH17d26gDO+gSrAjUnt38np2r/bv5z59OvEllrXvJPAklPUtIzq1sDHmV/LoGvy8OrexqLQupnBfjLPqn3TrIG8eRbLpnLu5NS9ikLq2LfQqHz5+OXEj1Pgxp3r17rXtYvz7Nb159q7ll6+nW3U48PQAAAPAElEQVR4nO2biXbbthKGwRLgJsMUtVDiqn2JVddqLDd14+Te93+qOwNKFkhFajyO49xz8DdNZBIiwY8zg8EAZr8xo5frN2a4UWS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40WS40fQjuHF++CSY/eqr/X/o1dw46vCZ7fjFxsRbqD+XTpPPkvVqbkLAH6HQCcbWP6RTzVvwS09/8aTq1Fvotdz23bJt9fnDzet7dHoLftHa3ItQ+a/HDbvLW5N+txt1EnWkU25+VL90ub9fsBo4eYGb+7v7Bh1ir+AGb1J8WY9HoZQ92Ss3t53pn1f5m3BL/jiDxgVLnBQXoNr8TQIHo3MTXBQbmXmxDB9uFv6oF8q7zMvehFvx8G1sHIfvm+LSGO6WyVv0iMwNXnRfZtZArvqqY1/XI8uzHOdNuHWHxTdNyoaXNxm2zvupgNMf3qJHr/DT22Fspb0Zh865GH2LcWZZwfWP7V2l1Wj2zeNc8ORRXvJTts3v36JHJG7CBmvrDC3Lkv3nPgsxHwdOuAEjELtZ96gZvHAOltE9HrydRXAFHsGRW61lNC04XlxwW8ukhZj2rEfOmoMqtLM5a+dXrXP9hLdZlJmVwHutHRbc7dZ6OCeMuRRuwMYdB7GT/cmOwzwX89SzrvFDEi2GMgf15PCxn4A32Uy0uothiBrBsTmmZPPueJhDYMRDo9HHj8Oe9LdTjqeOD8JZ4lteWcDHWhjjKrzNRoOrM34KOaXgi8C5+8zquQi8FVHM5ChXPQyHTzs88lIIJD/lIpIemFtLcxHIoyKZXe9TpqUEc7QGwRZ/AJtxwTbY5xIP3i2x764NnXU38cCP07Dtuklrt/RDLwtXnVpKxpNFMEjz25MpHHy72Iaec44bvFz2KXCsbNuYMwAlOFU8xNiZuOxA/9yXTyoo3OBFboLUCa7RNg7H8L8N5CHqg+s+BtgtH4wNG6H3wcRiKp0guFduy/GPaIW+ZTnyAw7PMPjN4G1kcgnNjzdLLC+1gsVJAgvogbOTnbU3cPbH2ANbTeoBEO1Q4EvGDob/VL15MQMSN5YglWym9RjhsOlwc2gxy7FX7eO7tvHTTebIjqieQ5HYwGBijXbqCnCJqUzhx+XRsyAWjVOMpIVocmMujuDWeXvjbIPdlNPGwFFNbZIr5CYvjMYXReEm2A5fluzCu6odd8cVN3ih00OL2jdngXU1F0crZcsM3GWE0QsLBC6byTi1hp3nFhCKQny+vNuchgI3H8+c5QZxVqGJ299oAFdbIdRSBRCCaHnIpFdRqcsWy+tDtybILY8aXe7LuOSu9vq7QWVM+FkNpT54ZbZ4thAXyOLDBzesYXD/zo1FaPPQwj2N+vDCr/HWPoZBigjcOPoTPsu2cVNb7Bb7LlfcwqgRk/vSKrkeTbo9B+2tclwcdsG/nb3jooT7ADHKaoxB1T3+hZtgNyrGOnIimi0wDiA3z2En575PtPimuEHUt20V1557wyNedZl1sEUvaqRdipve0y54oVf5qbowm97BrCPv7q9nC+Dvpw48fNO4/42b4C0ZQAozSMOnb5wVlb051AIdKe9lxVAFna0LkUwb/ITg+5B/5Fb7al969YjShSHRGx1TV1HAkOqEW/UZ0EAqUf51NUjRUV8W32zIhWR/5QCd9LQmwt+DG3Q5VZFDfsJMS8t9uf1abnOM5UE1vECmNS+zMQyLaRyXrRf6qTvOymSZp5YnO6fP8A7cEEsbRznHK8dTvYjN94Peq7g5kOOp4QVzvr7MZywKrRTmdC/k1pEwN92NIA4Ep8Wkd+EG7riT3sBy4jjorfrzKvfiut2RubWkk2JuzNSMgC2CsGBJCUND1iglX+SG+VE7CyeMjwPPih9c0Qj/78INK9f3gRNXU6lSbip0Wrfp3CZy4HhxFcltXsDMDV7HJnPAtusT+EvccMh2ncx39xM+2Wk2eR9ucNuWzBzsduplThzK+4m+HPgKbrMQbGsUqc+cLUP4yEU/jy0vjGqXusQNR/moF8BEWChHzde/CDdVEVRDgwPPjRNIuZr+CD/lY7iidZXgpSBheQhgdgnTujLwnKBeE73opzDOb+IrSAuFmhZ4Y7eRNb8XN1y7GgaQooLBDQZoeUHvulAvmhG4iaowZLNpz4Ep7JpV3Ca9bKsCAEw0HU/OhW7TF7hBOtQqcdYBX8WJcgqJ9K8Q31CQkvpgBQPPSaukxPOuYBKpkrkXcpMtrFFg1ftvP4Dh9CHZ54TbfDQRmNpEOHzLSL/Yxfhmw0Q37GMj8UUGTpqtfxVumOG27nsZDKspmlsKtueFbVIeAtxw5dpmrcfAi3O/qFJCkYwGMBJCczEvq6xOm9dd5CbYGDwcS384okIYeWw46ntxA8NCQ5hcy7vUiqtIB2Oe3FZnX8wNPyfdNINAuWgdZmKRDJf7Wdy9mv/rlbSLfio6MsCuCKxoBVhi3f0a3HCawNVyzHIsA0gtHSf14tiTt2pXwku4YT3ETYqo7fcCKR8jXN2r8ufrTH5uFajWPxlO0Ptazfdy3tsOy9ui0mfImmN4AbVW7xffDh1gvNMuJQyCHsQ5zypbiugzt7r64Sk3Pw78cvjx47B82Mx27r5oDZcopJXJYSUZDDwL0uHvszeWwJxjtP/qKEsHXjD+ReLbQcqnklmZO1UeDCFOvIxbGmf96YfJrpi7KqNWJqUcLAw2T+1KTytIfYMqP9nf+JKfRr3s+gmkvnoNzuD1dvUW786tWgtKtjLwsVDm+ckL7c3ye4f8DWsEFRm4RLLK5JFTNIKRW0bfaW83wdWhNqVG1EEKjqrr/caF/ROohAoDXXdUGZzsqA1EZ+Lbt7hhnVyt3lR/78Gxzgj8sjI+eMoERtQg2+o9OMMNx2UZLOCFqm/DP2NIMoPH2nrY+9RD0Dt5vTDPYR6thlVVGz/PDeu92oHmfOH5coK1cznVjnzKIMKlx90e57nhVfNjmVOAw1fFeH4sFb4HN3iP7pzxeiWXi2Sg8t+wq2ywWrmJGsXtWwhntQNnubEkiH33mK+Jz9JxBqOp1uLb3LiaW/WOa/A2+6r6MmNaTfw9uNmQpP6nJRo3tKscy8r7quxbYKYa9hvclpk3rh04x02IKMz0+raAOapa0jjoLDdI3sLskzYhEwznqMGKi+MM+n3qb4wv1s19B4Ld4mt1Rh+UHyeK222jV+ussfPmvL1tMlnY2nog22aWk/nJscUzt5rARLeh7uFcLfZUjqp39x38FAasstVcBWddtVgjd0zN0seQNcmlnnCpQlrQrl2rKz3nsJ5Vu1whs4W+giPYVEWpyb4U/8ytuXIs4KuBr+1cEHgE7iK77BiS+X49yz/Zr/OdInJbjJ4aLiiq2jnMKKuOrDPPye71GjoMig+BrO9HA9aO1WudcIPZkezr+w9s4e7XHg9rPxU378RPObyctbYijqMBZH9esNC5icP66U/0U+jSTYz7FWrdheEeh9DZPvpORrE3GGsL+pDofR3FDbequBWsKT4OyzlG0sMBuKiKn767D6xcVNwaZWCb9e88+UVDXs1R4xQctVYh3Pvpz7M31E3m+fUdoPyzHMBjWPN9fuaO4zSA6fSxgS3WYXMj60z5aT2XR0Ujb8OEvpdGVDthILWpXsWeG+aL2pPbbCJ970G/FNYfdleAKNd2HwKthdrn8JPXs24yJ1zhzja1TQtXnoo0dgaBGhUqRWFqZW0sZXI108daoqdV+tXi1zYbWKmMnlcThSpNimSc3c2qOLlvrNaC0FFXLubGWMnlmPc4wbUrDr8OANeIMD++1wtOaHpJCvYW+En1PYGznGopU7YEaTsScR8XcEvjYPWlenqkt7MCy8uu+lqG1A69OOwgVtxTBW02cW+tpQIY8MKB5TkhPOehUqzCUXITptlSX7FAP/2C3AZyqTJIaO86ilu4mWMDZYXF9s5S3PSsHG6dBKmVprhnVU1L8O+J2q9T7fz5Sfu4BHMXcvUg83BdVM/UWl95XiDHHX3Tg9uWWerD8OoqO5pv5Wir7QjEF73N0gF6y19sX1dUBtxZ5b4VjN3ajghR7bBJrbvb/YIVV37qx6nTnrT+LopJ96YMvCo34UIPZWCFThA7uEERe4PfTsYq2/QGkJ24tjgdmN6Cm83/u+NudCNHw5un7u3yRvbycrTqu/qvuIE5TR97odzuksRNvnStYdrXd+66fHo9yvIgD4N82C6qTUPCLbqLYZ7lYShXE/e4fZi3lkPcWBpm2XARzdFsv+AW1zAPc9kbDrHg1JNwObUX1o+S5/vYbH5b5jGcybPhuN/Cm8z7/ihUl8uvuq2ftW8Q3uFcmXfR3fhy+HEo/fH9LW5qrm2KRGvZLRflcFjC//59P9H3kjDe37af9ef9fgSJtsej9x+OTu3+obW+X0NYKpaHH5+e2g2tP3W1eZb+1e32K1xsrR9p/07Yk0SuhzAV55ibtEA4tPLTXbLCBRd150UBLThrrJmLunNw93BJrcXxx8Y2NbgZv/Qrm/q9Gg3VKFY74hJ++41WD9n3gO+fHZdVwJZOHsTW4ECTxsZmbYkf901XV+LH7RI20/cPCz1iif1Io9ZzKmks1AntRvq+QY55ZGOqQ9k5+Dp7A1QYZO3q31Nrr9Ygqta2XU+V7MYP1c/2kX7N6/Gw5npcHO63T3Kac3stxbXrFS/R3HbPX25tr+NW+xXHM7F1f/hbVPXe8sMl9TJL0z4bH787KGm35qfXpSW+5vfraTLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaDLcaPrtfyuu8pe9yN0EAAAAAElFTkSuQmCC" 
            alt="Supalai" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYsAAACACAMAAADNjrXOAAAAllBMVEX///8AXqwAVqkAUacAW6udtNXS4O8AWqr3+/0AV6kAVKjr8/kda7I9eLjD1+nz+fx7m8hVhb5JhsC90eUAT6YqcLWfuNjX5fGSstbp7vVMgLwYaLE4fLsATKXe6vQAYa6zzOSBocyfvtyrxd9ZjsQAR6N/p9BsmMiuxt9nlMaaudmJrtRLhb9zn8zL2us5crUAQaGTrdGb3IvwAAAO8ElEQVR4nO2de2OyLhvHFbhD0HL91FlZ2sp1Pux+/2/uAcRDLQ3buren+P6zmkDAB66Lk2oYWlpaWlpaWlpaWlpa1xTPXnZBAnyQBKPl31n80/l5WvWWkU8JRiYXwgRQP1qu3J/O1vPJ3QSQZBgqQoTS0cr66cw9lewFppX+QCnI+4dpYhh4P52/J9LKBBkIYDq7/evKmw8WqYOBxIFg9/DTWXwS2WsoKp3g4yAs/211BgHAed8Y/Fz+nkiHSHQKDNLw0zVvnPcNuNZe4+7qIVHb4HjZDE0dksGgOw3jzjpkKOinZm8Nh+JfdgokjOUPZO+ZFCcZisXZ/91NF/jjbK63lzDg6t/n74lkjYQFIunZ/3sBd+cksMW3dWamkHnfeZ/V2ewX21XWAFy7+DGbf7Rs2+IfbbsI74oL2WXXLiXDiiSLT0LxbLsYTIfFD4Yb9t2z89SEXEtGzFREH85Z2FVoXL4q4p/GPM0Kj77NFzLcshRlGhsqajkpCyiCLuVkA26y70H2lW7UKvU2xWPfn7xPfLzndTuKxhJGHESsqXhRNDcMx3GiqQw/ZF9GrhE6zpth/Bc5uUxjFUWyCw+ipHSDYUogF9pnKa+6VHxP3ljxrVRGD0ZrVuGbPL3R1sriYhGW9nl62/xqt5/nxoqcaMs/bMqcOMlwE0V8chaukYgORHRj7PDCcNlBJEeobpRZqNlJpXQCaZRMIE3XVHYM51sq/bLciJiLQzgdEZpy/CTIWSCyY1mA9NUwCMI4kBG2lH1mLCh4MYxdJOQkCH0YcwjneRhYsDiYhAbpvo8wEEkvfEyP6+UIEXqMhYVweBKAENIxBhQlIkEKuyyshwl1+svUARhMWVSAxM9hgH3ZPjd89YhjG/B4LBv8ejIcUMjC90xCzNF63aWE8lYSYISzfNkJ3Mo6lt3ixG/PCc6XQKiccFuyY/h3XCycQfIqPqRwcjDcIy5YmJizoIBdRqiLQZYpN8JdfGQsAHnJjBezL2GEWOXMKc1ZgIKFHWGy4EmGLAk2DFn5KOnxgsc7QkaMBUiFmeocEVkbAwDm4qsHfM+ICSIbbjtcRiGJGQsn5hfjNUZmVnkRSTHgbZrHcgcgOQgbtQV0agwjBPq86iwvQZD1ugAhHAlTaSdAssgcATkZIM1osRrFsii1zzoGvaP3/gtkJR+W+14tC7IYgV2WTxjNaMEikx2IdnqRxYDm5bQxfXeNCNFO9t1icHrGKHeaU4q6jAWrQ6EU/jHeAMnnunvCjAVjkWUuTsyJsO8e9JkJLOzGjCaxzABLZwtQVzb3DmWgWb8YO0D8q2QxEj0AVOfUW1guDCbF5G+WWS36p1X1ttIMomAV556Ms+jEIVPcq7IACw8SXofWkbKPpyyGAREm4yKLEaZ5r55vBnYI8S7/6Skl+5KFR3FaYbFjRiTJWz/7DRMfSxZ2goC4MiaB0fNzO3LCwjOOKM8PQ0sIY0HWBwrWRpVF/xOLQQWFWbo9aczA33b120Y2s8UUR8fRni/Tu0dkMt/AxOY/JywMh7cs5j/M4eqUxdCR1vsSC9ZlguowcErpa/7ZpXjEWPQF+8MYs+pjNmrDv3Y2hBn8CRoXEfs4sRmLgwi7x1C41A7kPjcqDMkJC5sZzmLstqKsSQSM+wbyei9ZpIIFeSt+aFOiwEmvzPk/6BeGvXfYOIW5ThiEgkWZlQqLNz72Y+UcwT3rSlUWQ2agsuq9yMLB46pbXFFQtFUrwV1uIzh8ALHJLgyAibggIZFh+2UfYnYdDRdEhCWQ4L38JzB4LQFpSc5YmH4xUPUoM42chbGkYFVhkbkBXLiFTokCdKurU7m/mN5c0ypyw+ngpQtM0hc2Ks4ccueMhYtZ5zhAFLOWU2GRGyhDsJCOrWThVvqF5bqsTsg2/11b9As5YiEEdV3OAohRqD9ilTpBQZFJ0S/kuhACphgz2wDvOoeDV7ikExauIxx2kbesXzA3RcyOW7CQpofm1JyiMdL0ZF43yi5MhsbddDjIWtuwAg7rfDcfZS9o5K7hmrvjkkUFBW/z0v5sCc0NbR+D3F+snSSOYVm/c+EvcBRy9EM2C5kzFmR76DEJ/+4glFdR5i8Iq2EeeIBF7W9Z+/F9n82PZbhT3z3GpRvYYeEvuG8aJiQIo5xFLPuADNnzCxSnayIyHOreWtEKCiZQzrgRGzbWsmD2dEjJG8Ihnz0ULOIAl7Okg4/X2SdmhPMWOSsabchmAgYfR0l2zJ4zYoxFVo8hYtVT+m6uLSB7+XFPWN0sSN7dAu4irARFAZeDZFWesuAzatkOppDnImNh9CjuFiykw0BygpEPZzEpTGmmReYu4Nm/v1WvPhJmcbjkw/1aFrxOlgSLwpQsmK8gi2GcyTCYrRd1NSW4cLquw9owrxEvQhNWkNXEzOYMhy5mRtEqWNgR63ynLGzEOuSQL5qsCQ9WstgR1j7nAE4tLtbZIlGVpyzYTyOHz2XsOUZ0WLBgRhaZBYteZvjk/NoT/QLR7tlGRii7hXPXVfPUB9g5HhMKI+a7A1qwwLRgASBnEfoEcNuxh4FkMZ9gnGTeFk1YYPY13W5HmJByLNhJAEmOx4CQiWjkiwkGkfgOR3aVhcM63ykLNmcHgMV1EAHcQZQsxJwiwGZeBgyEp5r5qMLCCBOACStbRAHlIyIHyvHzHmJYuK00gyGXYI8UY5p8WnWSbs2/80art2QjIeCkMz6mXfaXkoWd9llTWX18sEFc2heZW/TF0G/TX1pG5/19bXj9tBAfifS6vj+ZTOjJ9li8FutPk66cBXgjX3hnZ2Px+cq7tPWW8+4Yg8lkWs3bcI/YIA/65p67zP37hxxkLt8/Yu/jPa9P72Mi5nvTfpq51sX7B0/HXpg8Osx6prHsywjWMu0XxsaOsnrOZinWdtyffVqMXWcWyr//Nisb4Lh1fa/2yuULQ2828+yzf9qrzWZeWccZzmebeceSyVSHWYfB4Mw4uB4L23OLEEVYy6rkoEzFOA1p9Wabmde80N0x5RrsrCZALPeS/PMtDq1vVyeRPWP3ebub4RyYWKP4Zxp2qRw9pZ2zS51tdi7BJPieQyitUgNIJI0k/eMdwtiOw95qm0byhBT20ztO8rROFK8ncrcIA3FikP0tTtYS/1N/0bqn4j2l+NNxWn5Ija4v+RGte8parZMJLY/RIkyoj9ZTfSrqZzRc/d0lgE2SfJIE6WKu77/Q0tLS0tJ6WMUdbzp//fNF5SvBVkNKTavF89cG/SlW5uKv5lNRr/kg9MsVcynxSxUQ/t1Fvg8hpeCLmuRLwVZQm9akabm4CxtSfy8WD3qTL2dVRfSYs6gvzu2JJ59Kb20cH1yaJd6iYlvY6tamCJrOooybMgJLFqAh2PepOKFm1Bfn9sSj88J7Cf3Gn9EsWiR+zmLqf+uPaBYtEj9jEdLrcdpIs2iR+BkLeZPMt0mzaJH4KQvru4ukWbRI/JRFD16P0kqaRYvET1lMv9ldaBZtEtcs2kizqJVm0UaaRYvENYs20ixqpVm0kWbRInHNoo3uygKuW7JA7UQflcURK9eBYtJ0e1ryqyxI5dkYKipu/biZBWkopf9zLEbKFRGopYzOn3pwjQXYVB9fo6LitoYbWfznBPWKfo6FegVsVToGiT6dqvWurEeRwa2HDm9l4TapvDPmn7NQ1kIlZ3T0+ah57F+JBJzBbQfUb2WhqCYW2dMWhBpKVglV35Bbs7B3Kijg/kKy1tXtCwSS/S1Ho3+ORTQqFdWXq1uG6jaEasciDBT2gxC4/BSvflPTkSI47V2M3KQfY4H77MeljP9qi0e9MlSnNlRLFtNEoTqxWfPg5msOQ0YH47aP4f5RFoUaWRT6LhaDz48wv1D6oNbMjBRI8hLSYHB+T2mjmlgMrEYPXatKvfxCFtZSyWun9dUYqp6Mauk4GliYLecshSrP1/19LOyRktduvIF1qrzNighKlW/Wb2LRdjIvhbu/mMXBUfHanyZ4Z1oRNTMlCgq6io6jkcVtQr+YxUpl6YM4V2+bDIMWK4QYOBsVx/FcLLYqZy/pTqHirDfa4pgUosnb9VvPnomFld48wbugcO2rGyox47jmOJ6IRdz9wgTvknrjVgdrCelONYssK2oTvFbT5WkA21QfBtGm4aExT8NiBpQmeG1vKJ52YRtLhYC5qF04fBYWe5VxD0xvWO4+7GCrw84ErGuGac/Bwt0podg2JlIr5sXb0aDji0tdT8EiVprgfeE5tMM32mqjBtPowlPEnoGFBxRMOkm+9DQWdwBa3TeGKNieu/EnYLG5thHHBcbNT8VT0CxpNagywflbTh6fxVplIc//lldUTZ1W0z8TBidjqkdn4XZVDLn/Xe/h6Y1bDXHxyYOIH5xFaKpM8MA3PoO2k7Ya4sJ9GfWxWSjd/UucVrtvVxXv2wyqKjAemsV2opBd2r8U9Uuyt0hllp+pNFOPzCJV8drNO3i3ytpEqjQQyh34zft6DbF+Bws7ULAUX5ngXdEqUJnWMIHcSjWwINuGg6HuoNZD/Q4WHZVtUJLc8+GC3liRhszEzWdyXmtXeH4Fi7mK1waj+77f0zikWGFQlb/n6GYWf341i73KXPtfvIM4XF534/k7oh6ShdKyLAJ1D/n/Xg0XyZW+kb/D6BFZxCqnZVvu4H1F7tuV/Mi39D4gix5S8Jig+y8fCXzl1KccQTwei43SuZtPb7S/q9LnZLFUmeCh29+8M39pr/6V1vGYLNQ2U/G+I17pp6rq0uELJK11zWY+JotQ8Tg+bCO/eoP3NT98ix6URV2Ir6jyXlLNQrPQLPLUNQshzUJIs8hT1yyEnoJF9JBrIP+XLJBjaBaKujeLB10z/79kkb+hV7O4rjuzQFH+hmXN4qruzKI4/qBZXNd9WZR3fWgW13VPFqSy06tZXNfdWGBA15XtRc3iur6dBX9QB6EQjwYnG72axXWdsHh5b7X38XkzxAdmFIzXi1l4vs1rBX5drPfGjcg/tXnyg/IEmPdel/xkVElsPKlL7KPKojaUH+Qs6kJ8RSd7ScPOlxQOs+eSXVRYH6/xCYZ2w++VoVylUEZcH6xyHt+6nlhDkC9Iv1ddS0tLS0tLS0tLS0vrQfU/2b6sGcKAUugAAAAASUVORK5CYII=" 
            alt="Shimizu Corporation Thailand" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="https://www.cormix.com/wp-content/uploads/2021/06/Logo-Cormix-One-Step-Ahead-300x180.jpg" 
            alt="Cormix One Step Ahead" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARIAAACSCAMAAAC+LrV9AAAA9lBMVEX////NuVTtHCSnqazuKDC7rK/QvV3W1dX0cHXArVD5uLr4qq2bjEb1foJrbG66ubmUhkh5en3Ix8f6xsjj4+Ovnkvx8fGTiFzzYWeUhUO0trlyc3a8vsD8+/Sfj0a4pk6kn5OUjW+uq6b81Nbv6cmBg4aWmJuOkJOfoaTxU1mbloNjZGbj156Th1X3m5/69+zwRUzczojs5b/Uwmv28t/YyHjSwGXg05Tp4LPv6Mjz7tXbzYRTU1Xp6Ojm3KvXx3Z+cj6YkXiAdk/vNz6IgGFGRUfhz9D95ue2s6qinYzQz8yGeUCDeleuqZ2Sh1eIgm1+enGVkIMkWJ23AAASFUlEQVR4nO1ca3ubxrZGZW9RcqhAbIQLQkhWA6KSVTdObCdO5Nqu99m2nDon///PnDU3NDcuUtOnO3l4P7SCua6XNesyM45hdOjQoUOHDh06dOjQoUOHDh06dOjQoUOHDh06dOjQoUOHDh06tIWV+MWBTc/7HM7l0pcXfHH/9Sl5fSW+1uIS6r3SvayfQmWttnB98r8wDPGv0A326+C0x+NEKj0TSnuMkTf9XjPeQEWl3m+aKZwoTc/2k4FHkMVxDP8PE6DERS/MuMj36kIU+kosvNYzMrlowQj60i+Vt311Bmql3uQQMggSM078OHHdDdISN7aKJDb3o+RVzYQvpS880bWpQB/Rp37/3qk8gVNV45TluwdcRIlpWQGiJAgsN9mbEmFCr/iSiST5OWNEWk16vEU1Ndp0JU/gvVrn+lA+EBZAib+jxPeBkr3s7JUwF34NT87Feb5njLQyJK9xzSqqOFxr6rw5jAxsOQqkJUCDC//1E9PElOTIzm79dt2Iqs2t4dPXFYwYv7VghEj1VlMgGfArTZWLwxjJsvHCLUygxOR8DLASm2ZemNl4mLTqRxCcW8NvJJ3fLSmdnBWCn2tK3gvDaw31YS64yLJFvgBKTFcsCOBVkS+ybDho04+o2rs1fNWvmqXGGqog3E50RaIKaAxJr/fyIEqsMVCSF4UZKkV+QSgZtulH/OTlGn5X/d20Qkjon2p7IZhUDq+rsQcyTAkxGFcnJyfYak1O0K8gx5SYbboRBCw/oDxTbv3rxZRAvcqltpCznTrzKy+t9tgOgRJ/JxeaNbaIEE5tFkDJok0vomozXZCdAG8RJaOrQ58pvn6JvduNru9M9kltUYCWxJxcV9Qi4nAqQFqiLikV4jenk5U/rhAlTHgIIv3G3rKqOmcidFcR8SnBXDtYQ6CEk6tPLSINp3ygpE14IkqP205kY1H90cT0SImvdBFHj/NdFRHf6314oAhz8MCwMpjvvcTj4A9eBg85eBywsE32RHCB2E3IAVpdBlabHlXGLyzxq4r45MyzDYrVYDzMslJcJNfZW4ERyAeH48Hqw4f61SOaN6QOcoBWm5PWpUeyDikVKwyJhtoWGGJKSluB5cKz4zOUnFBSryaiar9RAzTOFmogfGYlvqrMhIit0LsjbarcDBNTUnqUUi4hZ3MxJatNbU/CIrlQA7R+bdAkmk+FvMp0GatBJWGv1IFawBwDJTEvFxZFTKnHQMnQqu1HdsFyzNGv1+HK9IigMsrFC7Sy9MDdI3c8HDPjiuV6+VrpLRsPsoZuxC/1Ug7QGhipTI8IKlxwj9jP6tTxQBdsAiW8XH0ygQv+S+XNlIiqLW/3XDSk6KptFqDZPaJ4X1eo24hsgwIWDi/XKzrIiVBnMNY05VGbwDUxUpUeMYg6xA91IW4tinHQgbtH8ZCjBA12xrJsTutMsCWLWltSrdpo3o0KrE+PGKQwTjDkQkTyXtSYg3aPtgPscXi5TtkPzlyb2AnXZTrV2ttrsaT16VEJSYcEl8t7+v6pYFYO2z1arBAlLPVHcpH1h0fdWcQCU/LvGj2pzeAaFVh0T4q3lnSoIriHhqI6HbZ7lCNKBgOfuJzJ6ekptaqnu5+h62eEkup+qqJL9vUapqFJjzg0+XeGE8nt1YaGlXA/ACV5GNZtJCZh6A8QJTVOR1RtZRU1fS8hzlW2OMSzmXcVOyNIv0W3t//uURgXsRGaxSAIww3eLYkLPmZ36TYbOvzLBpkZ+EVRleaIln6icFIflTS4YFmHtHuOWBUFt3fA7lERxwlK+rMNUILUJE9ic8cJOulCnOCTrsUqNMy48gxDnOR7NQ2rjxBE46CsMkWHtOeDZ7LbO2D3CERM/EVsonObjV+YZiJQgk+6CjO2ECWWicorT7peynNRfHJtaC14VWWLQ9Uh3ZYtWpt/2gVjSuhR1iawyFHWjhLf1Jx0VVByqcxFzk0vaha2qGPKFoeSYusS39eof0E3D3HBjBIrjl3Xt2SZrZxS4kJxUk+JoMn4MytnKjWbOQ27R3KKrd2LR0zV31uoR567RlggW+Kb7ngwzLJF5sYmPvA0UbAyDJGpRcVo8aBznMG4wOsKDGyyyCUr+0YzF+UIv9oRCx9d2eLQhHHq9YC3LaitgwkcDBcFOstLDAvvqi3yHLkYoKRYjLNsvMrQ4V/hguw+2o6GuCTfmuikKwMMJXf8VjcXWburHUD14boqKA7jlCiI9F2/MVeLBTm3McnJzQIoGaNnA5FCj7IGqBjvovjoeQBxCWKn0B/+nevmoiydqi2k6sN1VVAaa0g90xyqntpaxIQSGmSEOSgDew4oJWN4xOF7go62EgNWFa5Li8VsR1Ttci6yelftlot+QllfulhD8vGE7AZq64EpEXZSA6Y1IZZ5BY+IMAjk4Jk/KTYxJWKy865iLvLuYEWgIKRqSgCjjTWkzRnysoHaeuRAiRR0wQtkKixQGrRQcmRBQ3SboMjFcy0TiiW/c1kxl4m8+6p1xA1+Qiuo8JKx+Fr3siUC0BI50c9yfJkiMSHHA0qyIAT/gl1MvhB35pGWiPdN+lVzkbeJtalOg58QBGVrj7fnLKf8My7YQE5DuqoYUEp8f+sPQGZYOTgQyRElolKE+CIBlyeKqi1sBMhLRxdQ7nOAwwTlh2QLVev22qBYfViNuaMsCgsoyU1g4AOkxgNwKavVh6Fvmi4YHVmjTFJceh01utwJJC0d3VW6+gMcvaCnmhZClL+PCya7aJmS0foLdHUgxDtK4zE9ykKqFGdK+jskxczG1u1kyUtH9QP7uOCdoCWPryfKKy21NfiAKam8p4gpyVZY5n9Xne4VhBJ6+FO/kyVlaGqqs88Bzi7WKD9DqZSiy9/HBfsDJHPpVq9elsCdx7gYq8GK3q94gwqvuOpXATrpWrHlVL+TJS8dxezVH+AoKTbFK+VNA7W1nGTcuQ0/IuE7Q4d/xQBkNuklHPKdCSNUKmBsUKpQw06WnKJJ8ULDHYqqWIO+55KEemrrsdjtyPOfkH6+EIoH6MAz94kJmewIoyH6FXTBnXQ17WRJFyqkQLvhAEdNsQmIanLLsOrqYCuAljBTwn3g8v52gTbsM6CEPtPQ9F1ZvY837Mv7fI07WfLSEd1j/QGOLsXmRuW6aqC2HsMxu1M0ub6+xhp4eX1d6mSOlIg7A74seX9bfmYTFg6rb5n/hdiLkGK4GvPXrOhFLIZttkKULJD9JLWo6l6WX+yMnHStFuG3QckAe1mOEnIRi8EkPtog5zZIURgR5+UO8yk76SK3kv73n5VwEwy3usY/SY2kqYu6TuQaqMk+lHzAlHBhyUWPd+Ls8I9QguwFCk1Rnf4l/YFymJw76frlu0q8IJ3+VF3jezru91UVfmAze1FV41dWgw3zYh8+DBSK8WfAVAl2vi0n0Ws4KLUE+YtraiBf/UaN+YJoybdBSYzvpu0uRlz3hNw1yCDgh+AWxWIDFPWTa7AkVrx4w6w8DtVovPfVU2KgywJc9HreUwLK4RAFc9SjkDs4xPtenVFT7I/Hq3J7gFDy6/ca/KSM/TOu/C/l/fcSASpeSASo+BOUGNkux2F3oXnkOMeh4for7GyuiRsmD/iC407PfmkShsd/KyXFsNwuYd+dhw9x2HBMczpyBwdVOy8v5IRQvDPQ3wIlIWhJRt3wZU/NXcHDZhDOYQ+Lg8QJMsL9U/ZgFFA8lhbO101Jhs9tiEj9npJHI0bQuQ32SidEPSZ4E5w+WLh4wDZRvgFKTHKUhWPPyRlAzF2DwSAjR1mItCsoR6bm7CV9eAN5IT3pog2+pHn99QcRXA1KyT+kGtwQh1Pi0tO9iqsi4SqjMlf8IXlOi1nQ3OyEOTRQIoOrUeGEuSH+zMLBN8TzXPNnawbel15kKwTtxTRyzJNxdz6/BUqwZDk63dPoAf5bvtwwUbHmL2HxYeBC4PJLUvL7jyK4GmzhSDW+yMIhCBf40FdSlNDEp3sGO+mSOXPxmbD49j//0uDnwyj52+ISBExJHJsxJ18Q45sDOcr2cnysY8bc6gnRxQKgJGvxd9Q/foWUuDmmJPFd8sfjfuyaMb5fgs+AQ3bSlZik2HVjXIy0pMUftX2NlGBjkZnyxawiK/CBp48Yywv5YpYJuiUf/mnxNVKCT/GMbRHzlKBlVCzybGsEIPsiCAqTpwRdqEiguMWe1ddIiRGQCyOYEj9JfEQJzo8tk9yiwA/oCluwdRMXUYKpCE3JOf/yDw0O9Dg//48CVpdS8rtag43CKPlBrfKffZhBlPggJLrF57tKMaYkxv8CEKVEwV8Zl3y321Gp3C/57neJklYTqQGSGYvqWlayVYqD2LKwp95qGfsmKQlNfEUPBW+xzpNA7BLQH0qUQinRLRwCdSY/4vcqJT9U9sHMy4vKGsy8/LTPRDp0+HsQAP6WgTcwcJt/FOIwPBw96F4vj+r/IhjgOymgupp79Ifu9eORasFrsV1KY4RPMO5o2dxys9TK1gBrZI80Us1s22tqejS9uYnuKtVkM7KnGuEfbNvZb4ozey6+mNtPN95TC2mt6dFeI917GPZoKqRwd/htao8aJ76eTkfybDFuWc+24LJJz05vlLbT+UfSjReplIymdp2wPm3p1dZS8dGhOBZe39C3kVbrxSkfrR1dRnzPer7X9/zYboKfU9ZAUrattz5ybmtaJmwCTsuhKNwZ+Vg++r81ny3/IGsgcGfLx52kDzNYV3P0nWZIVcPZElUL/fnydkYaWNBgxi8+n/a8RRVwqbZnd7ZVmriPyzn7hx6geQgt2PNmhppu8MB4tPmczZA2sJL5DAF003qchS6xJGjU23krxVyPyESPp9bWmdqAEdKXmxH6OV0zGwH67xpOBL9SsC6hZ9vp1khS0gBM3MbDDUYfd4MeUet0a7tWRCoifbkjPT8x9p7t0YPYZOuhGilVgKV9l+JnwqJvw/QsOtN7GC2K6AzJEncd3H/Ptp+NP+AnmuKdYXzCb+2ozT+Ut05LSub2+tF1Hx00qJPezt35s+1REZPPYKMiRsnMvv8MCzR8Pp65/iydzsCEecu5+4eHhlcpcW1UOots4CTCPR9NHfrZ/dloLTQJnen93F06Nlmzy97UO4bnkROWlBh3aOC5Z3+E/jyBEstb387mx6Pp//lhOprfjp7cNfT0sIZRk+NR2iJcECiZoV8bBxTHIQMd28zJBTDxkpJH+7M7fWZdBKkDlBBbtJ6WtlSgBH/y0APnQ0W4tZnxClORkiUZM0hJxaWd06k87CihLT3wCRIlFP7IM3zkaQLB48zaWFqVEmg3Y5SEKXPCHCWztWNPpzvZwQ/7jBJ/N7xKCTiJ21IEJ6qghC3ldbohlLi07UymBFz5cQUlqBdWNdip4W7UGmgo8UE8hw0UGQ+3G4GSqT2KPG80Qsty5kUOPIC1oJRsJPlESqzRES/Cw3GgocSj3pm211ISLo99tT+CJZ6TM/UFSsJjz4kib5R+CUrI1HaUjLCzeZjCOB8ROxEYtJISWb5aSo5xLKRS8ry+b6DkycZPOkru7JTMSaBk49kpxDbp9C+hZKf4/tQL6Ky/JCW9afpUTwksTyvUU/Jgr/F6OxYpObbvse55fyUlkYOENf4CSkZuGNZTwmaqoeSYRuESJWw1tqKETryGkmm5bCVK2PAVlNDcppoSQmmwvy1h/bmqeWUfAlEy3VFSRi8tKFnan1Crx7SSkjny/sY9FMqULOnM9JTMUBQC0aZTbV7tZ5D+k11G5QolriVQsvUJJZs0RXRDbAlOeHSMSHDB6xpuADR/ZpQEIxJVYS0Z+a0pCSMbrBEkwiIl3iiaU0rAljmeg4K2NcRjPCUbZxrdVlICIS7pWaRkPY1mlBKIXFNI56Iy4l3a0UeekmQa8ZRA7LUNRikEvsspsusjNCgExlOHeMCZ/QQ6N42WhBKw/mnkEkoeoIHfkhIjOIKMav34KbLmKUkXfOczBNUOfri7Qf4rSp17MFrBGkpuaHyKSqxnnNPN0sSKiNDh0y7J2xw5qeMtP6VJkpLEy4ruje06nZU930LPR7t/ti48cu6Mj0+EkvvIsqIb1DmhBGZ3422Mx8gDrXhYQza3RsHbzd38OXJSD2R3UxjcWuNc8DNKRaF7kCLw4PWD5yR01A4dOnTo0KFDhw4dOnTo0KFDhw4dOnTo0KFDhw4dvk78P6pnZorbti+qAAAAAElFTkSuQmCC" 
            alt="KTM Steel" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhMWFhUXGB0bGBYYFxgbGBsdICAdHR4dHiAbHSggHR0lHR0eITEhJSkrLi4uGB8zODMtNygtLisBCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAGoBbAMBIgACEQEDEQH/xAAcAAACAwADAQAAAAAAAAAAAAAGBwAFCAECBAP/xABUEAABAgMFAQYPCwwBAwUAAAABAgMABBEFBgcSITETIkFRYdMIFBcyUlNVcXSBkpOUsbIjJTVCcnORobPS4xUkMzQ2VGJlgoOkwsEmovEWZKPD0f/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwB4xIkSAkSBq2r4sy0/KyK+umArfV6w7GwR/GrMkcoHHBLASJA3K3xYXaTtnA+6NtpXmropW1SBypSUq8auxgkgJEiRICRIkSAFL04gyUg8GJlTgWUBYytlQykkDUcqTF1d62mpyXRMsEltdcpUCk71RSdDygwiOiE+E2/BUfaOw0cFvgaV/u/auQBvEiRSX2tFyXkJp9rRxtlaknbQ00OvFt8UBdxVXnt9qRl1TL+bc0lIOQVVviEjSo4TGSk21Mh3dRMPbrWu6bqvNXjrWHxiJPrfu0l9zr3GpdatKalTZJpwVOsAWXNvxK2kXRLBwbllzZ0hPXZqUoT2JgmhHdDarfz3eZ/+yBTF+3Jh205hpbqw20oJbbCiEgZUmtBwkmtduvEBAaciQoOh7tp91E0w64paGi2pvMSopzZgUgnXLvQQODXjhvwEiRIkBIkSJASJEiQHymplDaFOOLShCRVSlEBIHGSdBC+tTGWz2yQ0Hn6fGQgBH0rIJ74BhZYv3yXOTa2EKIlpdZSEg6LWnRSzx0NQOICvCY5uXhjNz6A8pQl2VdapYKlLHGlIppykivBWAfFz7wpn5VEyhCkJUVDKogneqKeDvRdRQ3Ju4LPlESoc3TIVHPly1zKKtlTsrxxfQEiRIkBIkSJAdHnMqSo8AJ+iF1dzGCWm5hmXRLvJU6rKFKyUGhOtFV4IYM9+jX8lXqMZXwtPvpI/Oj2VQGr4qb1W6iRlXZpxKlpbAqlNMxqoJ0qabTFtARjI4DY82ARWiNKjtiIDi5GJLFpPqYbZdbUlsuVXkoQFJTTek674QcRnjof3ALSdqQPzZW0/xtxoVCwdhB7xgO0SJEgBG9+IcrZzyGH0PKWtGcbmhJFKlO0qGtQYuLr2+1PS6ZlkLCFFQAWAFb1RSagEjaOOEl0RJ98JfwYfaLhjYH/BDHy3ftFQB7EiRICR0feShKlrISlIJUo7ABqSeQCO8LPHe8vS8kJZBo5NEpNNoaFM58dQnlClcUAj73XiXOzz01UpzK9z4ClCdG6cRAAJpwkmH9YGIaHLGXPuauMIKXUDhdFANmwLJSa7Bm5IXmFeHqJ2RnHXQAXRucusjrFJ1KxyZ6J04EqHDFBhzbAkp1yUnE0YmKy8y2rYlVSkKPeUSkniUTwCAHJK3Hm5sTiVVfDhdKjsKiSVA04DUgjiMazsC125uXamWjvHEhQ4weFJ5Qag8ohTzmD+5WZMpFHJpLynWVjrlNp0S331IqadkocUeDAO9oQ6qQcO8dJWzXgWBvkf1AZhypPCYB7kwo7042tNOKbkmQ9lNC8tWVskdgAKqHLUclRrBdizPqZsmaWg0UUBFeILUlB+pRgEw1uRZNoSSHFNL3ZG8eG6rG+HxqA6BQ1H0cEBVMY5zoVv5aWUniTuiT9JUr1Qz7g4gS9phSUAtPoFVsqIJpszJI65NdK0BGlQKivg6j9ldpX55z70K5EzKyd4JdNngpabeQyslZUFlRKHCCSdBmp30VgPv0Qvwk14Kn7R2PJdrFeYkZJqUZYaO55t+4VmuZSl9akilM1Npj19EP8ACTR/9qn7RyGFhrh/JNyTDrzDbzzzaXFKcSFgZwFBKQqoAAIHKawAjZGO7wUBNSqFIrqplSkqA4wlZIV3qiHFZ0/Lz0sHGyl1h5BBBGhBqFJUDsO0EGFzjDcKUEi5NS7KGXWaKO5pCUrTUBQKRpUA1BpXSnDFd0ONoqKZyXJ3qShxI5VApV7KYC2bwbsozKkhcwSgJWpndBlyqKgkVy56EoUOurpti0xpZSixH0IASlO5BKQKAAOIAAHAAIp7tXn3S806zm3im9ySP4maEj6S7F7jb8DTPfa+1RAA/Q29fO/JZ9bkG1+8PLPmnOmpguNLJQhS21JGcqKW0ZgpKgTUhNduzigI6G79JO/Ja9bkEWP1uKYk2W2zRbjwV/S1v/byQBpdG6UtZzRalknfGq1qOZazsFTpsGwAAbeMwt714wTMrOTEslhhSWllIKlLBIoDrQ04YblmziXmW3kda4hK095QBH1GPm9ZUuolamWiTqVFtBJ5SSIBIdXWb/dZfyl//sFmG+Jr9ozZl3WG0Dc1LzIKqggpGteDWAvFS+bEwoyVntN7nmAcdQ2nM6oHRDdBXLX4w1UdBp1x7hBcJUghUxMaTDqQnJ2tFa5SeFRNCeAUA44D04lYkos0hlpAdmVJzZSaIQngK6akkjRI4iajSoTNYhW+yjph6USlnjXLrSkV2VObMkHjMCczbjf5cXOTaVrbRNLUUpAKqNkpbABIBplRw8EM2YxssxaVIWxMqSoFKkltsgg6EEbpspAFdwL6NWmwVpTkdQQHWia5SdhB4UnWh5COCL61ZncmXXOwbUr6AT/xGe8FbSS3bG5tE7k8l1CQo65RVxGb+IBNPGY0FbMuXJd5sbVtrSO+UkQGSbsWf0zNyzK9Q88hKtdaKUM31VjYDTYSAlIASAAANAANAByRkG5s6lidlHVmiUPtlRPAnMAo+IVPijYEB1ccCQVKIAAqSTQADaSeAQmby445VqRIMJWkGgedKgFcqUChpxEkHkgwxonlNWRMZDQuZG68ilAK+lNR44FMOLlWPaEk26WCXUgIeG7OijgAqaBQoFdcKcdOCAH2Mcp9KgXGJZaeEJDiT4jnIH0GGzcO/Mvabai2C26im6MqIJTXYQRopPL9IEVqsIbI4ZdVPnnae3CtuVaTDV4kCRBRKrWplIzFWZOUitVa0LiQoV5IDR0SJEgPjO/o1/JPqMZXwwPvnI/Oj2VRqmb6xfyT6oyrhh8JyPzo9lUBq+Mw34uJPsuzc45L5WN2cXnztneqWcpoFZtajg4Y09AdjB8DznyE+2iAzjd2wZiddLUs3ujgSVlNUpokECtVEDaR9MPPBW6s3IJmhNNBvdFNlG/QqtAqvWk02iAPoez75O+DK9tuNEQAXiFiIxZgSjIXphYqloHKAmtMyzQ0G2mhJp44Vr+ONoE1S1LJHY5XD9Jzj1RRXpzTtvONrNN0nAxXiSlQaFPEK9+NFWXdWSl2w21LNBNNaoSSrlUSKk9+AzPfW97lpOtPOtoQtDeSiCcp3xVWh1G3jMPTA/4IZ+W79oqF3jrdNiVcZmJdAbS8VJWhOiQoUIIA0FRWtOIQxMD/AIJa+cd9tUAexIkSA4JjKl/baXalprU1vgpaWZccaQcqafKUSr+qNIX1kpl+SeZlChLrqcmZaikJSdFGoBNctQOU14IW+HGE0xKTqJmbUypDSSUJbUpRznQEhSAKAEnv0gGldqx0ScqzLI61pATXjPxld8qqfHCXx9urubyZ9tO8eoh7kcA3qv6kinfRyw+orLyWK3OSzss71riaV4UnalQ5QoA+KAFsHL1dOyIQ4qr8vRtddqk/EX4wKE8aTCmxVu+uzrSDzG8Q6rdmVD4jgIKkjvKooDZRYHBBlh7h1adnTiH88ups1Q8lLi6qQeEVb64Gih3qV1g6xHumLRk1MpKUupIWytVaBQ4DTWikkg98HggKG8U/+V7vOusjflsKUgalK2lBS0cfxTTjBB4YUuE97ekJxOc+4PUQ7xDsV/0k68hMNfCm5toWa46l9bCpd0VyoWsqS4NAoAoAoU6HvJ4o8V7ME2H3FOyjvS5USS0UZmqnsaEFA5NRxAQBDixezpCRJbPu728a5KjfL/pT9ZTCEw5s1cxacohIrldS4o/wtnOSfop3yIY9oYRWjNFoTVoNKS0gNtkIUSlA4Kb2p5Samg4oPriXBlrMSotkuPLFFvLpmI7FIGiU11pw6VJoKAuOiMsZW6S02AchSWVngBBK0fTVfkwTYZ4jyS5JliYeQw8y2lshxQSlQSMoUlR0NQBUbQa8hhgWxZbM0yth9AW2sUUk/UQdoIOoI1BEJy18BlZiZWbGQ7EvINR/Ujb5IgLPGDEGUXJOSkq8l5x6gUWzmQhAIJqoaEmlKDjrFX0P7G4S8/POCjYAAPzaVLX7SY72TgMrMDNTgy8KGUUJ/qVs8kwxbw3YP5LckLPDbWZvc0BRISEkjPUgEklObXWpMBnG5ttKbtSXm1nVUwC4rkcJCz9CzD9xt+BpnvtfaohXjAy0e2yvluc1Devrd+YnbKVKhTYmFpazElW55kqQpeoTWmhppxQC36G79LO/Ia9bkVOP1qbraKWQd6w0ARxLXvj/ANuSGDhLcKZsxcwqYW0oOpQE7mpR1SVVrmSOOBS9GEVpTc5MTO6y1HXVKSCtyoTWiAaN7QkAeKAPsG7S3ayZepqprM0eTISEjyMsA2Nt/HN0XZ0uciEgdMLB3yswruY4k5SMx4a02VqaYTXSmrNZeZmFtKStwLRualGhIyqrmSOxTTxwJ3zwgmpqdfmWphkIdUFBK84UNACDRJHBAezCi4svKBM3NuNKmCKoQVpIZBHf1cpw8GwccNRmcbUaJcQo8QUCfqMIhOBU5+8S3/yfdgpw6wwmLPnRMuOsrSG1pojPmqqlNoA4IAAlSiz7wq6ZA3NMy5mzUICHQrIs14AFpV4jGhHpaVQguKQylAGYrKUBIG2pNKUpwwMYiYdtWllcSvcphAyhzLVKk7cqxtIBrQg1FTt2QvRg7aikhlc41uIPW7q8pI5QgpAr9EAc3Kv9JT00WJeUWhaQpQc3NvKEjTMSDmTmqBSnxoYEDFxLlMWY0UNkrcXQuOqABVTYAPipGtBrtOpgngMs4nXXVIzzqctGXVKcZVTelJNSjvoJpTiynhgsuJjEqXaSxOtrdQgZUOooXABsCkqICqD41a6bDth0XgsGXnWSzMthxB1FdCk9kkjVJ5RCntbAjUmVm6J4EvIqR/WilfJgCK/c63athPvSmZSUkLAUkpV7koFenyQqFVhJevpKdTnVSXfo25xAnrF+InU8SjD0w3u25ISKZZ5SFqC1qqipTRRqOuAP1QI3mwSl3nFOSjxl8xJU0U529exFQUjkqRxUgPfjderpWT6XbVR6ZBTptS38dXjrlHfPFCnwZssvWswQN6yFOq5AElI/7lJg5ncHJyacSubtFKsqUoCg0SrInYOuA8etawxrmXOlrNaLcuCVK1cdXQrWRsqQKADgA0HfJJAOdxvk0zBa3F0tBZTu4y00NMwTWpTw8dODgjti/iC7ILlmpRSd1J3VzMKpLeqUoPIs1NQQRk5YpJjAiswpSZsCXKyrLuZLgTWuWuahPBm+qFjeScmJ20HCtte7uOBCWSmi003qG6GlCBT6zAaLuZfdi05dam6odQn3Vk7Ukg6g7FJNDQ/SBGd8OX0N2jJuOKShCXQVKUQEgUOpJ0EaLw+ucizpMM6F5wZnnBwqI2D+FOweM8JhcIwEcAp08jzB5yAbH/q6z/36V8+196KfEtxMxY02phSXUlrMFIIUkhKgVEEaGgSfogA6gjn78jzB5yGpcy7/AElItSilhzcwoFWWgVmUpWwk9lTbAZ2wvvM3Z88l90HcloLbhAJKQSDmA4aFIqOKtI0pZFvys1+rTDTtBUhC0kgHjANR44ALwYJybylLlnVyxOuQALbHeSSCO8FU4hBJh1chFlsrQF7q64rM47ly1polIFTQAV4TqowCLvyyuQtxx2nWzCZlFdigVBz6M2ZPiMPKysS7MebC+mm2zTVDpyLSeKh298VEeq+tyJW0kJD4KVo6x1FAtNeDUEFPIfqhZvYDO13k8kj+Jog/UsiAo8Z77sz7jTMsSppkqJcoQFrNBvQdcoA28OaG1dBhNlWM2qYChuTRddFN9mVVZSBx1OXviKi5mD8tJupffcMy6g1QCkJbSeBWWpKlDgJNOGldYOrwWSiblnpZwkJdQUkjaK7COUHXxQATdDFpmdmkyqpdbKl1DaipKgSAVUVQDKSAePXSGNCruVhB0nNomXZoOhokoQlvLUkFIKiVHYCTQcNNYakANYgXsFmSwmCyXquJRlCwjaFGtSD2PFwwuxj4O56vSBzcX3RAD3sT4Q36lxnPNAO/q9Duer0gc3E6vY7nn0gc3CRBjsTAOzq9juefSBzccdXwdzz6QObhJkxwFQDt6vg7nn0gc3E6vg7nn0gc3C6ufcSatJDi5ct0bUEqzqINSK6aGCA4KWlxsecP3YAk6vg7nn0gc3E6vg7nn0gc3AReXDGdkpdcy+WS2ilcqyVakAaU4zAVmpAOs4+juefSBzcTq+juefSBzUVslg2mYlQ/LzyVqU2FJTlGXMRXKVBRI102QM23hdaEqw5MPBrc201VlcBNNBoKcsAbnH7+Xn0gc1HBx/8A5efSBzUJExKwDvGP38vPpA5qOOr9/Lz6QOahIlUQGAd/V9/l/wDkDmogx9/l/wDkDmoS0s2VqShIqpRCUjjJNAPpMNx/CSUk5YP2nPKb2AhtIoFH4oqCVHxcEB7+r0e5/wDkfhRwMez3P/yBzUKK3EMIfcTKuKcYB3i1CiiKCtRQcNRHhBgHYMev5f8A5H4Uc9Xk9z/8j8KEuwnMpKRpUgeMmkMlWC1odsl/LV92AIOrwf3D/I/Cjjq8nuf/AJH4UUIwXtDtsv5avux6bDw8kFu9IzE4tM+muZCB7nszDKVJ329oTrxwFp1eT3P/AMj8KJ1ej3P/AMj8KF7f+6K7MmAytYcQtOZtYFCRWhBHAQfXAwVQDp6vR/cP8j8KOvV7Pc//ACPwoS+aJAOnq9H9wHpH4UcHHpX7gPSPwoTBNBxw2LJuFZQlEvzc+MxbC1pbcQMtRXLl1USNnHWA9vV8V3PHpH4UcDH1Xc8ekfhQr71Ikg8PyetxbOQVLgIVnqajUDSlIpqwDqGPiu549I/CjwPYvMKmUTSrJbMwhJSl3d98Ado/Ra6aAnZU02mFKTxR95FnO4hBUEZlJTmOxNSBmPINsA5Dj0ruePSPwo46vSu549I/CivtDDGWQl4B2ZRuTZWmbdDXSrhpXKkg5v8AwYVCVH6oB0HHlXc8ekfhRx1eldzx6R+FCZEEVx7CZnZrpd58MJKCUr01UKb3fGlaV+iAYnV6X3PHpH4UcnHlfc8ekfhRW21gw+lSelJlpxBGpcORQPeFQRAFeewHpB7cHigryhe8OZNDUbePSAZvV6X+4D0g81EOPS/3BPpB5qE2TEMA4zj0v9wT6Qeajnq9L/cE+kHmoTMQmAft0sYFTk2zLGTCA6ojPuxVSiVK2bmK7OOGvGVsK1++0n84fYXGqYBadEB8Fjwhv1KjOVI0fj+PesfPt/7RnAiA7ARZ3Ys5MxNy8uskJddSgkbQDppFWIILgfCUl4Q364ArxTw7l7MYadZcdWpbuQhZTSmUnSg26RMLMPJe02HXXnHEKQ5kAQU0plB4Rt1gz6IofmUv4QPYVHTodP1Wa+fHsCAXtk3PU7bD1nMPrbbbWvMupzZEU1oKAqNaeODO37tWNIONsTc5O7osAijiiACaVNBoKxSSN4WpG8s28+SG1OOIUoCuXNSiiOKo178E+L1yHbQ3OfklJeytULaSDnTUqCkHYTrsgB7FDDjpOV6al5l5xoFIW24sq0VoFA7DrTQjhj6XFwulZ2zm5tx15K1BdQkpy70kDaOSKG9GKE1Nyq5J5hptJypVQLCxkIOxR0OkNnB74Ea7zvtKgEHcyR6YnWJYuOIQ65lUUKINNfFXSDLFu5Tdmssqaffc3VakqDi6igFdgivwluzMvTrM20gFliY90VmAI2nYdToYZePNhPzMo2plIUGFLcc1AonLt1296AHrTwikW5MTK5p1pIQha1qopIBoVAACpJrQDjpHnutciwrQztyr80XEJqcxCTTZmAKaEVg2xE1u+58wz/pC36Hw++Lvg6vaTABt+Lsqs6cXLKWHAAFIXSlUq2VHAeAxQiGNj4PfT+w3/wAwuICysA/nUv8APN+2IffRCfBqPCEeyuEFYf6xL/PN+2If3RCD3sR4Qj2VwAnYuFso9ZSZ5TjwcMup3KCnLmSFHZStNIAMP7EbnZ5mWdKghzNUpoDokkUryiH1dDW7iPA3PZXCWwd+FpTvq9hUBaYnXHl7OelG2VuKDxOYrIJFFJGlAOOL/EnDtiQklTDL8wpYWhNFuVTRRodgEejogv1mz++r2kQV46/BK/nWvagFnhRdNu0lTCX3n07kEFORwjrq1rWvFFhd6xkSd5kS7alqQgGhWaq1arqfHHv6HQ+6TnyWvWqO7n7XDvD7GA83RDNlU1JJG1SFAd8qAH1x65vDKzLOlemLRdecpQEI0GY/FSBqfGeCPJ0RKiJmTUNCELIPEQoER8WbnW5aMuDOTWRk0WEPq102KISN7t4YD23euPYlqNuGSVMNLbICgo6iuw0VUEHv8EC1l3Ts9qamJO0ppaHkLCGtzQaKBoQrYalQIGXghl4R3RMguZrMsP5wjRpVSmmbruKtfqgHt79q0eEM+ymA7YiYbyVnyW7ImHN2KwEJcp7pxpASNCBrU8UFGEl1pR2zGnJiUaWsqcOZxsFRAJoakVpHw6IZwpbkljal5RHFUAH/AIgiuTaarWssl/3NRUtsllRR1uwih00OzZAZom6Z10pTMqn0mkfIR9JhrKpSeJRFe8aVjpAGmF1yRabzgccKGWgCvLTMoq2AV2bCSYKrZsS7cpMGVfXNbomgWoElKSeMgcR4AYB7lX1mLNLpl0Nq3XLm3QE0y1pShHHHtlrCn7cemJtltsqKhugzBCQSNKZjxCAK8ScLmpWTVNSjzim26FTTiswykgBSTyEjSmyOtx7o2NaSdybcmUzKGgpypATXQKKaihGaGPiU0U2HMJV1yWEA98FIMLHoej74PeDn20wFI9coMWy1Zryytta079O9UUKBI7ytNYNb3XFsOzg2ZpU3RwkJyqCtm2u95Y+V8v2qk/7P+0evojf0cn8tz2RAfCz8NLPtCWL9mzcwmhKQHCSAocChQEcGzjgFuNc9U9PqlHVlG5BRdI1VvTlomvGfqhp9D3+oPeEK9lMUGFh/6gnx8/8AaiAl57Fu/ZrqWH25lxwpCjlUTQHYTqBXTYI73hwtk3JEztmuOU3PdUoWcyVppUjUVSaV8cD+PI99f7CPWqGtdHW77fgi/ZVAZjBEcpMdEHQd6OwgCvDA++0l87/qqNVRlHDE++sl89/qqNXQC4x8+Cv77f8AzGb40lj0PepXzzfrjN+WA4i9uF8JSXhDfrijpHqsueUw80+imZpaVprsqk1oYB69EQPzFjwgeyqPh0Oh/Npr55PsCPDbOItkWnLJZtBuYaIUFbwVooAioUNo1O0R1sPEKx7LYW3INzDpWrMc4pVVKCqlbB3hACtq3aXaFvTks24ltRccVmUCRpTTTvx7fyhO3bmkMF1L7LiQtTQzZKEkHLXrVaV00PDA/d6+q2LVVaLiAsuKWXEJ03q+BNeEaUrtpBzee9V37RcbemumkrQnLRKSKitaGla68UBc413Zl3ZFVoJQEPoCDmGhWlRAovjIrodukW2DPwK1/d9pUAmJeJ8vNyhk5RtwIUU5nFjKMqSCAkVqakDUx88L8TmZGW6Umm1lAUooWgA0CtSlSa8ddRxwAvhnaLzdpSzSHVpbXMDO2FEJVqRvgNDDP6IiccblGA24tAW4pKwlRAUnKdDTaOQwO2Zat2peZE00JrdEKzoQUqKArkHj4TFFivf5NplptltSGWiSCumZSiKVoNgA9cA17/8A7POeDNf6Qs+h9Pvi54Or2kxbXlxOk5iy1SSEPbqWUIBKQE1TlrrXZpAbhdedmzpxT74WUFpSN4ATUkHhPJAWuP3woPmEf8wt4MMULys2hOB9gLCA0lG/ABqCeInTWBFKYD22Kfzhj51v2hGgeiC+DE+EN+pcZ7s90IdbWRolxKjTbQEE+qGlihiTK2jJiXZQ6lYdSuq0gCgrXYTrrAMG5n7Ot+COepcJPB/4WlO+r2DBtdjFSUlrMblFsuuOIaUgig3NRNdK1qAQaVpHkuneG78o6JpDE2h4VypV7olBOhy0OvFUwFn0Qf6xZ/fV7SIKsdPglz5xr2hChxNvx+Un2ltNlttmuTMQVEkg5iBoNg0gzcxRkJ6UMtabDyagZi1qCRQhSaEFOvAYDp0Oh90nPkt+tUfWY0vcnvD7GPld6+9jWYhwyLM04tylc+labBUmgGvAIEbOvnW2Bacwk0zGqEakJy5EgVpWmlYAzx3T+fWbXUV2f1ogjx7cUmy96SKvNg0NKjXQ8kLTE6+7NoPSzsshaSxUndABU1SobCdNIMbQxLsq0JXcZ9p5FaEpSCaKHClST64Cu6HKm6TvyW/WuK68RpetHhDHspj4XCvrI2bNTi0NvmXdyBkUBWAmtc1TxmB+9F6Q9av5RlkkUW2tCVjWqABrTgNIBkdEaPzeU+dX7MW2AvwX/fc/1get3ESyLSYQ3PszCFJOYBArlVShooHUd8R1l8ULOkZTpezWHlEZindNAFHapRJJPeHFAJu0R7s784v2jHnpH0WsqJUdpJJPKdTHQwEA4YtbIt+alUrEs+40FaqCFUqRsrFYIlK6QGoMQ1lVgvqJqTLoJJ4TvSTCy6H0++Dvg59pMe68mKspMWYuSQ08HFMpbCiE5aimu2tNIEsML0tWdNLfeQtaVNFFEAVqSDwnZpAG99B/1TJf2fWqPV0Rv6OT+cc9kQH3gvqy/bEvaCEOBprc8yCBnOUkmmtOHjj7Yq37YtNDCWW3EFpaic4AqCANKEwB30PX6g94Qr2UxQ4YftDP/wB/7QRV4X4hy9myzjLzbq1KdKwUBJFKJHCRrpFLd++YlLVen0tFbbynKoJAWErVm72YUHJAWOPXwp/YR61Q1bl62A14Iv1Khe34vhY0+lTqpd8zIbKG1UygHXLmoqhAJ4o+t3sVJWXsxuTWy8VpZLZUAnLUg67a01gE82NB3o7R1A0EdwIAlwzPvrJfPD1GNXxk/DQe+klTtyfUY1hACWKF3np+RMuxlzlxCt+aCiTU6gGFD1FrT45fzivuRouJAZ1GC1p8cv5xX3I4OClpccv5xX3I0XEgM59RO0uyl/OK+5HIwUtLspbzivuRouJAZ06idpdlLecV9yOOolaXZS3nF/cjRkSAzp1ErS7KW84v7kQYJWl2ct5xf3I0XEgM6DBK0uzlvOL5uIcEbS7OW84vm40XEgM5HBC0uzlvOL5uODgfaXZy3nF83GjokBnHqIWn2Ut5xfNxBgfaXZy3nF83GjokBnNOCFpdnLecXzccjBC0uzlvOL5uNFxIDOvURtLs5bzjnNx2GClpD48t5xfNxoiJAZ46idpdslvOL5uOxwUtHtkt5xzm40LEgM9jBS0e2S3luc3E6ido9slvLc5uNCRIDPXURtHtst5bnNxz1EbR7bK+W5zcaEiQGejghaHbZXy3ObidQ+0O2S3luc3GhYkBnnqIWj22V8tzm44GB1o9tlfLc5uNDxIDO/UNtDtst5bnNxx1DbR7ZK+Nxzm40TEgM7DA60e2ytPluc3HPUOtHtsr5bnNxoiJAZ5GB1odslfLc5uO4wRtDtsr5bnNxoOJAZ+GCVodulvLc5uOOojaHbZXy3ObjQUSAz/1E7Q7bK+W5zccKwRtDt0r5bnNxoGJAZ8OB9odulfLd5uJ1D7Q7dK+U7zcaDiQGflYI2gR+llfKd5uOnUOtDt0r5TvNxoSJAJG6OD87KzsvMOPS5Q04FKCVOZiBXZVAFfHDuiRID//2Q==" 
            alt="Mobilize Co., Ltd." 
            class="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhMWFhUXGB0bGBYYFxgbGBsdICAdHR4dHiAbHSggHR0lHR0eITEhJSkrLi4uGB8zODMtNygtLisBCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAGoBbAMBIgACEQEDEQH/xAAcAAACAwADAQAAAAAAAAAAAAAGBwAFCAECBAP/xABUEAABAgMFAQYPCwwBAwUAAAABAgMABBEFBgcSITETIkFRYdMIFBcyUlNVcXSBkpOUsbIjJTVCcnORobPS4xUkMzQ2VGJlgoOkwsEmovEWZKPD0f/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwB4xIkSAkSBq2r4sy0/KyK+umArfV6w7GwR/GrMkcoHHBLASJA3K3xYXaTtnA+6NtpXmropW1SBypSUq8auxgkgJEiRICRIkSAFL04gyUg8GJlTgWUBYytlQykkDUcqTF1d62mpyXRMsEltdcpUCk71RSdDygwiOiE+E2/BUfaOw0cFvgaV/u/auQBvEiRSX2tFyXkJp9rRxtlaknbQ00OvFt8UBdxVXnt9qRl1TL+bc0lIOQVVviEjSo4TGSk21Mh3dRMPbrWu6bqvNXjrWHxiJPrfu0l9zr3GpdatKalTZJpwVOsAWXNvxK2kXRLBwbllzZ0hPXZqUoT2JgmhHdDarfz3eZ/+yBTF+3Jh205hpbqw20oJbbCiEgZUmtBwkmtduvEBAaciQoOh7tp91E0w64paGi2pvMSopzZgUgnXLvQQODXjhvwEiRIkBIkSJASJEiQHymplDaFOOLShCRVSlEBIHGSdBC+tTGWz2yQ0Hn6fGQgBH0rIJ74BhZYv3yXOTa2EKIlpdZSEg6LWnRSzx0NQOICvCY5uXhjNz6A8pQl2VdapYKlLHGlIppykivBWAfFz7wpn5VEyhCkJUVDKogneqKeDvRdRQ3Ju4LPlESoc3TIVHPly1zKKtlTsrxxfQEiRIkBIkSJAdHnMqSo8AJ+iF1dzGCWm5hmXRLvJU6rKFKyUGhOtFV4IYM9+jX8lXqMZXwtPvpI/Oj2VQGr4qb1W6iRlXZpxKlpbAqlNMxqoJ0qabTFtARjI4DY82ARWiNKjtiIDi5GJLFpPqYbZdbUlsuVXkoQFJTTek674QcRnjof3ALSdqQPzZW0/xtxoVCwdhB7xgO0SJEgBG9+IcrZzyGH0PKWtGcbmhJFKlO0qGtQYuLr2+1PS6ZlkLCFFQAWAFb1RSagEjaOOEl0RJ98JfwYfaLhjYH/BDHy3ftFQB7EiRICR0feShKlrISlIJUo7ABqSeQCO8LPHe8vS8kJZBo5NEpNNoaFM58dQnlClcUAj73XiXOzz01UpzK9z4ClCdG6cRAAJpwkmH9YGIaHLGXPuauMIKXUDhdFANmwLJSa7Bm5IXmFeHqJ2RnHXQAXRucusjrFJ1KxyZ6J04EqHDFBhzbAkp1yUnE0YmKy8y2rYlVSkKPeUSkniUTwCAHJK3Hm5sTiVVfDhdKjsKiSVA04DUgjiMazsC125uXamWjvHEhQ4weFJ5Qag8ohTzmD+5WZMpFHJpLynWVjrlNp0S331IqadkocUeDAO9oQ6qQcO8dJWzXgWBvkf1AZhypPCYB7kwo7042tNOKbkmQ9lNC8tWVskdgAKqHLUclRrBdizPqZsmaWg0UUBFeILUlB+pRgEw1uRZNoSSHFNL3ZG8eG6rG+HxqA6BQ1H0cEBVMY5zoVv5aWUniTuiT9JUr1Qz7g4gS9phSUAtPoFVsqIJpszJI65NdK0BGlQKivg6j9ldpX55z70K5EzKyd4JdNngpabeQyslZUFlRKHCCSdBmp30VgPv0Qvwk14Kn7R2PJdrFeYkZJqUZYaO55t+4VmuZSl9akilM1Npj19EP8ACTR/9qn7RyGFhrh/JNyTDrzDbzzzaXFKcSFgZwFBKQqoAAIHKawAjZGO7wUBNSqFIrqplSkqA4wlZIV3qiHFZ0/Lz0sHGyl1h5BBBGhBqFJUDsO0EGFzjDcKUEi5NS7KGXWaKO5pCUrTUBQKRpUA1BpXSnDFd0ONoqKZyXJ3qShxI5VApV7KYC2bwbsozKkhcwSgJWpndBlyqKgkVy56EoUOurpti0xpZSixH0IASlO5BKQKAAOIAAHAAIp7tXn3S806zm3im9ySP4maEj6S7F7jb8DTPfa+1RAA/Q29fO/JZ9bkG1+8PLPmnOmpguNLJQhS21JGcqKW0ZgpKgTUhNduzigI6G79JO/Ja9bkEWP1uKYk2W2zRbjwV/S1v/byQBpdG6UtZzRalknfGq1qOZazsFTpsGwAAbeMwt714wTMrOTEslhhSWllIKlLBIoDrQ04YblmziXmW3kda4hK095QBH1GPm9ZUuolamWiTqVFtBJ5SSIBIdXWb/dZfyl//sFmG+Jr9ozZl3WG0Dc1LzIKqggpGteDWAvFS+bEwoyVntN7nmAcdQ2nM6oHRDdBXLX4w1UdBp1x7hBcJUghUxMaTDqQnJ2tFa5SeFRNCeAUA44D04lYkos0hlpAdmVJzZSaIQngK6akkjRI4iajSoTNYhW+yjph6USlnjXLrSkV2VObMkHjMCczbjf5cXOTaVrbRNLUUpAKqNkpbABIBplRw8EM2YxssxaVIWxMqSoFKkltsgg6EEbpspAFdwL6NWmwVpTkdQQHWia5SdhB4UnWh5COCL61ZncmXXOwbUr6AT/xGe8FbSS3bG5tE7k8l1CQo65RVxGb+IBNPGY0FbMuXJd5sbVtrSO+UkQGSbsWf0zNyzK9Q88hKtdaKUM31VjYDTYSAlIASAAANAANAByRkG5s6lidlHVmiUPtlRPAnMAo+IVPijYEB1ccCQVKIAAqSTQADaSeAQmby445VqRIMJWkGgedKgFcqUChpxEkHkgwxonlNWRMZDQuZG68ilAK+lNR44FMOLlWPaEk26WCXUgIeG7OijgAqaBQoFdcKcdOCAH2Mcp9KgXGJZaeEJDiT4jnIH0GGzcO/Mvabai2C26im6MqIJTXYQRopPL9IEVqsIbI4ZdVPnnae3CtuVaTDV4kCRBRKrWplIzFWZOUitVa0LiQoV5IDR0SJEgPjO/o1/JPqMZXwwPvnI/Oj2VRqmb6xfyT6oyrhh8JyPzo9lUBq+Mw34uJPsuzc45L5WN2cXnztneqWcpoFZtajg4Y09AdjB8DznyE+2iAzjd2wZiddLUs3ujgSVlNUpokECtVEDaR9MPPBW6s3IJmhNNBvdFNlG/QqtAqvWk02iAPoez75O+DK9tuNEQAXiFiIxZgSjIXphYqloHKAmtMyzQ0G2mhJp44Vr+ONoE1S1LJHY5XD9Jzj1RRXpzTtvONrNN0nAxXiSlQaFPEK9+NFWXdWSl2w21LNBNNaoSSrlUSKk9+AzPfW97lpOtPOtoQtDeSiCcp3xVWh1G3jMPTA/4IZ+W79oqF3jrdNiVcZmJdAbS8VJWhOiQoUIIA0FRWtOIQxMD/AIJa+cd9tUAexIkSA4JjKl/baXalprU1vgpaWZccaQcqafKUSr+qNIX1kpl+SeZlChLrqcmZaikJSdFGoBNctQOU14IW+HGE0xKTqJmbUypDSSUJbUpRznQEhSAKAEnv0gGldqx0ScqzLI61pATXjPxld8qqfHCXx9urubyZ9tO8eoh7kcA3qv6kinfRyw+orLyWK3OSzss71riaV4UnalQ5QoA+KAFsHL1dOyIQ4qr8vRtddqk/EX4wKE8aTCmxVu+uzrSDzG8Q6rdmVD4jgIKkjvKooDZRYHBBlh7h1adnTiH88ups1Q8lLi6qQeEVb64Gih3qV1g6xHumLRk1MpKUupIWytVaBQ4DTWikkg98HggKG8U/+V7vOusjflsKUgalK2lBS0cfxTTjBB4YUuE97ekJxOc+4PUQ7xDsV/0k68hMNfCm5toWa46l9bCpd0VyoWsqS4NAoAoAoU6HvJ4o8V7ME2H3FOyjvS5USS0UZmqnsaEFA5NRxAQBDixezpCRJbPu728a5KjfL/pT9ZTCEw5s1cxacohIrldS4o/wtnOSfop3yIY9oYRWjNFoTVoNKS0gNtkIUSlA4Kb2p5Samg4oPriXBlrMSotkuPLFFvLpmI7FIGiU11pw6VJoKAuOiMsZW6S02AchSWVngBBK0fTVfkwTYZ4jyS5JliYeQw8y2lshxQSlQSMoUlR0NQBUbQa8hhgWxZbM0yth9AW2sUUk/UQdoIOoI1BEJy18BlZiZWbGQ7EvINR/Ujb5IgLPGDEGUXJOSkq8l5x6gUWzmQhAIJqoaEmlKDjrFX0P7G4S8/POCjYAAPzaVLX7SY72TgMrMDNTgy8KGUUJ/qVs8kwxbw3YP5LckLPDbWZvc0BRISEkjPUgEklObXWpMBnG5ttKbtSXm1nVUwC4rkcJCz9CzD9xt+BpnvtfaohXjAy0e2yvluc1Devrd+YnbKVKhTYmFpazElW55kqQpeoTWmhppxQC36G79LO/Ia9bkVOP1qbraKWQd6w0ARxLXvj/ANuSGDhLcKZsxcwqYW0oOpQE7mpR1SVVrmSOOBS9GEVpTc5MTO6y1HXVKSCtyoTWiAaN7QkAeKAPsG7S3ayZepqprM0eTISEjyMsA2Nt/HN0XZ0uciEgdMLB3yswruY4k5SMx4a02VqaYTXSmrNZeZmFtKStwLRualGhIyqrmSOxTTxwJ3zwgmpqdfmWphkIdUFBK84UNACDRJHBAezCi4svKBM3NuNKmCKoQVpIZBHf1cpw8GwccNRmcbUaJcQo8QUCfqMIhOBU5+8S3/yfdgpw6wwmLPnRMuOsrSG1pojPmqqlNoA4IAAlSiz7wq6ZA3NMy5mzUICHQrIs14AFpV4jGhHpaVQguKQylAGYrKUBIG2pNKUpwwMYiYdtWllcSvcphAyhzLVKk7cqxtIBrQg1FTt2QvRg7aikhlc41uIPW7q8pI5QgpAr9EAc3Kv9JT00WJeUWhaQpQc3NvKEjTMSDmTmqBSnxoYEDFxLlMWY0UNkrcXQuOqABVTYAPipGtBrtOpgngMs4nXXVIzzqctGXVKcZVTelJNSjvoJpTiynhgsuJjEqXaSxOtrdQgZUOooXABsCkqICqD41a6bDth0XgsGXnWSzMthxB1FdCk9kkjVJ5RCntbAjUmVm6J4EvIqR/WilfJgCK/c63athPvSmZSUkLAUkpV7koFenyQqFVhJevpKdTnVSXfo25xAnrF+InU8SjD0w3u25ISKZZ5SFqC1qqipTRRqOuAP1QI3mwSl3nFOSjxl8xJU0U529exFQUjkqRxUgPfjderpWT6XbVR6ZBTptS38dXjrlHfPFCnwZssvWswQN6yFOq5AElI/7lJg5ncHJyacSubtFKsqUoCg0SrInYOuA8etawxrmXOlrNaLcuCVK1cdXQrWRsqQKADgA0HfJJAOdxvk0zBa3F0tBZTu4y00NMwTWpTw8dODgjti/iC7ILlmpRSd1J3VzMKpLeqUoPIs1NQQRk5YpJjAiswpSZsCXKyrLuZLgTWuWuahPBm+qFjeScmJ20HCtte7uOBCWSmi003qG6GlCBT6zAaLuZfdi05dam6odQn3Vk7Ukg6g7FJNDQ/SBGd8OX0N2jJuOKShCXQVKUQEgUOpJ0EaLw+ucizpMM6F5wZnnBwqI2D+FOweM8JhcIwEcAp08jzB5yAbH/q6z/36V8+196KfEtxMxY02phSXUlrMFIIUkhKgVEEaGgSfogA6gjn78jzB5yGpcy7/AElItSilhzcwoFWWgVmUpWwk9lTbAZ2wvvM3Z88l90HcloLbhAJKQSDmA4aFIqOKtI0pZFvys1+rTDTtBUhC0kgHjANR44ALwYJybylLlnVyxOuQALbHeSSCO8FU4hBJh1chFlsrQF7q64rM47ly1polIFTQAV4TqowCLvyyuQtxx2nWzCZlFdigVBz6M2ZPiMPKysS7MebC+mm2zTVDpyLSeKh298VEeq+tyJW0kJD4KVo6x1FAtNeDUEFPIfqhZvYDO13k8kj+Jog/UsiAo8Z77sz7jTMsSppkqJcoQFrNBvQdcoA28OaG1dBhNlWM2qYChuTRddFN9mVVZSBx1OXviKi5mD8tJupffcMy6g1QCkJbSeBWWpKlDgJNOGldYOrwWSiblnpZwkJdQUkjaK7COUHXxQATdDFpmdmkyqpdbKl1DaipKgSAVUVQDKSAePXSGNCruVhB0nNomXZoOhokoQlvLUkFIKiVHYCTQcNNYakANYgXsFmSwmCyXquJRlCwjaFGtSD2PFwwuxj4O56vSBzcX3RAD3sT4Q36lxnPNAO/q9Duer0gc3E6vY7nn0gc3CRBjsTAOzq9juefSBzccdXwdzz6QObhJkxwFQDt6vg7nn0gc3E6vg7nn0gc3C6ufcSatJDi5ct0bUEqzqINSK6aGCA4KWlxsecP3YAk6vg7nn0gc3E6vg7nn0gc3AReXDGdkpdcy+WS2ilcqyVakAaU4zAVmpAOs4+juefSBzcTq+juefSBzUVslg2mYlQ/LzyVqU2FJTlGXMRXKVBRI102QM23hdaEqw5MPBrc201VlcBNNBoKcsAbnH7+Xn0gc1HBx/8A5efSBzUJExKwDvGP38vPpA5qOOr9/Lz6QOahIlUQGAd/V9/l/wDkDmogx9/l/wDkDmoS0s2VqShIqpRCUjjJNAPpMNx/CSUk5YP2nPKb2AhtIoFH4oqCVHxcEB7+r0e5/wDkfhRwMez3P/yBzUKK3EMIfcTKuKcYB3i1CiiKCtRQcNRHhBgHYMev5f8A5H4Uc9Xk9z/8j8KEuwnMpKRpUgeMmkMlWC1odsl/LV92AIOrwf3D/I/Cjjq8nuf/AJH4UUIwXtDtsv5avux6bDw8kFu9IzE4tM+muZCB7nszDKVJ329oTrxwFp1eT3P/AMj8KJ1ej3P/AMj8KF7f+6K7MmAytYcQtOZtYFCRWhBHAQfXAwVQDp6vR/cP8j8KOvV7Pc//ACPwoS+aJAOnq9H9wHpH4UcHHpX7gPSPwoTBNBxw2LJuFZQlEvzc+MxbC1pbcQMtRXLl1USNnHWA9vV8V3PHpH4UcDH1Xc8ekfhQr71Ikg8PyetxbOQVLgIVnqajUDSlIpqwDqGPiu549I/CjwPYvMKmUTSrJbMwhJSl3d98Ado/Ra6aAnZU02mFKTxR95FnO4hBUEZlJTmOxNSBmPINsA5Dj0ruePSPwo46vSu549I/CivtDDGWQl4B2ZRuTZWmbdDXSrhpXKkg5v8AwYVCVH6oB0HHlXc8ekfhRx1eldzx6R+FCZEEVx7CZnZrpd58MJKCUr01UKb3fGlaV+iAYnV6X3PHpH4UcnHlfc8ekfhRW21gw+lSelJlpxBGpcORQPeFQRAFeewHpB7cHigryhe8OZNDUbePSAZvV6X+4D0g81EOPS/3BPpB5qE2TEMA4zj0v9wT6Qeajnq9L/cE+kHmoTMQmAft0sYFTk2zLGTCA6ojPuxVSiVK2bmK7OOGvGVsK1++0n84fYXGqYBadEB8Fjwhv1KjOVI0fj+PesfPt/7RnAiA7ARZ3Ys5MxNy8uskJddSgkbQDppFWIILgfCUl4Q364ArxTw7l7MYadZcdWpbuQhZTSmUnSg26RMLMPJe02HXXnHEKQ5kAQU0plB4Rt1gz6IofmUv4QPYVHTodP1Wa+fHsCAXtk3PU7bD1nMPrbbbWvMupzZEU1oKAqNaeODO37tWNIONsTc5O7osAijiiACaVNBoKxSSN4WpG8s28+SG1OOIUoCuXNSiiOKo178E+L1yHbQ3OfklJeytULaSDnTUqCkHYTrsgB7FDDjpOV6al5l5xoFIW24sq0VoFA7DrTQjhj6XFwulZ2zm5tx15K1BdQkpy70kDaOSKG9GKE1Nyq5J5hptJypVQLCxkIOxR0OkNnB74Ea7zvtKgEHcyR6YnWJYuOIQ65lUUKINNfFXSDLFu5Tdmssqaffc3VakqDi6igFdgivwluzMvTrM20gFliY90VmAI2nYdToYZePNhPzMo2plIUGFLcc1AonLt1296AHrTwikW5MTK5p1pIQha1qopIBoVAACpJrQDjpHnutciwrQztyr80XEJqcxCTTZmAKaEVg2xE1u+58wz/pC36Hw++Lvg6vaTABt+Lsqs6cXLKWHAAFIXSlUq2VHAeAxQiGNj4PfT+w3/wAwuICysA/nUv8APN+2IffRCfBqPCEeyuEFYf6xL/PN+2If3RCD3sR4Qj2VwAnYuFso9ZSZ5TjwcMup3KCnLmSFHZStNIAMP7EbnZ5mWdKghzNUpoDokkUryiH1dDW7iPA3PZXCWwd+FpTvq9hUBaYnXHl7OelG2VuKDxOYrIJFFJGlAOOL/EnDtiQklTDL8wpYWhNFuVTRRodgEejogv1mz++r2kQV46/BK/nWvagFnhRdNu0lTCX3n07kEFORwjrq1rWvFFhd6xkSd5kS7alqQgGhWaq1arqfHHv6HQ+6TnyWvWqO7n7XDvD7GA83RDNlU1JJG1SFAd8qAH1x65vDKzLOlemLRdecpQEI0GY/FSBqfGeCPJ0RKiJmTUNCELIPEQoER8WbnW5aMuDOTWRk0WEPq102KISN7t4YD23euPYlqNuGSVMNLbICgo6iuw0VUEHv8EC1l3Ts9qamJO0ppaHkLCGtzQaKBoQrYalQIGXghl4R3RMguZrMsP5wjRpVSmmbruKtfqgHt79q0eEM+ymA7YiYbyVnyW7ImHN2KwEJcp7pxpASNCBrU8UFGEl1pR2zGnJiUaWsqcOZxsFRAJoakVpHw6IZwpbkljal5RHFUAH/AIgiuTaarWssl/3NRUtsllRR1uwih00OzZAZom6Z10pTMqn0mkfIR9JhrKpSeJRFe8aVjpAGmF1yRabzgccKGWgCvLTMoq2AV2bCSYKrZsS7cpMGVfXNbomgWoElKSeMgcR4AYB7lX1mLNLpl0Nq3XLm3QE0y1pShHHHtlrCn7cemJtltsqKhugzBCQSNKZjxCAK8ScLmpWTVNSjzim26FTTiswykgBSTyEjSmyOtx7o2NaSdybcmUzKGgpypATXQKKaihGaGPiU0U2HMJV1yWEA98FIMLHoej74PeDn20wFI9coMWy1Zryytta079O9UUKBI7ytNYNb3XFsOzg2ZpU3RwkJyqCtm2u95Y+V8v2qk/7P+0evojf0cn8tz2RAfCz8NLPtCWL9mzcwmhKQHCSAocChQEcGzjgFuNc9U9PqlHVlG5BRdI1VvTlomvGfqhp9D3+oPeEK9lMUGFh/6gnx8/8AaiAl57Fu/ZrqWH25lxwpCjlUTQHYTqBXTYI73hwtk3JEztmuOU3PdUoWcyVppUjUVSaV8cD+PI99f7CPWqGtdHW77fgi/ZVAZjBEcpMdEHQd6OwgCvDA++0l87/qqNVRlHDE++sl89/qqNXQC4x8+Cv77f8AzGb40lj0PepXzzfrjN+WA4i9uF8JSXhDfrijpHqsueUw80+imZpaVprsqk1oYB69EQPzFjwgeyqPh0Oh/Npr55PsCPDbOItkWnLJZtBuYaIUFbwVooAioUNo1O0R1sPEKx7LYW3INzDpWrMc4pVVKCqlbB3hACtq3aXaFvTks24ltRccVmUCRpTTTvx7fyhO3bmkMF1L7LiQtTQzZKEkHLXrVaV00PDA/d6+q2LVVaLiAsuKWXEJ03q+BNeEaUrtpBzee9V37RcbemumkrQnLRKSKitaGla68UBc413Zl3ZFVoJQEPoCDmGhWlRAovjIrodukW2DPwK1/d9pUAmJeJ8vNyhk5RtwIUU5nFjKMqSCAkVqakDUx88L8TmZGW6Umm1lAUooWgA0CtSlSa8ddRxwAvhnaLzdpSzSHVpbXMDO2FEJVqRvgNDDP6IiccblGA24tAW4pKwlRAUnKdDTaOQwO2Zat2peZE00JrdEKzoQUqKArkHj4TFFivf5NplptltSGWiSCumZSiKVoNgA9cA17/8A7POeDNf6Qs+h9Pvi54Or2kxbXlxOk5iy1SSEPbqWUIBKQE1TlrrXZpAbhdedmzpxT74WUFpSN4ATUkHhPJAWuP3woPmEf8wt4MMULys2hOB9gLCA0lG/ABqCeInTWBFKYD22Kfzhj51v2hGgeiC+DE+EN+pcZ7s90IdbWRolxKjTbQEE+qGlihiTK2jJiXZQ6lYdSuq0gCgrXYTrrAMG5n7Ot+COepcJPB/4WlO+r2DBtdjFSUlrMblFsuuOIaUgig3NRNdK1qAQaVpHkuneG78o6JpDE2h4VypV7olBOhy0OvFUwFn0Qf6xZ/fV7SIKsdPglz5xr2hChxNvx+Un2ltNlttmuTMQVEkg5iBoNg0gzcxRkJ6UMtabDyagZi1qCRQhSaEFOvAYDp0Oh90nPkt+tUfWY0vcnvD7GPld6+9jWYhwyLM04tylc+labBUmgGvAIEbOvnW2Bacwk0zGqEakJy5EgVpWmlYAzx3T+fWbXUV2f1ogjx7cUmy96SKvNg0NKjXQ8kLTE6+7NoPSzsshaSxUndABU1SobCdNIMbQxLsq0JXcZ9p5FaEpSCaKHClST64Cu6HKm6TvyW/WuK68RpetHhDHspj4XCvrI2bNTi0NvmXdyBkUBWAmtc1TxmB+9F6Q9av5RlkkUW2tCVjWqABrTgNIBkdEaPzeU+dX7MW2AvwX/fc/1get3ESyLSYQ3PszCFJOYBArlVShooHUd8R1l8ULOkZTpezWHlEZindNAFHapRJJPeHFAJu0R7s784v2jHnpH0WsqJUdpJJPKdTHQwEA4YtbIt+alUrEs+40FaqCFUqRsrFYIlK6QGoMQ1lVgvqJqTLoJJ4TvSTCy6H0++Dvg59pMe68mKspMWYuSQ08HFMpbCiE5aimu2tNIEsML0tWdNLfeQtaVNFFEAVqSDwnZpAG99B/1TJf2fWqPV0Rv6OT+cc9kQH3gvqy/bEvaCEOBprc8yCBnOUkmmtOHjj7Yq37YtNDCWW3EFpaic4AqCANKEwB30PX6g94Qr2UxQ4YftDP/wB/7QRV4X4hy9myzjLzbq1KdKwUBJFKJHCRrpFLd++YlLVen0tFbbynKoJAWErVm72YUHJAWOPXwp/YR61Q1bl62A14Iv1Khe34vhY0+lTqpd8zIbKG1UygHXLmoqhAJ4o+t3sVJWXsxuTWy8VpZLZUAnLUg67a01gE82NB3o7R1A0EdwIAlwzPvrJfPD1GNXxk/DQe+klTtyfUY1hACWKF3np+RMuxlzlxCt+aCiTU6gGFD1FrT45fzivuRouJAZ1GC1p8cv5xX3I4OClpccv5xX3I0XEgM59RO0uyl/OK+5HIwUtLspbzivuRouJAZ06idpdlLecV9yOOolaXZS3nF/cjRkSAzp1ErS7KW84v7kQYJWl2ct5xf3I0XEgM6DBK0uzlvOL5uIcEbS7OW84vm40XEgM5HBC0uzlvOL5uODgfaXZy3nF83GjokBnHqIWn2Ut5xfNxBgfaXZy3nF83GjokBnNOCFpdnLecXzccjBC0uzlvOL5uNFxIDOvURtLs5bzjnNx2GClpD48t5xfNxoiJAZ46idpdslvOL5uOxwUtHtkt5xzm40LEgM9jBS0e2S3luc3E6ido9slvLc5uNCRIDPXURtHtst5bnNxz1EbR7bK+W5zcaEiQGejghaHbZXy3ObidQ+0O2S3luc3GhYkBnnqIWj22V8tzm44GB1o9tlfLc5uNDxIDO/UNtDtst5bnNxx1DbR7ZK+Nxzm40TEgM7DA60e2ytPluc3HPUOtHtsr5bnNxoiJAZ5GB1odslfLc5uO4wRtDtsr5bnNxoOJAZ+GCVodulvLc5uOOojaHbZXy3ObjQUSAz/1E7Q7bK+W5zccKwRtDt0r5bnNxoGJAZ8OB9odulfLd5uJ1D7Q7dK+U7zcaDiQGflYI2gR+llfKd5uOnUOtDt0r5TvNxoSJAJG6OD87KzsvMOPS5Q04FKCVOZiBXZVAFfHDuiRID//2Q=="
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="https://static.wixstatic.com/media/fc40e7_f494902d8405495b9c547370f2a53e0b~mv2.png" 
            alt="Vigo Tex Thailand" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAU4AAABaCAMAAADgvU9iAAAAbFBMVEX///8jHyAFBwiXlZd6eHiJh4enpaXx8fHNzc7T0tLDw8Pi4eGQjo5raWlmY2QxLS62tLU/PD03ODhdWlpPS0wVFxd1cXKsrK1XWVmCgIBHSEibm5slJic4NDW7vLxYVVbr6+tEQEDa2Njk5ORvMDOMAAANtElEQVR4nO2c6WKqOhCAQcCIlCIVl7q02r7/O95kJstkA8Rzbnuvzo8WQsxkPrJMJkCSPOUp/xVhfXJznp+y4rfIKu2TcwGAevM0ucjzgifZD5vz0/LZiypNP0WmgTzXRONsHrt9lgOk0vQ7GcSZLjTO9PjTFv2o1IM4q2QY59LgPP9g81xmLdSh+Kkh53uQ5q04RzbPyi6gyZZOBoYXKJg5pOT2uTldtaTAvFLJS0tRm5X9SqistYIB1UoKqur1XUkXx3lVedYRnOdBlEIcnFzWlZUBDUg7P6myzrVNTj9r1P2xcXKpmVsiVdKHM6ZaCWtoBYyaF5Ls4NyqPLsIznTey1GKjzNtrWFC3S0CWdq0DtnEOq+8FV7xcBJFASW9OIOqvQqivJv0u3COap4BnFb19HXSEVVtl/Rc/ki2zUzUdo6UmiqCUysKKenFGVRt5EqVkFt0F85RzRMsaTUoaFvUycpUYaQjKptaep6T7G1l5cRLS8ohs0wNKaHi4wyoNvJBadbkwn0422RYbJxy1CGzhOm7JlH3pcy1CX/emAaBcwLcHgunLCOLK6Hi4/RVE7Fc+O3RCJ1mLjfjTHc348Sam9kd3OEGenDh45TN2NiEzYz0CpyyVz7OpDFlBpUM4PRUG/lKRwgouhHniOYZxGnaCLSufG5nglOCw9jU9Wh1cLYGRFAJFQdnULWR7TDMT6wGSTl/SrnGcapJdTxO6K1k7ASjV8wmgTYAusqyCfOFW1gPzqCSHpwh1UYuwzT5IP3h4AyKi/N6I06cikz1AEEj52udjDbAtdqyadl3D22chHxYSR/OgGojFoBzS4W6o2wEzsopbbh5BhyltWmcuaxtJi2mOPHiktqEI1t4OnFw4iibxZX04QyoNhJx4V3SIxaZmXtzouuMHpy0co28JWRGMTbohq1tynRFB3AyuQos40p6cfqqtcRc+AGc7daRHFxnB+dg8wy0TrL6FqeNNki5cMoGoDf3cFr4QDLnXMm6R0kvTl+1litV4NzZMX5nEv9JOtw8Q6sibZEZzbAjMhsnazHRwcnG4kT/NKKkH6enWoml5bWHzTSc6ccInHoqWqFDLR1H0vsqmm6PlUWksw/ixFhLWIm5y20Qp6faIq9k5Wz/0EDTRJwDzdN1lMBpqQk2OTd0brrxMyt9jhs0yzE4OxUJDCsZxOmqljLKhb8HZ9iTi+G0pte1W1TqLkXQY9HnpYFnlUdwerUJKxnG6aiWkv91nJ834ZwbbIFhNXNwSidHn8MkbU0m9QDOiJJhnK5qEHb66zj7m2cPzswrSY4cxKZKe3lwXuiaWrR6cEaVUAnidFTHSovIyXHjx+PsbZ4uTgCCnd0PBAdWdtqA3NAjPOohnFElgzgd1SDnsTQbmPsm4RT7m2NxVqa74kCo/VYyLlrRd7UxRHpg2ikgciiL44wrGcbpqBa1fxkpc5wESErMP1++e9Lnyjtr9taYh+3UiYZ0rk16FZJbJsKSIlNNL44zrmQYp6P6V0jIjcedGHdawXFRLAvt6XRt2VQ2gQLjOONKqERwOqp/g4S23qCretEhTBAxINumpW1T2VqFrfM+nD1KqMRwOqqT5WtYcLT7sBP1aFmFfrKMl/b6GolKBHHKgBIMe9aKD1pSIO6QO02Erj3mkDmKs0fJGJyuahpJpwL3i7VOqto0CD6As4uXFo2Z+Tj1YoX5LmSueDg24fRFe1yGWeEhkLIHZ5+SUTgd1b04vTla3cY/ifN/JX04v30PX4bvnjgj0ocz9BDYF/zqiTMiPTgXoXR0YcpzQJ44ObOQl5am56/w6ktGL9kyIJcnTk7mxR8hTy+Mounei62m3rs1+cSZJBc3RJdfeCpTi/krkDBxZPA93G0iLmJUnYpzDqWv6SNNVQG7B4X6YUF9wVqVx4o15JIeh4nnrDMnQdTBHvIL56ouXZvaYrkr9Oozaykf+a2Qr1dySXrcqsyrcnHV+rS5BLGBsdNwVnpYMTvCxhOvdYLx9hROY9PcsxGWVvfh5MaWE3BSD1P+RDvXJhikmOfO3ifKcTJO7gm3WN8u7ZjildbCuSi5aZhWpI3xrSXOXOXKZb2NxVkLcYws8IRhqd320FVQJRedokJJFGfPc+JHbbd8SEuxI7GVpUFzdGlJB38Szs48e1pLS7O0VT9gHaYVadF0Jp8MhKjFdtlACrGR36TqXpyibss/gVOjI7EAptI+AyFNzDcFZ0YHxRZaICMNUax0V2BjlunaIM6WWJTBPaE25uJn9+KEHPfj1LxeSCbTEt89XBfIMQXnmsZzMrm9SyM6KzCf48S2IgRwLq2wZOs2xuJP4ASS9+PUj8qTkDt54NnbrpOzxBScDX0oiEHQorV3F9omQZyV6u6A0zZoXjg4134elB9onWYeN7ErNZe1geUnrj2n4CzNyKmlseNjtWiUAqdutoCz9rf0iI3LPzAViRtbTsC5MCugThquUnRvv6gGuzITlRL17MgEnCs/lO0SBvMAp+rugLPzd8i0jdxN9hwl1TAoTv9qYs/sdTLCUbKfwqnsxraFWuoVu/StL4qvMNV9fVM1k0k4vYdbS+epq0LUAXGWOF5KnN7DRMTG2ttavgGnljWp4jicF39eeWcJ6dAizP591KtM0a+d5byeEv5665TdPd46jTiOKC1+sLOjNMVKVnF0Z2cvoRhIk7FQtBNQi19d7TT9QsHfHjsT2d2Hx848dR1RonH82AlyA86eAF1gv1xNTfbm/HmwtNEzewUt3ZnZGzWzI4wuOLO7bmYNh78IJ3sLpONrq00gra+00X4nQisifqfMUgT8TgYtmtg4hzJ+Ec7QNRmes9KILzVtVWSoVA0UxhrynpVZFcmELi3VqsiEoHKXHt6E34Qz8P0F+WC5lVYMl9a7Zm/16Fl1OjIUWLOr6vNWWcuBsVF2y3ti+Z2/Dqe3JST9S/vFme/h0npxljKiJEKqZlGe5qIKFYko6eqL4FIpc0FEab6WTzoQG0tvEW+u/BBO7/Ut2QWtrfHtiNL6453msQ264lai453mYqvK04td+Qo8sZGlOJgSkdfCfqe72g/hpJnDv2VlWFjoqhrQrFb7RTUPfRMoIpkVUwfxo/HG3qW+PaUTxs9Npq6Y//s4Jwl9yNz3Gh9dvlYBkS7yt5V4wUT6ujZ1pctQQUIeZ+NNSBZaAGEDth9Tkh4mGSIPpJhF5Llw2Bh9JPkOPfCBA5L18IKcdshWEXlh/Su8ZZ9uL/++QT8ty4PPwQnMp/o5PRMdJV/7+A4/Fr7+Cmh7ADn6jQvfV6PhowukePueSfADMVyuA6+8/Y/Fe3xBzjNfZEhEOjqkdzKDYugLds2IT6ssZkIOC3U02/PEAg/f+OHxxP8fE4Ypsw3NtsFD3ovYnv+HEKc50ld3WBgZl3YHXhIuGRYHlZ9n+xB/hdakQLVUmzycsd1MJeqkoGml28JOsMtOtoExNq+5m9eLQ4NvMWYGkjU6mermFOcRj44eTpHN4HzT+M2Rg3M2048MyAQxjX5ITQxS3xTOHJMLqu1mnLwwZwBsYOQzr9mhl6kXS3p96Yeg0zr+/LaN8028K8YbxgJbo/hbQHMQcuAm8dMDgmfqB5htowh9CB7sjRdijszVHZR2mGkv5DSrhR8iMp1mB5Ys3gQuQemIOBfiiOvYUG0LfqqkwDZMk4Li7vlCaEdvE8nXp9RWkd6D8B9j+Ox7lcjDmex5I1I1P9g49W1xcB5snIV75OKstOkfoi+oMk/632522JwQZzGrdQatbQpOPlTar3yeRQs0X0oF29Q4qbxz70Oq7fAXVYxBpnVid17ozl7Izr4vLJw620b2f+ziJ/h4nznSVxEnP5d98qhh8Ut4KK7xbMWsAJz17Kirp7WRYdTgNElRsT4wmLaXhHRvGM/lEKveDXTfE29uWcJ6Y+emojiTHQxjtY+zojiT/CDTzNEEnMlpcwzjrKbjdJ755IOLeTwR9smueCydINd9f7/cQNOa2UUV5WBp1bAAElZnh2ybGR1S+Byd0yOnsy90F/9AFm/QI2hn33PSJ+zs8BWhzYZqm9bZQaxlkgg4qsURRGlx10NG5h33vecNoqBgfc0RDFsG50bM24vNJnFwQjYNDOeqPTfaHDk42cG0yRPqOCXOVLSHsUJPRQeYu7W2O3DyHnw1iESvVgFIYRE2R3Qq2ZXC7Po/BRAQH+ded3aOT3osVmfX2TbKiWEb1SXNkbkqHZuNdmek9yV6l+Uo7eFcFF/jCMSoNuUV7RK3s89GfBuOLpNEFF4OmOKOwwGuLxl1389jih3AKR0lhRP86Y09FRFHSQJLqr0cMciRg/NABgbhxku3nrrxokvsjRt/qCxtd+JMLiYYv9UfuTiqrSKcb8jjNQ8XOLpZzDIpV85lLbeKcH1J1qWPGDi6WXaqxxfS3TzLrSJYX5JH+x8rQjxZ9DLpJfkGtBfcKhITuA4jP3Dg6GZRy6Qj4vsAp0lMtcp9bx77g/s3i1wm7SBuVMBWEZ8mS+nrjwocPYWIXCatxOJoLZbon/qzNyMDR0+xpAKPaMn790lsFX0kF/wGydjA0VMcEcuk04JPTF9Hvr6EvYwbAkdP8YQvk5rFNZ2/8PXl+sbA0VN84cukZpXmRcO28kXYp9wli+5cHPKXl/T1Qfd7/7TMu26bHW4OHD0lIix7nxA4espTnvKD8g+iQMk32q5PCwAAAABJRU5ErkJggg==" 
            alt="Bangpa-in Concrete Pile" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8SDxUQEBIQFhUREBUVGRgWFxUWFRcTFxcXFxgWGRkYHikgGBolHRUWITEiJSotLi4uFx8zODMtOCgtLi0BCgoKDg0OGxAQGi0lICYtMC0vLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAM8A9AMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcBAgj/xABMEAABAwIDBAQFEQYEBwEAAAABAAIDBBEFEiEGEzFBIlFhcQcyUoGRFCMzNUJTVGJyc4KSk6Gys9M0Q3SiscEVFmODJGSUwsPR0kT/xAAaAQEBAAMBAQAAAAAAAAAAAAAAAwIEBQEG/8QAMhEAAgECBAIIBgIDAQAAAAAAAAECAxEEEiExUZETIjIzQWFx4QWBobHR8BTBI0JSFf/aAAwDAQACEQMRAD8A7igCAIAgCAIAgCAIAgCAIDwlAQ1VtVQRuyGoY549xHeV/wBWMEqqoVHrYlKvBeJG123tLEQ10VZmf4rTEWOd3NeQ4+hVjg5y8VzIyxcI6WfI15fCJAy28pa6ME2u+MNHpc4BZLBSe0lzPHjIreL5Em3a+msDIyqjBF8z4JcluvO0Ftu26l/Hl4NcyixEfG/IksOxmlqPYJ4pOxrgSO8cQpypzj2kVjUjLZm+sDMIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAID4mla1pc4hrWi5JIAA6yTwRJvRHjdtSvf47PUnLh8Qczh6omzNh/22jpTd4s3tV+ijDvH8lv7EekcuwvmfTdlWydKummqj5LjkgHdCyzSPlZj2o6+XSCt9+YVG/bd/sY62UtkGH4cyKJ+UOke1jQyniPA5Ro6R2uVp00udOPsVddJU14eZ43rkprX7Eng2BwUwO7aS92r5XnPNIet7zqe7gOQClOrKe/IpCnGHqSL2AgggEHiDqCsLlGrlZqsLkoiaihaTFxlpR4jhzkgH7uQcco6LuoHVbEZqp1Z7+D/ACa8oOn1obcDdfhmH10bJzFFIHtDmyAZXgHqe2zmnuKwz1Kby3MslOor2Nc4VW0+tJUGVg/c1RL9Opkw6bfpZll0kJ9tW81+DzJOPZd/Jmzhm0Eckm4lY+Ce3sUlru7Y3DoyDuN+sBYzotLMtVxMo1U3lejJpSKhAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAaOL4pFTRbyUm1w1rWi73vPBjGjVzj1LOFNzdkYTmoK7IenwearcJsQADAQY6UG8bep0xHssnZ4o6jxVXUVNWp78fxwRLo3N3nyLK0ACw5LXNgj8fxMU1O6XLmcLNYzm+V5DY2DvcQPSs6UM8spOpPJG58bO4UaeGzznlkcZJn+XK7xj8kcAOQAXtWpnlpt4CnDKvMlFMoEB4gK3TD1HXbrhBXOc5g5R1QGZ7B1CRoLgPKa7rWw/8AJTv4x+3sa6/xzt4P7llWubBpYphcNRHu5mBzb3HJzXcnNcNWuHWFlCcoO6MJQUlqQsddPQuEdW90tO4hrKk+PGTwZUW0tyEg067cTbLGrrDR8Px+CWZ09JbcfyWYG61zYPUAQBAEAQBAEAQBAEAQBAEAQBAEAQGrieIRU8L55nZWRtuTxPYAObibADmSFlCDnLKjGUlFXZEYLh0ssgrqxtpSDuojqKeM8u2UjxneYaDWtSaiskNvF8fYlCDbzz+RYFAueoCuVI9UYmyPjHQx753UaiW7Yh9Fm8d9JquupSb8Xp8vEg+tVt4LX5liCgXPUAQBARO0+HOnpXsj0lbaSI+TPGc8Z+sAD2EqlGeWab22foSqwzRdjZwXEG1FPHO0WEsbXW5gkatPaDceZY1IZJOJlTlmimbqxMzHNC17Sx7Q5rgQQRcEHiCOYXqdndHjSasyt0UjqCZtLISaWZ2WB7jcxSHhTvJ4tPuCerL1K7SqxzLdb+fn+SCbpuz28PwWha5sBAEAQBAEAQBAEAQBAEAQBAEAQHhQFaaPVtaXHWnoZLNHKWrHF3a2O9h8YnyVsP8AxQ839F7mv3k/JfV+xZQtc2D1AeONtUBAbGNzwPqjxrJ3zf7d8kQ+zYz0q9fSSjwVvyQoLRy4ssCgXCAIAgCAr+zI3U1VSco598wf6dQM/wB0m9CvW60Yz8rciFLqylDz+5YFAuEBqYnQR1EL4JRdkjbHrHMEHkQbEHkQFlCbi8yMZxUlZkdszXSEPpag3npSGOPvkZF45h8oDX4zXBUrRWko7P8AbE6UnrGW6JxRLBAEAQBAEAQBAEAQBAEAQBAEBE7T4g+GmcYtZZC2KIdc0hyt8wvmPY0qtGClLXbdkq0nGOm+yNnBsOZT08cDOEbbXPFzuLnHtJJJ71jUm5ycmZU4KMUkbqwMwgIja6pMdBO9vjbpzW/Lf0G/e4KtGOaokyVZ2g7G9h1K2KGOJvCONrB3NAH9lhOWaTZnBWikbKxMggCAIAgICq9bxWF3KppZIj2vic2Rn3OkVo60WuD+5B6VU+KJ9RLhAEBXNpRuJoa8aCNwhm7aeVwAcfkPyu7i5XpddOn816+5Cr1ZKfP0LGoFwgCAIAgCAIAgCAIAgCAIAgCAr1b69ikMfuaSB9QfnZLxRehu+PoV49Wi3x0/t/0Ql1qqXDUzHa3DQbGrp9DbxwvP41V/6s9/kUl/sh/m7DfhdN9dq9/jVf8Alj+RS/6Q/wA3Yb8LpvrtT+NV/wCWefyaX/SNHaDEIKmGnbDIyRk2IQMJabj1t2+cPRH96ypRlCTzK1kzGpKM4qz3ZaFrGyaGI43S07g2eeKMuFwHuAJHC4uqQpTn2VcnOrCHadjFSbSUMrxHFUwPe46Na8EmwvoO4FeyoVIq7TPI16cnZNEm51hc8AL+ZS3KXsQw2vw34ZTfXar/AMar/wAsl/Ipf9IkqCuinZvIXsewkjM03FxodVKUJQdpKxSM1JXTInanoyUc3vdcxvmlY+L+rwq0dpLyJVt4vzJ66gXITFdraCncWTTsDxxa0F7h3hoNvOr08NVqK8UQqYmnDtMxUe22GSuDW1LATwzhzLnveAF7LCVo6uJ5HFUpaKRL4jRsngkhfq2aNzD3OBH91GEnGSfAtKOaLRo7JVj5aKJ0h9cYDFJ87ETG/wBJaT51nXjlm7bb8zCjK8FcmFIqEAQBAEAQBAEAQBAEAQBACgK/s906qum/5hkI+TDE3/uker1dIQj5X+pCnrOT87HGajAa0vcRS1Wr3fupOs9i7scRTyrrLmcGdCo5NqL5EW9hBLSCCCQQdCCNCD1FXTvqiDTTszbpsIqpGh8dPO9pvZzY3uabGxsQLHUEeZTlWpxdnJczONGpJXSZ0DYyklY2hiljex3q+pkyvaWmzactBseV3rl4qalKbT8F9zrYWEowgmras6cuYdM5N4Zf2mD5h3412fhnZl6nG+KdqJX/AAe+2tN8t/5b1sY7uJGrgu/id0q/Y3/Id/Qr5+HaR9DPss/NDOA7gvqlsfKvc7b4Kvatnzsv4yuDj+/Z38B3KJHbcf8AB5ve6mlf9WojJ+66jhu3byf2LYjsfNEd4S9oH0tKGQm0s7i0OHFrALucO3UAd9+SrgqCq1NdkRxtd0oabs5BhOGT1MwhgaXvdc8bWHNzieA149vau3UqQpRvLY4lOnKrKy3JXFNiMSgaXPgLmgamMh9h3Dpfco08bRnpfmXngq0NbHa8CfmpIHdcEZ/kC4NRddnepvqojtnBkqK2Hk2qEo7po2OP8wes6usYvy+xOlpKS8ywKJcIAgCAIAgCAIAgCAIAgCAICA2O9ind5VfVH0SuaPuaFevuvRfYhh9n6sn1AufnHG/2uf8AiZvzHL6ej3cfRHy9fvJep2XwZe1MHfN+dIuHju/l8vsju4HuI/vibWK+2dEP9OrPobEP7qUO6l8ik+9j8yeUS5ybwy/tMHzDvxrs/DOzL1OP8U7USv8Ag99tab5b/wAt62Mb3EjUwXfRO6VZ9bf8h39CuBDtI+gm1lZ+aGcB3BfUrY+We523wU+1bPnZfxlcDH98zv4DuUSO3ftbOepjT6HtP9lHDd6i9fu2Uvwzxuz0zvc5ZR57sP8AT+i6HwxrrI53xNPqsr/g8x2OkrM02kcrN2XeQbghx+LcWPffktnG0XUp9XdGtgaypVOtszuDHhwBBBBFwRqCDzC4GqO/o9T6a23BD0gcP0xWqHlU1K7z3nb/AGCvLuY+r/ohHvZeiJ9QLhAEAQBAEAQBAEAQBAEAQBAQGx+kdQzmzEKkfWkLx9zwr190/JEKGifqyfUC5+cMb/a5/wCJm/Mcvp6Pdx9D5ev3kvU7N4MvamDvm/OkXDx3fy+X2O7ge4j++JtYt7ZUR+JVN9LYz/2qUO6l8is+8j8yeUSxybwy/tMHzDvxrs/DOzL1OP8AFO1E58HW1vb7l0mrnKV76D1R8c/WWOWHAzzT8zxZmB2zwU+1bPnZfxlfP4/vmfQYDuUSO3XtdMPKaxvpe0f3UcP3iL1+7Zn2owCOtpzDIS0g5mOGpa8aA25jUgjqKUK0qU8yPK1FVYZWcOx/Aqijl3U7bX8VwuWPHW0/1HEL6CjXhVjePucCvh50naRu7NbX1dEQGOzxX1ieej9E8WHu07Cp18JTq67PiUoYudLTdHbcDxaKqp2TxHovHA8WuGhae0FcCrTdOTjI71KoqkVJEfh2uKVZ5NgpWef11/8AR4VJ91H1ZhHvZeiJ9QLhAEAQBAEAQBAEAQBAEAQHhQEBgfQrq2Hynw1A7pI92f5oT6VeprTi/l+8yFPScl8yfUC5+ccb/a5/4mb8xy+no93H0Pl6/eS9Ts3gy9qYO+b86RcPHd/L5fY7uB7iPz+5tbQnLV0D/wDmpGfXp5bfe0KdLsTXl/ZSr2oepPKBc5N4Zf2mD5h3412fhnZl6nH+KdqJXdgGA4pTggEF79DqPY3rZxvcs1MEr1kdzfRxWPrcfDyW/wDpfPqT4n0DhG2x+bn8T3lfUR2R8vPtM7V4Kfatnzsv4yuDj++Z3sB3KJHbY3pWs98q6VnpqI7/AHAqWH7d+Cf2LYjs/NE8oFzUxTDYaiIwzsD2O5HkeRB4gjrCyhUlB5oswnTjNZZI4DtFhnqWrlps2YRPsDzLSA5t+2zhftX0lCp0lNS4nzeIp9HUceB0DwMVDiypjPitfG4djnBwP4Grm/E49aLOn8Mk8rRatlunJWVHKWtc0fJha2H8THrSraKMfL76m7R1cpeZYFAuEAQBAEAQBAEAQBAEAQBAEBXsYO5xClqfczB9I/qu/wBchJ+kxzf9xXp9anKPDX8kJ9WopcdPwWBQLn5yxv8Aa5/4mb8xy+no93H0Pl63eS9Ts3gy9qYO+b86RcPHd/L5fZHdwPcR/fE2ds+jDFN7xW07/omQRu/lkKnQ1k1xTKV9Ip+aJ5QLnJvDL+0wfMO/Gux8M7MvU4/xTtRK/wCD321pvlv/AC3rZxvcSNTA9/E7w/ge5fPI+iex+Z38T3lfVR7KPlZ9pnavBT7Vs+dl/GVwcf3zO9gO5RI7S9Keih8qs3h+TFFI+/1sijS0jJ+X3LVe1FeZG+E+vngpI5YJHxubUNF2niCx+hB0cOGhVsDCE6mWSvoRx05Qp5ou2pSmeE7ERHlIpy61s5Y7N32Dst/N5l0P/NpXvdmh/wClUtayKdVVD5HukkcXPe4uc48STzW9GKhHKtkaEpOcrvc61sjRnDcJlqZWkSPaZcp8bhaKO3lE20632XExM+nrqK22/J3MNT6Cjd7/ALYtWzeHmnpIoXG7mxjOeuR3SefO4uK1K0883I26UMsEiTUygQBAEAQBAEAQBAEAQBAEAQEfj+GipppIb5S5t2u5skaQ5j/M4NPmWdKeSSZhUjmi0fGz2JGop2yOGWQEskb5EzDle30jTsIXtWGSVkeU55o3ZAVPg3oHyOkcZ7yPc82eLXcS4+56ytmOPqxSSsa0sBSk22WTBMKjpYG08WbIzNbMbnpOLjc97itWpUdSTlI2adONOOWOxi2lojNRTxDi+F4b8u12n0gL2lLLNMVY5oNGXBa0T00Mw/ewsf5y0E/evKkcs2uDPacs0EyN2i2Rpa17XzmW7GloyODRYm+uhVaOJnRTUSVbDQrO8jVwnYGipp2VERmzxkkZngjUFuot1ErOpjatSLjKxhTwVKnJSiWkjRahtWuUs+DHDuuo+uP/AJW8viFbyNN/D6L11LJgWDxUkAghzZA5x6RubuNzrZatWrKpLNI2aVKNOOWOxoO9cxZo5UtGSflzvAHnyxH0rPaj6v7GG9X0X3JPF8Kgqot1UMD2XBtcixHAgtIIOqnTqSpvNF2KVKcaitJFVn8F+HOPRdUs7GvB/G0lba+I1lwZpy+HUXxN/BNg8PpniRrHSPabh0pzWPWGgBt+211OrjKtRWb08itLB0qbulr5mTFv+JrYqQax05bUz9RcD6xGe9wzkdUY61jT6kHPxei/syn15qHgtX/RZFrmwEAQBAEAQBAEAQBAEAQBAEAQHhQFaxM+oqr1Z/8AnqC1lR1RyDox1HdwY7synkVsQ/yRyeK2/Bry/wAcs3g9/wAllBWubB6gPCgIDZI7vf0Z401Q7L8zL67H5hmc36CvX1tPivqtCFHS8ODLAoFwgCAIAgK/skd5v6z4VUOLPmYvWo/Mcpd9JXr6WhwX13IUdbz4ssCgXCAjcexVtNDvCC57nBkcY8aSV3isHf18gCeSzp03N28PEnUnkRj2dwt0ERMpDppnmWZ44GR3IfFaAGjsaFlVnmemy0QpQyrXd7kspFAgCAIAgCAIAgCAIAgCAIAgCAIDHPC17Sx4DmuaWkEXBaRYgjmLIm07o8aTVmVqiqHYfI2lnJNM85YJnG+7J4U8p5dTXHiNDrx2JLpVmjv4r+yEX0byvbwf9FoWubB6gK5jB9T10FXwjnApZeoEnNA8/TzM/wB0K9Pr03DxWq/shPqzUuOjLEFAueoAgCAg9rqx7KfdRH16qeKeLsc++Z/cxge/6KtQinK72WrJVpNRst2SlBSMhiZCwWbExrGj4rRYf0U5ycpOTM4xypJGwsTI1MUxGKnidNM4Na3zkk8GtA1c4nQAalZQg5OyMZSUVdkTg9DLNMK6rbleARBCddxG7i53LfOHE8hoOd6zkorJH5vj7EoRcnnl8vIsKgXCAIAgCAIAgCAIAgCAIAgCAIAgCAIDDV00crHRyNa5j2kOa4XBB5EL1Np3R40mrMrrfVOH6WkqKQcLXfUQDqI4zRj6wHWr9Wt5S+j/AAQ61Lzj9UT+H18M8YlhkZIx3BzSCO7sPYoyhKLtJFoyUldHzitBHUQPgk8WRpabcR1OHUQbEHrCQm4SUkJxUo2ZH7NYi97XU1QR6oprNk5Z2+4mb8V4F+w3HJUrQSeaOz/bE6Um1lluibUSwQHy9wAJJAAFyTwAQMruCXq6k159ija6KmB5tJ9cn+nYBvxRf3S2Kn+OPR+Pj+DXh1553t4fksi1zYIjGMfigcImh0s7x0YY7GQ/GPJjPjOsFWFKUlmei4kp1VHRavga2HYNK+UVVcWvlb7HG3WGAHyb+PJ1vPcLBZTqJLJT2+r/AHgeRptvNPf7FgUCwQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQHhQEJXbNxukM9O99NO7Uvitlef8AVjPRk7yL9qtGs7ZZaolKkr3jozCMRxCDSophO0fvKY9K3W6F5uPoly9yU5dl28n+THPUj2lf0I7FMUop3slhqWU9XDfIZg6IkHjFIySxdGezgdQqQp1IXTjePlr80TnOEtU7PzJCg2tgNmVWWnl6nuBif2xy+K8eg9YWEsPLeGqM44iO0tGb9XtDRRtzPqIB1We0k9wGpPcpxo1JbJmbrU1uyAxHEBV6VD20tENXCVwjmqB5JaTeOLrv0ncNBxvGDp9nWX0XuRlPPu7R+5IN2qpiAykjmqLCwEEZ3YA0A3jrRgedT6CW83b1/blOnjtHX0BpsSqfZXspIz7mE7ycjqMhGVn0QT2pelDZZn57C1Se+i+pJ4Tg9PTNLYWBuY3c4kue93lPe7pOPeVOdSU+0UjCMdiQWBmEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEB4UBjqKeN4yyMY4dTgHD0FeqTWx44p7oiJdkMNdxo6cX8lgb+GyqsTVX+zIvD0n/qjEzYjCwbili/mP8AdZPF1v8Ao8/i0f8Ak3KTZugiN46WmaesRszem11N1qj0cnzM1RgtoolAFMoeoehAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQFO2jwnGZKlz6SrjjhLW2aSbggdI+xnn2rco1KEY2nG7NOvCu5XhKyKhsxVY3Xbzc1obuct89hfNmtbLGfJK3K8cNRteG/7xNOhLE1b2lsSm3OJ4jR01Gz1QRK4SiV7MpDyCyx6TeWbqClhadKrOby6eBXFVatKMFfXxOi1LiInEcRG437bLmpdax0W+rco/g32gqJaOpnqpHy7k31AvlEeYgWAW/jaEY1IxgrXNLB1pShKUvAisFmxnFBJPHWMgY1+UMabWNgQLNF7WI1J110VascPh7RlG7I0pV8ReUZWRNbE4tiQqpKKvY92QOyzZDlu0jo5wAHAg3B46G/ZDE06ORVKb+RfDVK2dwqL5l5WgbxzH/FcTxKtmhpahtPHA4i3BxAcW30Bc4kjsAuPP1eio0KalON2zl9LWr1HGDskbWC1+L0le2kq89RFJYbxrHODc1w12cN01FiHcOPfhUhQqUs8NGvAzpzr06uSeq4nRAuadEqPhA2qdRsZFAA6ea+W4uGtFhmt7pxJAA7+qx3cJhlVbctkaeLxLpJKO7INuB7RmPferAJLZt1mF/k+JkzdnDtV+lwl8uTTiQ6LFWzZteBNbAbVyVYfBUtDZ4ONhbM2+Ukt9y4HQjtHcIYvDKlaUdUy2ExDqXjLdFxWmbpyuor8VqMVqKSlq8gY57gHWDQ1uUWuGE+6XWUKEKEak43OU6ledeUISsTuEYNjrKiN9RWxPia+72gm7m2Og9aHZzWvUq4ZwahFp/vmXp0sQpJzldF3Wibxz7aSgxyM1FTHWxthZvJWsv0hG0FwbrHa9h1+ddCjPDvLFw12/dTn144hOUoy0IjZ0Y9WwmaGua1oeWWfYHMAD7mMi3SCvX/jUZZZQ/eZCh/JqxzRkdTpWuEbQ83cGAOPW62p9K5LtfQ60dtTKvD0IAgCAIAgCAIAgCA+XcD3Ijx7HM/Axxq++H/yrp/Ev9PQ5vw7efqe+GnhS983/iXvwz/b5f2efE9o+pnn2VxkMcTibiAwki8motwWKxGHv3Zm8PXy94YfBJPEyiqnylrYxIC4u8UNyC9+xZfEU3UiluY/DmlTlfiYBsKH3qcIrbNLiAMzxYg6tEjNSB2jzle/zLdSvEx/h361GRu7IbQ18df/AIbXnO4g5XGxcCG5x0h4zS0HjrdYYihTlS6WloZ4evUjV6KodEJXNOic2xDZOkrp5KnDKxjZA7M8NJLQ91zmDm6tvYnnzXThiZ0YqFWOhzZ4WFWWalKzNaixnFMOrIqatfvY5nNAJdn6JcG5mvIDrgkXDllKlRr03OmrNGEatahUUKmqZ1Nco6xy7b0hmOUj5PEtT6ngLTPv6Lgrq4TXDTS3OVitMTBvY6iuUdQ5fsg4P2hqnx+L6/cjh47B97l1cRphIp76HLw+uLk1sdRXKOqcc9R1UuOVTKSYQyZpDmN/EBZdugPWPQu1nhHCxc1dHFyTliZKDsy7bM4PisNRnq6xsse7cMoJ8cltjq0cLH0rn1qtGUbQjZnQo060ZXnK6LatU2iJ2s9r6r+Em/Lcq0O8j6olX7uXoVzwQe17/wCJf+CNbPxHvvkavw7uvmXlaJvhAEAQBAEAQBAEAQBAeO4IeMp3g92XqKEz750R327tkJPi573uB5QW5i8RGtlyrY1MLh5UnK/iPCHsvUV243Lohut5fOXDxslrWB8kphMRGjmutxi8PKtls9i2TxkxuaOJYR5yLLUT1ubTWlipbD7JSUtLPT1W6cJzYhhcRkLMpBuAtvFYlVJqUdLGrhsM6cHGXiQ1NshjFG57aCpjMT3Xs+wPUCWlpGa1hcWvZXeKoVkuljqa6wtek2qUtCV2S2NniqnV1bM2Scg2y3IBIylxcQLnL0QAAAPNaWIxUZw6OmrIth8LKM+kqO7LstE3jndXsVX09S+owudjBISSx2lrm+XVpa5t+FwCF0Y4unOChWV7HNlhKkJudJ2ufeGbF1stWyrxOdjzEQWsbrctN2jgA1oOtgNUni6cYOFGNrnsMJUlNTqu9joK5p0Sv7Y7LRV8Qa45JI7lj7Xtfi0jm02HoC2cPiJUZXWxr4jDqtGz3KqNndoRH6nFXHu7Zb5zmy8LZsmf71t9Phb5smpqdBirZc2hZ9jNlI6CMgOzySWzvtYWHBrRyaLnvutTE4l1pcEbWGwyoriyyLXNkpuD7L1EWLzVznRbuUSAAE5+kWEXFre5PNbtTERlQVNbo0qeHlGu6j2ZclpG6EBo45SOmpZoWWzSwSMF+GZzS0X7NVnTkozUn4MnUi5QcURGwWBTUVK6GYsLjM5/QJIsWtHMDXolWxdaNapmiSwtF0oZWWVaxshAEAQBAEAQBAEAQBAReIS14ktBFSuZYaySyMdfno2Nwt51SKptdZvl7k5OpfqpGtv8V+D0P28v6Kyy0uL5e5herwXP2G/xb4PQ/by/oplpcXy9xetwXP2G/wAW+D0P28v6KZaXF8vcXrcFz9hv8W94oft5f0UtS4vl7i9bgufsN/i3weh+3l/RS1Li+XuL1uC5+w3+LfB6H7eX9FLUuL5e4zVuC5+w3+Le8UP28v6KWpcXy9xetwXP2G/xb4PQ/by/opalxfL3F63Bc/Yb/Fvg9D9vL+ilqXF8vcXrcFz9hv8AFveKH7eX9FLUuL5e4vW4Ln7Df4t7xQ/by/oplpcXy9xetwXP2G/xb4PQ/by/oplpcXy9xmrcFz9hv8W94oft5f0UtS4vl7i9bgufsN/i3vFD9vL+ilqXF8vcXrcFz9hv8V+D0P28v6KZaXF8vcXrcFz9hv8AFveKH/qJf0UtS4vl7i9bgufsN/i3vFD/ANRL+ilqXF8vcXrcFz9hv8W94oft5f0Uy0uL5e4vW4Ln7Df4r7xQ/by/opalxfL3Pb1eC5+xL0bpTG0zNY19ukGOLmg35EgE6dik7X0KxvbUzLw9CAIAgCAIAgCAIAgITHKuriezdGnySysiAex5cHOv0iQ8AjThZVpxg073JTc01axpVWOTMndC+ooIjHHG4mUOGdz81y0GQWaMo6+KzVKLipWZg6rUsraNsVtZNJI2nNO1sDmsc6Rr3byXI17mtDXDdtAc0Zjm1J001wywilmvqZZpyby20JHCa7fwtlylpNw5pN8r2ktc2/OzmkXWE45XYzhLMrkFUbWxspql7pKcTQPqWtjLwC7dOe1l23zXcGjh16K0aDcorWzsReISi290bxrauWWVtNuGsgeGEyh7jJJla9wblcMjRmAzHNrfTTXDLGKWbxM88pPq20NSDagumhDow2KSMZ3X1inMjog08i3Owsv1lvI6ZOj1W763PFW6yRkGNzyOEMQiEr5akZn5ixkNPJkLy0EF7iXRjLdvjE30snRJLM9tObHSN6Lc38GrJZM7ZTC4scAHxOBY9pF75cxLDe4sSeFwTynOKW31M4Sb3+hp43jEkc7YWyU8IMYeJJw4se4uI3bbOaA4WBJJPjCwOqzhTTjd3foYzm07L6mGtx+eNri6NjXNomTlubMBIX5S3M02c3qK9VJPZ+LR46jXh4EpjFe6JrGxtDpJ5REwOJDcxa55c4jWwax7u21uanCGZu+yM5zypW3ZF4hjNVTNlbNuHvFLLPG9jXsY4xWzMewucW2zsNw7UE8La1hSjNq3GxOVSUF1uFz2v2ie2mhkYxpklkDXNJNmZXZZr28k3aO0heRopzab0/bCVZqCaWpNYlWNhhkmffLFG55txIaCbDt0UoxcpJItKSim2RlPXVjZIxP6lIlIvGwlskQIJBzPd68LjKbNadbgGyzcYWdrk1KV1exH0u0k5DHl1I7eVAi3LMwnAMu7zDpG+UXedODTwVHSim1r6+Bh0z303+ZtnE6x8b6mFsJijL8sbg7eytjJBcH5g2MnKcoLTyuRfTDJBPK73+iMs82nJbG9hWKb58oFsjN0WHW5bJE2S5+ssZ08qX74mcZ3uQtHtHUSiIh1JFvKGGodvM1s0heC1vTFgMvbxVXRjG+71sSVVytttcsGB15qKaOctDTIy9gbjqu02F2m1weYIUakcsmi0JZopm8sDMIAgCAIAgCAIAgCA0cUoTLu7OA3c7JeF7ht9Ozisoyy381YxlG9jSqcMqfVEk0MlOBKyMESRueQWZtQWvHHN9yzU45VFp8ybhLM2rA4bVMfI+nlhG/s54exzg2UNawvZZ40Ia3onmOOpTPFpKS2GSSvl8SQwuhEELYgS7KDdxtdziS5zjbmXEnzrCcszuUhHKrEbLgF6Oopszc1Q6pIfl8Xfue4aX1tm69bclRVuvGXC30JdD1HHjc+5MNqWSSuppYmidwe4SMc/JJlawvZlcLghreieYJvqvM8WlmWx7kkm8r3Pml2djbdrjnY6l3Lg4dJxL3Pe8kcyXk6c0lVb53PVSS5WNek2dmiZG5k7XTRPn6b2dGSOZ4e5j2tI16LDmHNt7WJCylWUm9NHb6GEaLilZ6o28Ewl8Mksj3REzBnRjj3bGZM2gFzfxhqed+wDCpUzJJeHEzpwcW2/EyYhR1BkL4pIsrmBro5ml7Lgkh7bEWOtiNb2HC2vkZRSs+aE4ybuvqRf+VHCExNlbrSCAEs0Dt4ZLhodozpWDb6AAXVen612vG/0sY9DpZPwsbtRhlXKAZZYA+J7ZInMieMsgDmnOHSHM0tc5pAsbOOvBYKcI7LTx1PXCUlq9VsYa7AZqhspnljzvpZII8jHBkbZLZ3G7rvcS1nVYNtzJWUaqg1lXjc8lSc08z8LHtTs3mkmeJLCXLkbl0jJex8p465zG09h70VaySt++wdG7bvuTNfSMmifC++WVjmOtobOFjb0qMZOLzIrKKkrMhH4JUvfE6aWA7iRjszYrSyBh0DnFxy6X8XiddBobdLFJpLfzI9FJtXe3MyM2dAp44wWCSOoZKJMmvRm3hbxvq3Mzj7o9y8dZuTfgZdF1bLc8fg1SGPp4p42wyOfqWEzRtkJL2sObKfGdlJHRuNHWTpI3UmtfoHTlayeh9uwmeOR7qSSFjZWMaWyMc/I6NuRrm5XC/RAGU+TxTpItLMtg6ck3le55h2zUUTmXyyMio4adoe0OPrRec9zprmGgHJeSrNp28XcRpJP5WJ0C2gUix6gCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAID/9k=" 
            alt="THS Development" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="https://www.jobbkk.com/upload/employer/01/371/00E371/images/58225.webp" 
            alt="Siam System Built Co., Ltd." 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAABHVBMVEX////OISfOISbOICnMISf9/f/cqaz/9PLICg3WnZ7FDRi5RknLHCTrzcrDBRgAAAD09PT///z6//8gHB08OjsXERMiHh+qqKlWVVX8+foMAAPf39/m5eYcFxiSkJFSUFF3dndeXF3IxsfQICFLSUq0srMqJif/9fn/+fjrxcShoKHT0dK5uLgSDA41MzTa2NmHhYawOkLRqKq9AAy9Iye9LzPBQUfDSlPQcXb13uD66enx1tnQg4HAVlS7Dhq3LzTrvMLemZjSExvSjpTEX2Tq0Mm9Kje5S1L07ufFcnO1GRXjrLe9eXyvABzNS1jrv7u9VVzy29/NZ23RfXulIyi0WV3LV13MlprUtLXSi4fxx869GhjozcTGAABsbGz39bV5AAAL5ElEQVR4nO2dDVvaShbHJ5MEJIa8TAySSEAZRBCDtgIKaHyBtfXu7drq3u71utfv/zH2TEJfrC8FDbgd8u9TTIQMz/w858w5k2SCUKJEiRIlSpQoUaJEiRIlSpQoUSLOZSIZXuVZKPy2X1phH2b0Vch0ZvZl05Ask/QM5czuTzMVZd8szkxv3r52b18kE2UXqDor7WZeu78vEsBSBCzMRpLGAaxZSVR+eVjaRIYlSRKGA/BIojj+oVj6xWGhCWEBHypKImMGmEQJS1IC63FYgoRVGkpVI+tKYD1MiioLu1qr3dkDLXbawa6iqWPTmg9YIqbgbfh0t9XZz9T73R5klzWn1uv266mDw3YAwJg3Sj+JX3MCS5JURTs6OO7WECIE/odHRhtOL3uyeKOpLH4lsLBAT7WjQRaKYCLLpnm3GCbEBHzd1GGgCj9xyLmApbSHxxvso2FhJ5Pvj2Y7jsNe+wdHGn0SF+ewwLWw0jrP1n7eDIDsnXQAlySKj7gj57AwVrXLfziEkJ+3w4JZb3Cm4kcDPe+wtHfHTjg/OAYt0wQP7Z63VDqHsESJBtc9COrIHGuC03RMWSbmRUdhw+IDjXIMC6JV58Ik481tAk6wPfM94ALj0iAteyBu8QxL2U+TcWfNYTysZQd7Hw42IJNAqd9OH4pb/MKiHwa1ccL6SN2Td4FCsbKXRY6J6kfK/LihSGnwT0Sc8YIVQsbvHxbYZISI1bNjMC3S/Zd2P2pxCgvT9gUaK1+I5HRPzjQMBSLkDa2TGsT53scb9cd2OYVFW3WZTHKSTDZ7J21KWVRXg+saAVqHioTnARZtXQCrSRphRWP3PKBsggJrVyNaIvewoMIJwAcnPh0KTls/Y0mDICpXLOPqdiiLYlzDEqiSgaxp8hPtDlgTGBcU01i7NmWHZM/onVlnDmFhhXmR/JyrEiB/T7VVME0cZAjsHf9G+XZDiR5CLjrBSPhNJstgs4sqlrDaAk+WycmNyC8sLIm4lZ0stn8vdmB3CAmppHa6JjE3hgqbj+YVFtYy5nOs6psgcCmssDw05Brpg1cKEp+wIBv9WHvhVUiOXDvXILArJyapoczNt6l5zmBJOOiTceaunhJBzn6AsRr8BUV1DRyR05glKFdxXEBFNi4VQVQP07BdDzCnsHC7G8vVZqT3WVGCN59g09xXOHVDZRDPVZ810l28vGDTYYT0W1yOhqJ61EXOCyNWKFNG6RoUAZA9yOa5MrrUhidY0JcDkzwrdX9ERIYSyKwHghimD3zBamVfOhL+KDY1b75T+YNF6XCMk6kTqfu2B7RSu9HcA0+wROXPGJuFQvr9ebCbgRR3oxXOCnIFC/KGOJ1QJuk9qnysQaV5SbkL8Oow1vsfZNmsa7SVhbCVuuEOlpaZfHr0KUGJOaTKANKHXgtzFuBx61PMQyEi9YDu1WTTHIbT8RzBop2NuJtmZXSrDxsDhTM3pPuxNy2Dae2mCEEXYTXNCyxRwkrmxZMz91V7d7oPtU83oHzB2q3HDksmKKN00gilOypHsEA33Wec/npa7OK2dtCHv8ElV7Cw+CFNzLhvnYS04XL3AirEK57cUBDx0XRuyU1BxeNEwyEvsESR7k3nbu9+ax8MLLXLESxBVC+nA6t2+BkaPubJsrCo7k9pHYHrTs1E9fBLuIGlXE0Hlnncro3O8fADi15Nqf3+v7mDJdEpWRZKv0kT7mBNKWbJ5h89ky9Ygkg/j3tp8mSS0e8AK6VxNBpCntWZjhfK6D9pE53wlDqIEv2w8fzrsp7Un4aJDriCJeCbXuwTNJEaUEftc1UbCuJuNvZZh0gGIrVDrmBJopKKf+5vJNJr8zRTymAdPOd67jFEEMkGXM1nCQLdc+K8KOSOMgu8nQpr96YUtJB5xdvZHRxcxHuS9ZvSRypXMYtd9ncwta/YlXiDJS2mpzEcmgRdR/eH8QSLqtlptA+wOlTkLMALkjKYQoCXIXHQ+IMl0LP3sV5SGkom6ErB3MHCgpYCWDFX07IZpe+cwZIE+i7+E60yynxZrpInWKJIg+PY60PSC69z4A0WW/nw40assNiKI18Niy9YLItPoTjdkC3w8NWwuIOldt7HCIutEXWtYpFPWAJWTuJsWybZtsQrLDYV34/vlJiJ0kP1u78EX7AEkapQIcaXmQ7umC1fsNgq08p1fDE+26L8whIwFnHrOC5avcVT3lcMoe1Y7qSTSXoYUM5hCRJd7MVwvlVG15p4Z+k/DmFhjJVh71nrq9yRmQnurtvDIywJQ6f+SL/4gUKZlvrDamMcwgq7pQ3T6AWuKMvMrn5cUZJTWCJdeJEnEnLCfHA+YEnQr73+88fE9IH2wMMtOIUFYUugRxemaU66iI9p1th6IRqdsxVwaSuzIU92kprIskxQfTHAeK5WwAVYkvKxP1kyb8qEpActSh98QgPHsARRFNXWZL0zCfprUQlD+/wsF/yld1gMOschg7EMjC0HH9DHm+MaFrgiprvD7M/jFgQrQszuoKUKjz8ihXNY7LlgknpzeZxmq8o8YV0yMmv9QXsBS0888oNzWCxwQc1yE+yddGtPpl3vL/Zb6r2lp+cMVhioMVZv2sNMNh0eIKPwRCwBSyPRwy16F/sd9fFYNT+wmKRohfjW3nkm2wtXQvpiZLV0/+Jg2NaUh5OFeYQlQiYA/+mpogVni4fng0zqLfwbnA/fHQXKAlTM7Gk7CawIFrvHjsV6CcZHSk9PFUVZOAWxVafZvP3TT3KaL1gxKYGVwEpgPSySVVgVOAv9+rDQf7UZsQJYQWZK9xbPSKT+98KsdPr3rw2LoEJqdnr76ZeGlShRokSJEiV6SEbBiKEVxyhM6V7PV1chn8+HfXM2K66uLxVDXsZtPl/aZFvFUr60ihql/BeVtpGMduC35fD45VJpHX6swC9u2aGN26quW7fRm1uVUvE1OjUtrdi2x2CtLOm279ue29yGPaNpe34eNmS2sYbKuu/7nufBq94AwhZ88DY8vqjrALXQ9N2lQrjrs2ZsvcgaXdbd1Vfr2RS04nk56FdhyfZyq5urVc9uQqeNJS9nVWFjxbdy9hpqVEr5Ss6ywH4qAHPdhW32NtDx3U34uG0vrcDepm75pWIx71oMIVp27dVX7V3MGsHa0a0cM6mVpuWvRrByLvjSup5jsJDjoBXLsgzHYRazZucqlrvFjmewnNKIVUHP+TvwAbnoWt4Kr7CMpqUvh/vrLjMZgFW1XIg3q3auymCBCh7Aio6xvKV1l0FlsPzire81QzPb1L2l6CMVjx3NJ6yGb7lhd5HhWWBRAKtZglglL9ml5j1Ym66/Y+hWk+0V/VzVs+zo4DXb34maLfr2La+wtsCeRuM92NhWCKvoNo1tz93M3YNV8iDKVzydDXkAK2fl/HDkREueG9kn2gIbcziGNfoFwFoP3bCs69tbut6wf4S1bXvV0P+YFQEsD0zLZwGPwVqPWtnSLa5gGY3GNoNlAayyb9khCNnJWXrohlXDd5d3/Krh/gir6Hv5chleWXxiP7ZvbbvE3ip5/iiv2nTtPE9uuKLrFXkEq1C19CiPBGxWGOBzKO/flvzVe7CcipfzdB3cj6VcYeoAb7F4joqul4+uIomiF0ewfK/igE8xWAgGtEpIIu8xNgDLAg7Vqr51D1ZDZ6wYLWZGISzIMCy/zPhbduiHW25Ikh9YBuRCxcat7VVgZxtGtMp6Y71kW6yXIayyDi5ZuAcLBrq1BmjVZzE8goXWIqdchTZ3yuUd2wpT92XXquyEKr9eP+PRKpiDa48SrC0dKhgX6h2d5ZohLMOCfAoZ+ldYngc8nKanh9bT0C19G2CFuXohwuPkdc93oTLSwxi2DEboM+mbr9TH+LTqgzdZo36srPm6q/v5cFgzmroP5qLrO5CV6/nwAwXoNBCAMjFKyYymrxdHtSFzRD/EvNlkLlqNGt2EehP+2TzAQoXyVsP4fq9cGG0bhgEjo2E4ssw2mUYbzpd99hmDvTjf9tj72+VyY5Szsc9Gmtaqgv8/kr++THJAokSJEiVKlChRokSJEiVKlChRokSJEiV6Df0PxalcxEYAkW8AAAAASUVORK5CYII=" 
            alt="Jomtakol" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMQEhUTERIWFhUXFRkZGBYWFRoYGhgbGRUYFxgXFxgYHSggGBonHRcYITEhJikrLy4uFx81ODMtNygtLisBCgoKDg0OGRAQGy8mICUyMDAwLS8rLS0uLS0vKy0rLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAGYB7AMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUBAgYDBwj/xABFEAACAQMCAwUFBQQHBgcAAAABAgADBBESIQUGMRMiQVFhBzJxgZEUI0JysTNSobI0Q2JzgsHRFiQ1U6LhFSazwtLw8f/EABoBAQACAwEAAAAAAAAAAAAAAAABBAIDBQb/xAA0EQEAAgECBAMFBwQDAQAAAAAAAQIDBBEFEiExQVFxEzIzYaEUIkKBkbHBIzRS0RXh8GL/2gAMAwEAAhEDEQA/APuMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQBMbjAYeYmPNHmnaWZkggICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGvr1KK6nbHkPE+gHjNGfU48Fea8tuLDfLO1YV4rXNf3AKKebbsfl4SjGTVajrSOSvnPdZmmDF7080/Ls8a3D6S/t7lmPq+n+Amu+lw1+NlmZ9dv2Z1z5J+HSI/J5i2sj0qkH+8Imv2WgnpF/rLP2mrjvX6JFPh7gZt7kn0Yh1+vWb66XJXrgy/lPWGqc9J6Zcf6dG9Pi7UyEuU0E9HG6H5+Ezrrr47cmort8/BjbS1vHNhnf5eK3U53E6UTExvClMbMyQgICAgICAgICAgICAgICAgICAgICAgICAgIGICAgZgICAgICAgICAgICAgICAgICAgICAgICBE4nfCgmo7k7Ko6sfACVtVqa4Kc09/CPOW7BhnLbaPzVtOgKQNzdnL+A6hM9FUecoVxxij7Tqp3t5eXyham85J9jg7fupeJcdq1cgHQnkOp+JnI1XE8uadq9IdDBocePrPWWtrwGtUGrSAD4sesjFwzUZY5ttvVOTXYcfT9khuVqvgyH6ib54Jm27w1RxPH5Sg1rSvbHJDJ/aU7fUf5ynfBqdLO/WPnHZZrlw5426St+HcdWoOyuQCDtqxsfzDw+M6el4nXLHstRHfxUc+hnH/AFMP6JSlrJgCS1ux2J3NMnwz+7LVZtorxG++Ofp/00TEamu/a8fVegzrxO7nsyRgGAzAZgZgYzAzAxAzAQMZgZgYzAzAwTAzAxAzAQMZgAYCBmBiBmBiBmBiBmAgICAgICAgICAgICAgICAgICAgICAgICBSWv39dqrfs6WVTyyPeacnFtqM9s1vdp0j+ZX7/wBLFGOO9u/+kBOO9tVNN01UnOlQBuPX1lKvEvbZpx3rvSekf7WZ0Xs8cXrO1o6ofMHDFtwgUk51ZJ8vASrxLR000Vivi36PU2zTPN4L2/4r9mpUjp1agB1x4TsajWzpcNJ233c7Dpvb5Lxvtsgf7WH/AJX/AFf9pS/5yf8AD6rP/Fx/kkcO4/29QUjTADZ8c9B5YljTcU+0ZIxTTu1Z9D7GnPFuyBzFwUUvvKY7n4l/d9R6SjxPh0Yv6mPt4x5LOi1nP9y/dJ5evBXRrervttnxXy+IljhuojPjnT5evl6NWtwzivGaiw4DWYa6DnLUjgHzU+6Ze0GS0c2C/ev7eCrq6xO2Wva37rC9P3b/AJW/QzpKb5V7Ha9Rru7D1GYBABliQO/4ZkCz505IuK1Stc075qa41CmFPgo2zq9PKSOE5N5cuuJmsBfvS7IqOhbOrO/UY6Ql9v5Y4YbS1pUGqGoaaBS56tjx3JhD5j7Sbi4vOIC1tajL2dJmOCfwqXPTx8IF/wCxnizVbWpQqMWejUO7HJKtuOvrmEQs/alUZbByjFTrXcHB6wl5+yGozcMpF2LNqqZLHJPfPiYHZP0PwgfIPZTc1G4pch6jMBRbALEgfer4SEPqnGr0UKFSqfwoT88bSUvzwt3eUxSvzVfszcNhcnH3bAkeoIJgfo6zuBVRKi+66hh8CMwPjHtZqVzf6KLv3lACoTvhc/oDJS63k/mQ3nC6yux7ejRZHOdzhDof5gfUGQhC9i9w7C87R2b75QNRJxs2wzA+kkmBT828FqXtsaNKuaLFgdYGenUYyIHxLm3gV1YV0oG9epr0jXuuNRxuMwPpPJHIVawuTcVb5q47JkCFSANTK2r3j+7/ABgc57TrqovFLcLUZVLUsgMQPe3zCH0nme5BtK+hxq7NsYYZzjwhLjfYhcO9K6NR2c9uu7EnHcGw8oHS+0fiv2WwqsDhmGlT6mB8m5Ur3Vhf2VS5rOyV0U4ZjgLWGBkeYJH0kj7/ACB8d4ZXqf7QhTUYpqq93Uce6fCB9jgICAgICAgICAgICAgICAgICAgICAgICBF4nX7Ok7eSmV9Vk9nhtb5NuCnPkrVS3h7CyVR1cAH/ABbmcrPP2fQREd5/lfxR7XVzM9o/hH5QtAztUP4dh8T1P0lfguCLXtknw6Q3cTy7VikeLfnX+r/xf5TPjv4GHC/xOgtqStTTUAe6Ooz4TtYqVtirzRv0c29pi9tp8XI8zIBcEAADSuwnmeKViup2iPJ29DMzg3n5uxo0FABCgHHUAT1GPFSIiYiHDve0zMTLerTDAqRkEYM2XpF6zWfFhW01mJhwVIm3uB/YfHyzj9DPGU302q9J+j0lts+D1h1F33Lqk46VFKH5biehzf09XjvH4o2cfH97T3r5dVle/s3/ACt+hnUUnyj2On/fLz8o/nMD6hxr+j1f7tv0gfNfYn715+ZP84H1K5rCmjOeiqSfkMwPhfL/ADC6X9xdC3euWBTuqzadTZ/CPHECV7OeKdhxRlKmmtbKFG2KnqoIP0gfQPan/wAPf86/rA8fZHtwyl+Z/wCYwOzfofhA+O+yn/ilz/dN/wCosDqfa9xTsbPswd6hx8h/9ED55e8UJ4bTtWs6irS3FUo2MknLEkY3zA+k+yTinb2CoT3qLGmfgN1J+Rgc3ze+OOWv95T/AEgVnG7Y8H4i5wfs9wlQbdNLggj4q2IF77FRlbs+HbJ/K0C14pxfjC1HWhZIyAkKxcDI8DjMDruEVKrUaZuFC1So1qvQN4gQPk/tb/p9D40/5hA+w0zt8oHxn2t0S/EKSA4LBFz5ZOMyRK4x7O7ijQqVDfs4RSdOnGfTOZCVl7DtqFz/AHy/yQhD9td/rajbAE53KjqcnoMQOb534y10lEtavQNMBQxVlGw2GSPCB9n5V4mLu0o1vFkGr0YbMPqDA+ZcOH/mIfmqfymB9iWBmAgICAgICAgICAgICAgICAgICAgICAgVnMn9Hf5fzCUOJf21lrRfGqreav2NLyz/AO2c7i/wMf8A7wXOH/FukcofsW/OZv4L8CfVq4l8WPRD51/q/wDF/lK3HfwN3C/xOjs/2aflH6Tu4Ph19HMy+/Pq5Dmj+kH8q/rPMcW/uv0dvQfA/V2dPoPgJ6qnuw4Nu8tpkhwnMY/3h8en6Tx3E/7q23yei0PwI3dBxbra+faL+k7Wr74PWP2czT9svot7inqRlBxlSM/EYnXUHF8kcmVOHVq1R6y1O1AGFUrjvZ8YHX39ualJ0BwWUgE74yOsDk+Q+UH4aa2ustTtSp7qlcYz5n1gdDzLYVLm2ejSqKjOMamBIA8dhAqOReVzw2i1I1A7NULs6jTnYADHpj+MCr5n5CqXF6t3RrrTIKNgoSdS+OQfECB0PNvBXv7U0FcIxKnUVyNuu0DhrT2a3lFdNPiKqvkEb/WB3nK3DKlrbLRq1u1cas1MHfUSR18oHPco8k1LC7q3D11ftFK6VUgjLBs5J9IG/OnJdXiNem5rqtJNP3ekknBy2+fGB1F3w8VqL0mJCuhTHkMYG0DmOQuT6vDKlXVXWolQDuqpGGUnvbnyOPlAzxzkypX4hSvBWVVpsraCpJOkbjOYFrzny0vErfsyQjhtSORnSfHPoRAruQeVX4atVGqrU7RlbKqRjAI8fjA7BkzAyq4gcPzpyPUvrmnXWuqKmnulCSdJz1BgdrRO28DiubuSKl5d07kV1RU0d0oSTpOeuYHU8VszcW9WkpCl1IBIyBnxxAoOQOV34alVHqrUNSoHyqlcYXGN4ESpyVUfiS31aurKjFlphTnoQu5Ph1gXvNXAft1q1HXpYkFWIyAR6QI/InAanD6BoVKq1RrLKVUjSD1G/rv84FVbclVKfE/txrqV1MezCEHDDHXMDuafSBtAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQInFqPaUai+JU4lbWY/aYLV+Tdp78uWsqbiI7ayRx1UAn5bGcrVR7fQRaPBewT7LVTWfF48n3WGemfHvD5bGauCZ4i1sc+PWGzieLeIvHozzr/V/4pPHfwI4X+J0dl+zT8o/Sd3B8Kvo5mX359XIc0f0g/lX9Z5ji391+jt6D4H6uzp9B8BPVU92HBt3kdgASegGTFrRWJmSImZ2hwWTcXG343/hn/QTxm86nVbx4z9HpOmHB6Q6e9Gu5ooOiAuf0E9Dnjn1WOkfh6uPi+7gvbz6LczqSpKlONA5IpPpBwWAyMjw85U+1fd5uXos/Z+vLv1etxxhFClVLa+mOpOcY+MytqIiKzWN92FcM7zE9Nmp4tpUu9J1AOO9jJ2BzFs80rE2grii1tol73PEFRkTBJcgDHwyfoBmbLZdrRWPFjXHvWZ8kSlxrV7lF26AkAYyQD1+c11zzaelejO2GKx1lMoXweo1PG6jOfnibKZea1q+TXanLWJ82l7xFabBArO7dFXrt1J8pjfNtblrG8sq4t45pnaGKPE0ZWOCCoyVPXymNdTE1mdusd4ZWwTExHm8rfjKnTlGUMcKxxg74kV1PWImNt+yZwdJ2ns9aXFEar2WN99/hvJpqYtkmnki2Ca0i7WlxZGdkA3VSfp1Eimqi1rREdk2081iJnxa2vF+0I00n0kka8d3bqZljzWvtPL0Y3xRTfr1elvxNHdkxuBn44kY9TW9pr5JvgtWsW82i8WBTUKbEamU48NJxkyJ1M8nPFehGD73LMtuHcT7Y7U2C4yHPQ74wP4/SbMWWckb7bMcmOKTtur+ceN1LNKRpIjNUqin384GQTnb4Tc1IPDecwr1qd6EptS0ZdCzIdZ0qOmQcmBZcb5gpoldKVQdvTo9oFwTgEd1txgwIvKnNNK5pUUqVlNw1IMy4xlsd7Hh8hAqOBc31mpUDVNNmqXRpEkFe7nA0hRgt06wOpPH7bthQ7VTVJxoGTg+RIGAfjAg8w8xPRqpbW1IVKzqW7x0oijxYjf6eUDa246aNLXxA0qTFiB2ZZgR4YyMk/KBLqcx2q00qmunZudKt4E+R8j8YEdecrEgH7SmC2kdevqMbD1O0D2v+ZbS3YpVrKrKASMHOD0IwN4G17zFa0UR6lZQrjKEAtkeY0gwM3XMdrSVGeuoWoCUbfDAdcEQNKfM9oy02WspWq+hDg7t+6du6fjiBLtOKUqz1EpuGak2lxg90+WcYJ+ECq5W5ga7p1mdVU061RBpzghACCc+O8Dz4XzfRahTq3FSmhcsBpLFTpJ6Ejy84EqlzfZNoxcp94cL13Ocb7bfOBA4lzits90KgUrRFPSqFtbF87NkYHTrAsLfmq2ailY1AofYDBzke8AMZOPMCB7V+ZLVKaVWrpoc4U9cnxAA32gVfJXHql32/aMGC12WmQAO5k6enXbG8DqYCAgICAgICAgICAgICAgUdiBRqvbv7j5ZPn7yzk4IjDmtp79rdY/mF/LM5Mdc1e8dJVttwOolfrpRDqD+nl/kZz8XDcmPUb77Vr13+S3fW0vh223memzz5mv6dcJ2ZzpLA/6/Ca+K6rHn5eSezPQYL4t+aO7q7L9mn5R+k9Jp/hV9HGy+/b1UnGuB1K1XWpXGANyc7fKcnXcNy583tKzG3Rf0utpix8kxLoF2G/gJ2o6V6ubPWXL8x8ZDg0qR2/Ew8f7InnuKcRi0Tixz08Z/h19Do5rPtL/lDblmyCKbipsMd3Pl4mTwrTxjrOoydPJGvzc9ow0/NY8DQuXuGGDUPdHko6S/oKzebai34u3oq6qYrFcUeHf1WtXofhOlPZShy9nf0qdOqrOMl37o3O+PD5Tn4c1YxTXx69F7LimbxbwRXRkp0tZNMszMc9VDODjfxx+swvj5KY4sml+a95hZ26JUo1FWoamDnJwMbYxt6TfNa5MVq1mZ9WreaZImYeHA37WrqzkUk0D8x2PxwB/GRpt7zz2jw2TqNqRyx6oljVQe/XZMFe6AP3R575zNOGaxad5nu2ZItNY2iOydTvadK5ql2AyoAHwYmbceWtMl+ZhfHN8ddmzXC06/aO2EqJ3WPkSDEX9nmm1u0+Jye0xRFe8PAVBUevVXPZhCAx6MSRnHmB/nMZrNvaX26SneK8lPJ6cNsmqrSapUyqkMEC46HbJJ6fKbcODetZtPZhly7WtFY7oLvoFSrudFTG35F29fH6SrNbRHtKx13n6rETX3J7bQ9qCdnVVT7xouT81DH6HI+U21pyXmP/lrm/NWJ+bPCa6ArqrknUQEAGN84HnI0s1iIjed/I1EWnedo2ZpUv2lReqVf4aRn9Zh7OeSb17xM/oy545opPaYSuDVA1s5HQu5/wCqb6b/AGafzasnx0rloZoU/gf5jLOD4dfRoy+/Kr9oXCal0lBaaagtcM/eC4XSwJzkefhNrWr+M8nj7G6WyAOWR9ycsUbOCzbwKs8Nu61WvVeiENS1FIKHDbqMAE+Z+kBw3gdyXtFektNbYbuGBLnGMADcf/sDxs+Xbladspp4NO77Ru8uy6gc9d/hAueWrG4tKz02oh6dSsz9sHAIDfvKdzj08zAlcy8MrpdJeWyrUOjs3psdOpQSQQegO5gQeK0LqtUt7v7MoelrU0DUB2PRw+MaoFWOWrjsqY0Ak3YrOgI0ouRkDPXYeEDbinLddvt2mkD2ppGluozpfLePd288QPKt2q31RUpCq/2RVKswGOgzk9d4Ht/4JeUqFGimWQI4qKjhDqbp3iMlR5CA4bwC4AsA9Pai7mpupCg5xtnfw6QPG94U1C1ujXxTP2kVaJJByQBpwB4nfaB1XINi9Ohrqe/VY1H+LefyxAp+XkvLM1aRtNS1Kztr7ZBgNtnTvnpn5wIHDuXbhUslel+yrFqg1KcA+PXf5QNbrlm4NO5ApDU93TqJuu6L7xznb4QJd5y/cVWvu7gVqdMISRuVOSOu3zgeF1wi8bsKopsjU6ZpsiVVDdffViCu/iPSBra8v3FFqNdKRco9QtSqVFJ74ALBgAvhn4wOh5B4bVoGt2yBS9UuACCMHfbEDtICAgICAgICAgICAgICAgQuK2ArLscOpyjeR/0lTV6aM9OnS0dYn5t+nzeyt17T3hBp1xcI1vXylXxAONX9pfMekqVyxqaTp833bfv84WLUnDaM2PrVzvEeEVKOcjUv7yjb5jwnC1XD8uCesbx5w6uDV48sdJ2nySbPmSqgCkK4Gwzsf4Tfh4vmxxyzETDTl4djvO8dEpua38KQz6t/2lieOX26U+rVHC6+Nlbd8WrV+6ScH8KD9fEyjm12o1E8u/5QtY9Lhw9frKw4Vy/+O4wqjfT/APLyHpLuj4Vt/Uz9Ijw/2q6jX7/cxdZ8/wDSczG8YKm1up3PTWR4D+zLkzOtty16Y4+v/SvERpq81vfn6L1VAGB0E7ERERtDnzO87yzJQj/ZVByqqD5hQD9ZG0G7Y24PUA/EZkhToBemB8BiAWgAcjb4DEDV7VSc4H0EjY3HtQeoH0EnY3bNbgjBAI8iAR9DALQHy8vD6QNkpAdIGDRHkPpAx9nHkPpA1FqAcgD6CNhuKI9PpAJQA8Bjyxt9IGyUwOkDYrmA0wNRSHlAg8Y4hStKfaVc4yAAqliSegAH6wMcG4nRu0L0j0YqykYKsOoI+f8AGBP7MeUDW4dVUs5AUDJJ8AIHP8K5ttbmstGiHLFXbLU2pjC4374BOc9RA6IUx5QI/ELqnQTtKmy5UE4JxqYKCcdBk7noIEPhy29yFuaIUhxs+nDMAcdSM4yIFp2Y8oAUh5QOV4/zNYo5o1Qzujrt2TFQ5OBhyNAYZ84HT2yADaBVcxcapWfZl0LGo2lQCq74z1cgfKBK4Lerc0UqqjIHGQrYzjOxOCRv1gS65VFZ26KCT8AMmBraVEqorpurKCDjGx3Gx6QPXsh5QHZDygVn/jNLt/s9NWdx7+kbUxtuxPxGwyd4FsICAgICAgICAgICAgICAgIEPiHDkrjvDBHRhsR8DKup0mPPH3u/hPi3Yc98U9O3kg67mhsy9snmNnx6jxlTm1Wn6Wjnr9VjbBl6xPLP0R6tzZv+1p6D46kK/wARNFsuhyfEptPzjZtrTVU9y28erzC8PHiD6ZJmHJw2PKWXNrZSKPEEXa2t2Y+YXSPqZvpqsdemnxzP5bNdsF565r7fnu9Rw2rXOblu7/yk6f4j4zONJmzzvqJ6f4x2/Nh9ox4o2wx185W9NAoAUAAdAJ061isbVjopTabTvLaZIICAgICAgICAgICAgICAgIHO3txWp36DtCaT0XxTx0ZNy3zyPpAo7HjlVatk1W5Gip2iujYG4Z9LE4x4ADpAg8R43eC1WuHc017TUyEBgRVYBm23UDAAgdDxTjFU2AqofvdKM4QgOFYjJQHox6DPn6QOcveNVrejVCsyN2tPvPp7UBqBq6HYDDNqXTnHQwLPly5u7lGp1K7qVqqXbAFTS1POhTjC97B3GwyIHnZcxVshGqgt2Fwq6xs706+lWbA97SPnAq6HGapV6iOxLWrulSqUchlIyV0qCnX3D6QJa8QvuxqK9YrVW0FXOQ3R3bqF6lQBnEC6tOLC5r9i1RXRrQa02I1E97PrpIyPWBzQ4rVt7e3NtV6ValFqQH43dimcjoB+sCU/E74ihSpVizfanRmJAZlRVbc4wR722N9oHXcp3r1qOqoxY9pVGT5CowA+Q2gcZx3jVc3NUA6kpVANGxRVFQJ3lxuTknOc+UC7seINWWspujTFGvUNQjAZaQ1aQGIwq7dd/dIgUt1xipXp26u5bWlXRpKKzvTqFA7F1IG2nbAyWMAvGrkqmO0UfZe0U0tIUMhwxrKRnSTpAA8zAt6V/XepcCo+qm9iKqoBshKkEdIEG24q60norcdk32Si1PPgQAX07dTsPmIHq3G61emgpXGGNmXYjBw6uhbOBkNjUPTMDFxzU4VSlYFhw9nYbECr92VLf2sazj4wPHk3iFZ7n71i61EchmC5YU3VQwIAJzk+nlA+jCAgICAgICAgICAgICAgICAgIGrID1APymM1rPeExMx2a9iv7o+gkezp5R+iee3m3AmUREdmLMkICAgICAgICAgICAgICAgICAgVnFOCUbhg1SkrMBgE5yB5DBgRm5YtyFHY0+6pVe70U9QPSBJpcForRNDs17IgjRju4PUY8oBuCUSGBpqdaBG295V3VT6DMCNT5Yt1GBRQDWH6Z7yjCtv4gQLC24elNmZVALEFiOpIGAT8oER+X6BYMKSZXVpOOms5bHxJyYGtPlygq6RSQLpK4xtpb3h8DAWvLlCnqCUkAddLYHvLv3Tk9Nzt6wM2XLtCi4enSRCF0gqMYHXEDZeX6A6UkHf7Tp+P9/4wNbjl2g4w1JT3i/T8RGC23iRAmcN4elBQlNQqjoo6DPWB4PwOiS/3a/eNqfb3227zeZ2H0gYpcEpKahFNfvRipt74wRhvPqfrA0/2fodzFJfu86Nvdz1xA87jli3cKGooQoKqMdATkjr0zAxc8sW9Q6noox0hMkH3QMBdj09IG1blqg/vUkPc0bj8IxhfhsPpAzbcu0KbFlpICV0EhcZX90+kDxHKdsNhQpgaSmAv4TnK/Dc/WBPocJpoysEAZV0qcdFOMqPTYfSBYQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQP/2Q==" 
            alt="Italian-Thai Development" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
      

        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQBhITEhIVFRIVEBkVFRgSFhEQFhcbFhYYFhUWFRMYKDQgGBolHRgWITEiJSktLi8uFx8zODUsNygtLi0BCgoKDg0OGxAQGjclHyY3KzI1NS0tMi0tLTY1Ni0rLTItMC0tLS0tNystLS0tKy8vLS0vLystLS0uLS0tLS0tL//AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQcCAwYEAQj/xABGEAABAwICAg0ICAUEAwAAAAABAAIDBBEFBhIhBxMWFzE2QVFUc5GS0RQiU2Fxk7HBMnKBoaKjstIVIzNCUjQ1Q2IkY/D/xAAbAQEAAQUBAAAAAAAAAAAAAAAAAQIDBAUGB//EADkRAQABAgIECwkAAQUBAQAAAAABAgMEBRETMVESFBUhQVJTYZGh4RYiMjM0ccHR8LEGcoGi8UJi/9oADAMBAAIRAxEAPwC8UBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQV1j+yJNTYzLC2CNwjfoglzgT7QFjXMRwKtGh0mCyKjEWKbs16NPc8G+nP0ePvPVHG+5lezVvtJ8PU305+jx956cb7j2at9pPh6m+nP0ePvPTjfcezVvtJ8PU305+jx956cb7j2at9pPh6m+nP0ePvPTjfcezVvtJ8PU305+jx956cb7j2at9pPh6m+nP0ePvPTjfcezVvtJ8PU305+jx956cb7j2at9pPh6m+nP0ePvPTjfcezVvtJ8PU305+jx956cb7j2at9pPh6m+nP0ePvPTjfcezVvtJ8PV8OynPb/Txd56uWbtd6uKKKdMytX8hsWLc3Ll3REd3qb60vRmd5y6WnJ40c9XO5Gq7GmeDsN9eXozO85TyPT1ka2dxvry9GZ3nJyPT1jWzuN9eXozO85OR6esa2dxvry9GZ3nJyPT1jWzuN9eXozO85OR6esa2dxvry9GZ3nJyPR1jWzuWVhNWZsMilIsXxh1hrtcXstLdo4Fc07l2J0w9atpEBAQEBAQEFDZ1411XXH5LW4j5kvQso+it/3TKEVlshAQEBAQEBAQEBVUUVV1RTTGmZU1100UzVVOiIa3Ouu5yzLacJRpq+Odvd3Q86zfNasbc0U81EbO/vlito04gICAgIB4EH6Gyxxdpupb8Fx+J+dV95ZVOxKKwkQEBAQEBAQUNnXjXVdcfktbiPmS9Cyj6K3/AHTKEVlshAQEGUcZc+zQXOPAGguJ9gGtTETOxFVUUxpqnRHePaWvIIII4QQQR7QUmJjaRVFUaYnTDFQkQEBIjTzQiZiI0y1vcu0ynK+L06y58c+Tgc7zjjVWqtT7kf8Ab03MVu3PiAgICAgIB4EH6Gyxxdpupb8Fx+J+dV95ZVOxKKwkQEBAQEBAQUNnXjXVdcfktbiPmS9Cyj6K3/dMoRWWyEBB9aLuAHCTYfaiJnRGle+VMvRUWGMaGjbC0GRxA0i62vXzC5FltaKIojRDzrH465irs1VTzdEdEQ0Z1y5HWYS86IEzGl0bxqNxr0SeVp5R9vCFF23FdPOuZZj68Lejn92dsf25RwNwtW9CEBBg9y63J8q1cRfuxz9Ebu/7uJz3OdZM4ezPu9M7+6O5guicsICAgICAgIB4EH6Gyxxdpupb8Fx+J+dV95ZVOxKKwkQEBAQEBAQUNnXjXVdcfktbiPmS9Cyj6K3/AHTKEVlshAQfWuIcCOEG4+xETGmNC/Mr45HW4Wx7XDTDQJG6tJrra7hbaiuK40w83xuErwt2aKo+3fDz5yx6Ojwd5JBle0tjZykkWvb/ABHKfUouVxRTplcy7BV4q9FMRzRtndCigLBap6KIMXuXS5NlfC0X7sc3RH5/Tks+zng6cNYnn/8Aqd3dH5a11TjRAQEBAQEBAQDwIP0Nlji7TdS34Lj8T86r7yyqdiUVhIgICAgICAgobOvGuq64/Ja3EfMl6FlH0Vv+6ZQistkICAgzilcx92uc087SWntCmKpjZKiu3RXGiuImO+NJJI5z7ucXHncS49pSZmeeU0UU0RopjRHdzMFCpi5y3uUZXr51t2PdjZ3+jm88zji8aizPvztnq+rWuycIICAgIJ7KeWH4jPI1kjY9raHHSBde5I5PYsTF4uMPETMadKqmnhOl3qJukx9x/isLlijqT4q9VO83qJukx9x/inLFHUnxNVO83qJukx9x/inLFHUnxNVO83qJukx9x/inLFHUnxNVO83qJukx9x/inLFHUnxNVO9ZmE0hhwyKIkEsjDSRqBsLXWku18Ouat67EaIetW0iAgICAgICChs68a6rrj8lrcR8yXoWUfRW/wC6ZQistkICAgICD451lt8qy2cVXw6/gjz7v20ec5tGDo4FHxz5d8/hqXb00xTEU0xoiHntVU1TNVU6ZkUoEBAQEFi7DX+4VPVM/UVp84+Cn7yu2tq1VoF4QEBAQEBAQEBAQEBAQUNnXjXVdcfktbiPmS9Cyj6K3/dMoRWWyfHGzT7FEpiNMrSptjCB9Mx3lE3nNB/4uUX5lnzhKd7j6v8AUl6J0cCnz/bZvWU/SJvyv2qOKU70e0t7qU+f7N6yn6RN+V+1OKU7z2lvdSnz/bnM5ZYo8PpR/PlfO/6DP5XB/k+wuG/HtWdgso4xVzzPBjb+lFf+p70R8FPn+3Dk612Nu3TboiiiNEQ5e7dru1zcrnTMirWxAQEBAQS2X8wz0Mr3QaF3gB2m3S1A3FtfrWPiMNRfiIr6E01TGxN75dfzw+7PisXkrD9/j6KtZUb5dfzw+7PinJWH7/H0NZUb5dfzw+7PinJWH7/H0NZUb5dfzw+7PinJWH7/AB9DWVPo2SsQ54fdnxVnEYHCWLc3LkzER3+i/hrd7EXItW40zK2cBq3T4NDK+2k+MONtQuRrsFoZmJnTTsXb1qbVyaJnZzPeoWxAQEBAQEBBQ2deNdV1x+S1uI+ZL0LKPorf90yhFZbJjJ/TPsKidiadsP0dh/8AoI+rb+kLdTteWV/FL0KFKDzZmSPD8O03edI7VGzlcfXzNHKfmQsrCYWrEV6I2dMqaquDCi8TxCSprnSyu0nuNz6uYDmAXVWrdNumKadjGmdPO8qrBAQEBAQEBAQEBACouXKbdM11zoiFdu3XdriiiNMy3NbYLhMyzGrF183NTGyPzL0bKcrpwVvn5652z+I7l+5R4s03Ut+Cu07IcXjvqa/vKXVTFEBAQEBAQEFDZ1411XXH5LW4j5kvQso+it/3TKEVlsmMn9M+wqJ2Jp2w/R2H/wCgj6tv6Qt1O15ZX8UvJmHG4qHDXSyng1NaLaT3cjWj/wCsr2Hw9V+vgU/+KKqtEaVEY7jEtZiLpZTrPABwNHI0LqrFimzRwKWNM6Z0o9XkCAgICAgICAgICAomYiNMpiJqnRG1tY2wXE5rmc4qrgUfBHn3/p6Bk2URhKNZc+ZPl3ftktM3q/Mo8WabqW/BbenZDzbHfU1/eUuqmKICAgICAgIKGzrxrquuPyWtxHzJehZR9Fb/ALplCKy2TGT+mfYVE7E07YfoObEo6XAWyyu0WNib7T5osAOUlb63aqu18Cna8ruTomZUhmfMMtfiBkfqaNUbAbhg+Z5yuqw2GpsUcGnb0zvYlVWmUOshAgICAgICAgICAgINrGrj84zXXTNm1Puxtnf6f5dzkeT6iIv3o9+dkbvX/DJc+6UQX5lHizTdS34Lb07IebY76mv7yl1UxRAQEBAQEBBQ2deNdV1x+S1uI+ZL0LKPorf90yhFZbJ8eLsPsU00VVzwaY0zKmq5Tbjh1zoiExmjMklbKwG7YY2hsbPYAC53O4/cvQsHhKbFP/6na8luV8KqZQSzFAgICAgICAgICAgINjGrls5zXbYsz95/Efl2GRZPsxN+P9sfmfwzXMOuEBBfmUeLNN1LfgtvTsh5tjvqa/vKXVTFEBAQEBAQEFDZ1411XXH5LW4j5kvQso+it/3TKEVmI0zohsZmIjTLW9y7XKcsjD06y5Hvz5f3S4DOs3nFVaq1PuR/29NzFbpoBAQEBAQEBAQEBAQZsauezjNNVE2LU+90zu9f8OmyLJ9dMYi9Hu9Eb+/7f5bFyDuBAQEF+ZR4s03Ut+C29OyHm2O+pr+8pdVMUQEBAQEBAQUNnXjXVdcfktdiPmS9Cyj6K3/dMoF7l0+T5Xq4i/dj3uiN3q5rPc41szh7M+70zv7o7v8ALBdC5cQEBAQEBAQEBAQEGbG3WmzbM4w1Ortz78+X90N9kuUTi6tZcj3I/wC3d+/BsXEzMzOmXfxERGiBQlaOxxgVNPlzTlgje/bni7mgmwtYXWfhqaZo54chnmLv2sVwbdcxGiNk6HU7lKHosXdCv6ujdHg0/KOL7Wrxk3KUPRYu6E1dG6PA5Rxfa1eMpWCFscLWMaGtaLADUAByAKtiVVTVOmZ0y2IgQEBAQEBAQUJnp1s2VQ/9p+8BbTLcsiq5xi5HN0R+f02uIzeaMHRhrM8+j3p/Eflz910jny6BdAug+3UAgICAgICAgyY25WszPMacJRojnrnZH5lt8pyurG3NM81EbZ/Ef3M2rha66rlU1VTpmXolu3TbpiiiNEQKhWILAyPnKmosD2qUSae2ud5jQ4WNra7rMsXqaKdEuazbKsRicRrLejRojpdBvl0XNN3B4q9xm3vazkDGbo8TfLouabuDxTjNveez+M3R4urw+sbPRMlZfRe0OF9RsecK/HO09y3NuuaKtsPQigQEBAQEBAQeWXDoXyFzoY3OPCXMYSfaSFXF2uI0RM+KNEMf4TT+gi93H4Kddc60+Jog/hNP6CL3cfgmuudafE0Qfwmn9BF7uPwTXXOtPiaIP4TT+gi93H4JrrnWnxNEOR2UKCKPKpcyKNrtuZraxrTw84Wxyy5XVf0TPRKi5EaFProlgQEBAQEH1rblYOPx1GEt8Kds7I3/AN0thluXXMbd4FPNTG2d3rPQ3BcFevV3q5uVzpmXpGHsW7FuLduNEQK0vCAgICAgvzKPFmm6lvwW3p2Q82x31Nf3lLqpiiAgICAgICDncRztQ09a6KWYtkYbOAjmdbVfha2xWZbwF+5TFVNPNPfH7UTXTHM82+Jhvp3e5qP2qvkzE9Xzj9mspN8TDfTu9zUftTkzE9Xzj9mspN8TDfTu9zUftTkzE9Xzj9mspN8TDfTu9zUftTkzE9Xzj9mspc5n/N1HV5eMUEpdJtjHWMcrNQOvW4ALNwGCvWb3Crjm5+mP2orriY5lZrdrQgICAg+gXKxsXi7eFtTcr8OmWXgsFcxd2Ldv/meiI3y3AalwOKxVzE3JuV/+PScHg7eFtRbt/wDosZlCAgICAgIL8yjxZpupb8Ft6dkPNsd9TX95S6qYogICAgICAgobP/G+p+uP0hdZgPp6WNX8UueWWpEBAQEBAQEBB9A1q1fv0WLc3K50RC9h8PcxFyLduNMy2tFguBx2Orxdzh1c0dEbnpOXZfbwVrgU889M7/7ofVhM8Qe3DMKmqZXNhjL3NFyBbUL2vrVyi3VX8LGxOLs4eIm7OjSkdxtf0Z/4fFV8WubmLyzguv5Sbja/oz/w+KcWubjlnBdfyk3G1/Rn/h8U4tc3HLOC6/lJuNr+jP8Aw+KcWubjlnBdfyk3G1/Rn/h8U4tc3HLOC6/lK48t07osBgY8We2JocDyEDgWxiNEOHxVcV366qdkzKSUscQEBAQEBAQUNn/jfU/XH6QuswH09LGr+KXPLLUiAgICAgICABrVFy5TbpmuudEQrtWq7tcUURpmW5rbBcJmWY1YuvdTGyPzL0bKsrowVvfXO2fxHc+rWtqICDvdiD/eJ+oH6ws3Cf8A1/x+XNf6l+Xb+8/hayzHIiAgICAgICAgICAgICChs/8AG+p+uP0hdZgPp6WNX8UueWWpEBAQEBAQFEzFMaZ2JppmqdERpltY2y4jNcznFV8Cj4I8+/8AT0HJspjCUcO58yfLuj8slp28EBAQdHkjMTMPrpHvY94fGGgM0bjzr3OkQr9m9FvTphqs1y+vGU0xTVEaNO30djvp0/R5vyv3K/xundLS+zV7tKfP9G+nT9Hm/K/cnG6d0ns1e7Snz/Rvp0/R5vyv3JxundJ7NXu0p8/0b6dP0eb8r9ycbp3SezV7tKfP9G+nT9Hm/K/cnG6d0ns1e7Snz/TtcLrRUYfHK0EB7A4A2uL89llROmNLn71ubVyaJ6OZ6lK2ICAgICAgIKGz/wAb6n64/SF1mA+npY1fxS55ZakQEBAQEBBtY1cdnGaa6Zs2p92Ns7/T/LusjyfURF+9Hvzsjq+v+GS0DpBAQEBAQEBAQEBBfmUeLNN1LfgtvTsh5tjvqa/vKXVTFEBAQEBAQEFDZ/431P1x+kLrMB9PSxq/ilzyy1IgICAgINjGrls5zXTpsWZ+8/iPy7DIcn0aMTfj/bH5n8M1zDrhAQEBAQEBAQEBAQX5lHizTdS34Lb07IebY76mv7yl1UxRAQEBAQEBBCV2UqKerdJJA1z3G7iS7XyLKoxl6imKaauZTNES8+4bD+jN7XeKq5QxHWRwKdxuGw/oze13inKGI6xwKdxuGw/oze13inKGI6xwKdxuGw/oze13inKGI6xwKdxuGw/oze13inKGI6xwKdwcjYf0dva7xUTjsRMaJqVUxFMxMPm4Wg9AO1ywNTb3NnyvjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0k3C0HoB2uTU29xyxjO0lPUlM2KmbGwWY1tmjmAVxr665rqmqrbLcikQEBAQEBAQcDsk54qMMxOlighjkM4d/ULhYhzGtAIPLp8qCPxXOuM0NMJqvDoRAHAOMUukRfg1gm3tIRL25z2RDS5SpK2ljbI2oPBNpAtGgXEHRP0gRY+woO2jqicKEthpGEPtyX0dK3sRDktjHO0mK4TPNOyOLapA3zC61tAPJJd7fuQRkeyJWV2ISMwmhE8cZsZZn7W08PBrAF+S5vbkCJezANkGQ5gFFiNL5LUO+g5rtKNx5B6r67EEg+rlIS+es6w4VSs0mmWeUkRRNNi61gXE8jQSBym51IOcqM443DR+UTYVHtA85wbIdsDedzbkjVy6KJdFTZzjqclS11MLlkTiWScLXsFyx9viOEFEOf2ONkebEsZdBPFHH/J2xm16d3aLgHfSPrCDTshbJs2HY8YIIYpGsja57n6epz72b5p5h96JdBmrO7aDAqeQxGWeoa3a4mHRBc5oJJJ4GgkDlJuPWQQgq3POLUUAnrcMYKa40jDIHPbcgDSFyBw21218oRKYznnfyXJ8VdStZK2V7NHbNIDReCb6tYOpEOmwKtNRgsEzgA6SFkhAvYFzQ4gX5NaCtINl17s4inMUYpDVbSJPP07E6DXc2t1vsRKxszYi6ly/UTsAc6KFzwHXsS0XsbIhxWxvsizYnjD4J4o4ztO2R7Xp+dZwa76R9YQebZB2TpsPx90EEMUjWRtL3P09Tn3Ib5p5giVlUMxkoo3nUXRtcbcHnAHUiG9AQEBAQEBAQUvs7PLcy4Y5rdJwDyG3tpESwkNvyXOr7UTD2ZpxLGMUwk0gwh1OHkaT3zNkFgb2+i3R9utBG7KeDmh2NMOpnkOdHIQ8t4C4se59vVcmyEOhiw7MH8IBFbR7XtAIG1uvo6HBfQ4bION2P3kbEmMllxqPtDTCwO/DdBYOwixgyGwt+kZpC/nuHkC/2AIS5/Z0AGL4W5v8AV2x4FuGwfCW/eT2lCGnNXn7NdA2b6IiisHcH/If137EFwytBiIdbRIIN+C1td0QorY/JGVMbAvtYY63NezrfciXlyY7yWbBavgbJVTUsnr20hrNfJYkH7EHmzcfKMOxOtPBJirIIz/0hY9oI9RQWJnLKzq/AsPdDPHFUwxsdGJDYPuxuoHhBBAtqPN60QjMYxvG6bC3ivw+nq6a383RPC3ndo3AGq/0eVEvJn/Eqeq2I6eWljEUJqWgRgBu1lumHNsNWog8CDqsRxryLYljlB8/yGJjPrPY1rfiiFTzU9HvXsHlMXl3lJmLA9u22JMYbYa76PnW5yiVqy4z5bsPSzk3eaFzZLf5sbov9lyL/AGoK9yY7yWqwSr4GyTzUsnr2w6DNfJYkH7EHhzd/5GF4jWkf1cXbCw/9IY5Wgj1FB+g8I/2mDqWfpCIetAQEBAQEBAQVzsm5Qqq/HqCWnawsgJMmk8MOuSN2ocuphQWK36KDhNl3K9TiWCwx0wYXNmLnabtAWLHN4eXWQiYdfFTuGDCP+4QBn26FuH2ohxOxPk2egwGpgrGM/nP4GuEgLdrDHA9hRKOocoYthFVIMLkgmppH6QjqtLzdVuEEG41C4OuwuEHqwnJFbV5ljrcWljLorbXDDfQBBuOH+0HXykkayiExshZI/iTYpYpNpq4DeN/IRe+i62vURcHk185QQdTSZlnojTvdRsY4FrpmaQlIOo312FxzNBRKZw7I4o8h1FHCdsmlidpPdZge9wsPY0cARDm9wFZvax0tmCsiq9uZZ40R517h/P4Ikr9j6rOxjDRxtYakVO3SAvAbr07+fy8IQT2b8jPrsIozHIIqylY3QcfOaSGtu0nk1i4I+aIRtdRZkqqJ1NL5FHE9pY+VmnthaRY6tIgXHM0fYgyzLsfSDY6hoKPRe9kwkcZHCMOJ0i91+TW7UES0ZyybX1mB4ZSRhjYoY2eUO2wAhwa2PzB/dojTPrJHMiHWS5Awx1GWCipmksLQ8Qx6YJFtIOtfSHDdByWU8n4jT5NxCilbH/NY7aLSBw0nDRIP+PACiWmTINYdjeGmAYKyGq21tnjRA0jwP5+A/Yg+Ypse1btjOno42sNQ2p26UF4DdYkvZ/L9IILSw+IsoImu+k2NrTy6w0Aoh6EBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBB//Z" 
            alt="Phoomsiam" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbUAAABzCAMAAAAosmzyAAAA6lBMVEX////ofCT+//////7zcyrnfCP97OHoeyXzcif+8+3mcADzeTL++/fyZwDzcSXmcgDyaxLlawDneBnzbRv1gEX3tJL2jFr70r392cfybR3+7eb84NL1gEDybhf3mGr4q4b1iE3toGbneAfwrYHogi/zx6X4uqL8yrPytor559j307vrlFf32cLtn2b54M3ndhPphTbpjD/1za/0yajywZzupm/wrnzvnF7rj0z0xZ/yWQDohzP4uZn85tz34sz1k2D0pHjrl1D3oXn1nHD5wKv2pXzwrILyvp779ury0LDtmmbjYADxvJHsm1aaSpJbAAAgAElEQVR4nO1dDX/attYXUmSwo2BQ1iY0TRuIWWzi2LxDb5pmrN0N3ej3/zrPOZJsbDAv2dpmv/tw1q5g2ZKsv87ReZMgZB+ilDDK4C/NX1wSFO5V04F+HjENCbWi6MNoMvHVV2o3Z7OJHwa2ho+RA3L/LqJEzIP+h15LAsU9oS5aXJbga6vnP/VtAfcQuqOaA/1MYnbk97w4lpyXSiXuadQCznkZvvI4jru9TiBeuJcHQgJ5R1E2CmuMTFZKKUEtc6lUiuWkL9TyxthBUr4g4ejT+YeZJ0vlJTy87NmqOIca8J2U3XFf0ANqL00sGM6k5GVezrIVj1RhntcUsDIehTY5oPaSxKwFl7zEDSQpyb4qzqMGwMKtwHCT8ADaS5I1zXNTwlSyrYu9clGx5J0X7vf/b7J7fBtqdjFq/IDaSxKjQa+I2crxB1VuFWJakqODhHxBYoz6sgiZeKHKPxVBCivbgdVemIqZLfZV4dfCVU9O5wcfyYsSI19B6y+Qgap0WIiaYcQDvRiBxTxal5Fc9pSZPS5ErRsc7LWfSQz9vwz/aBGnxr5I++fcwqJRAWpc3gl6AO0nknI6EnRJLUMulPTRL5J3jfCWQW1d8y+DBX4A7acSDnfQ7APPZdQJgSyVh4e3Aiy5W+e1Mp/ZB1b7uQSqvtWLpU+XCxOjNOiurmybUePSP7DaTyZGxAQQ4h2ipCQKSmA6MVuRhLy0GTXex0d0rJuotAVxCLv9YGJjpTF6Y4EDDkSJGPR4eQW1cqyc/s0i1GYBMSISUKeURM1pdDDffiTRIVfB6pIc24rZKAl8Dpy2Eqgpxx1kp8J1jU87hteQVUUfJO70YAv8SOp7CgdgLTkKVLJIm0sQiOVVXTEeoggtlJC85A0SiGgEJh3ncmIfFrsfQ8hX96XUERJPQLm3rov9w8CLCEOz0ElZknzAFKPZX7sxIlmSbXZQLH8E4QrW1Mk8mmnk1B/fFzo/0CgbbUENONUHo49aM5kwoNc5MNsPoqEs8dzYo3QrggWYp4kPbEANUW12Qv9eJsthWX6zX/rt/ieJkvCeZ1YwTJpbW86WQnCC+sVdIWoq907KOGubl02U4EDfkZRZVaDHbyQ5Q4tuI6+tU9n7pP2c+XZXspUTTxoj6TLIzOU0RRYV2yTlzxBIY7RTaOaRFcrltjNK8x3J+BTW0suoucQS6zXf/ewt+SaWtZq+aROYaUO4uDHVAmPmzy7Cm9vPAA1R27yubXhCkHWNZPVtqbEZmHnDZOhIOvCMpg8ui5OH0kqz1a5NFcZYHkWynCLrliVV19U4roNjupNp0NyVvZdl+o4mLE2apwV9Uxy0n6EEr2HPSgWBtC2o0WehVuZyUABafocHvhHV/5LkH2P5Zd8ve0tSS3YA1ifw6td8o7kb1uQBpUtGXxnm1MBZY9B8gyzpsvmUzk26NknM/NzXLbGIS/uDVirdo5vqObxWlvfztfGkzFqhwMa3sR8uzs/PLyyRvDZVhfqrbWHh+UPqKNOVZOpeqXXVo0btfHFmNsFCsdojC2Mg4s2F6pG9wmzmluXoq75fZPquLtI3SUPiAT+Z7SxUrHaPvjm/ubk5u7D3gY0RqzDToGj0l6ixiXpmX+TksKDlkxX6zw2hFfi3hnRy8vaVpReF/2Ahhoc+YuFJWog7tOxLfHDJJFQcZ6s8WjPx3+eaPMuua+T8P6s9sol1YnoE/3/9hINvHlAtA71JgLePTO/g1uPfzwQxy9sVVnQG33T1l5a+/ew/6o2JWpepOPtc1S9eOzl+tc+6tnjGqlZGxgHUxK1cjbxtI96dr7d8WTnKUQ3e4XL5tXpae1LvfXJ0VDnCd311mim8fEKo7GOo5CQj2sQv1cpRUnH1rU1XYMvUAS2e5YTrRS0t0TWc2NQ6yfSodhyRRDie1Sp4W+2jQY3atYp+slI5qjZqR1+YXsVeV01D51h9pfFOi138Bpe1sOwf1xppM43Pe3CbNX2OeJSxC7oFwaCO3H8x5HEBs9UajUa1qscDPjZONGqVo9NGtXaKQ3Byg/Inj1qjdlk7xadOnuD1i1CDuxuaTo/XTEVVR9WUn5zl1tvzkyqSHjpVjryGQ33ZaKhhrdSsRJ/4DN/h1spVymuXiDVyi+pepfaoZV0eNZyc6nKKGqXicw1rAqhPa/juZ7tBI+14f8h4bzwcRiijw4U/43J/Lu2tyipG3yk6xlF8/Rk+PZ5rXqucPTxc/HqMr15Fwb9EDQaq8QesHR/fAjSVKgjJQtSOqp/fa3q1FilC1KqvTfEfFznUHh6hF58fcQSPVN8ehUKt8ksAPfqjkfABPmMDT1Wv4NYTLfFgAqHsOD67eLh4eoe4VRqvBV3jNbh+rGLHS9TEu5qSHlfvv9zcfHz/umJt5zWVdDDbY+jLYHbL+H4c2GYYqFrY/anaCrAHy/F4k18L37z2kPQHea2qvkUVxONiFbXar1hov8WnvhRLyKOKGckiQtROP24bFPsERWsCN6JWvVIfPyKbXhK9b+isBjedZSuzse/H6jkavMZ7a6+wX3nU4MvpH3QpIWFQXuH106uLRN20di5rjET7DDosYLL3IVhq6yiy4a/dmWgf8U5C72VRb5hC7SLR8peoUfO2BahBH36FUWn8vhG1h40vrFB7tW1I3mRQYylqsPq8QQl4QpW1TEFAVt+Jt5VK5ZhmUbPVU1SzfOXNGmrIyTUQKglqlDxcqtUO+VIPAl2zQFYxI8wvSNtZxaxckp4fGJvTPKoSukBEtbtyN2ywAnJ7zbTZjtoVDv8FLUKNkZsaCsu/i9pWXitGDVPoldjTFprdUNUAdhUlD7KoKVQjXA9RGuRRa5yB5Fe1p6i9byRSM/Ui7NBGUO3fQxUsy2k/8bUYc4OY7aSEBGO5swYATbYLReQG1Ci5wdX+LbaTQ+30VzWX3+lR24Da6c2FpjeFqDX+MMUXz0CN0N9x0rxX/g2Ks6b2QEFOIueq6ZjhNbRJUIY3Pq+iVnv4WFOikyaoKa68fKW8IvsZ2HBb5MrSeuQzO95lWNK+BVvqFGPled6KHC/LZqHVX4BaBcb8DGGp1qIC1DCb5T3edwmMWKyNgKKJdHmyzlRKh6xoy6h2tB9qoI1cnH+5wtbVdWgOule5Err5qpZAS9SQKCov1ddrqJ0LeKRyaaWo2Sg3YQBwLj690nSzAzYi+rgfdAu/lUGT8EWhdEsrCflOIcnj+6CI2dZRAyl0WkM9u3ocKRGfQ63yyx+/PR7j0J9+htINqBmj6/RpA2q6uHK8H2poHSp1/vK1ra/CUFcaoGvQd6hFntM11Cj9CIZAEWr0Cew6YMILo0M+nGjDED2kV7VTpNq77aiphfPTWPJ4oyLJS3Is1tyyWQLm/hDvYDXJF6HYT0KmY/5aaC03hxraWlVQLys1mOpkE2rIawD9Jl4DAx7KL/flNWU6Y62vtDLGtIAMQFieXaLApXkJqR58X8xrZ0Qoe+Hi4VRfNqgpKXtlbMXPO0Cj6o8dXs9c4LjyuhcZo6C20jtSZ+46bIR9iHnxLkQVYnV7flDg5S5GrVKpnZygkd24EmxNQqJEUqP+UXmCi1FrvPoC9OuXX9cXLmWvvfuiyn/9sidq1RPo0ZFa1fQLP+L8+fzHb799RjRr6s2WqCmT7lHZjWuo3eCKVgE8LY0ae3OCtvmFct69xRev7ERtOe4iHPcKR57fBzo8lIkiMOO3TsgkKReBVgY2+zaYk3UX9ybUjo4CZt+gX6j2G817tHCsjo+Pjq/en5lA2U/SIamwcCk9OlHb8yiadGDlo29HebXOcxJS+R9FTbm71lGD8t9gUaydVTRqNroZTl9hUICCNMKbqnuippP8F711260sByqCkEYYdKgyd0IFmtzFLmhYFPkkJHRz0KhoXXugSsWqKHG/qvl/MVJK68c/y16DHimRd6UuPyFHAMMAVVLH4VLzx6DTR5AWlVPsxypq6NCBmh4TPygqNkdHtt4XQ3G525vX0IXJyHjddsOIpmEwK4osqgNEK84pNDEGhZtHS7yvUmKLRSspRK2KaotQKtsXsooaaP5MhykVUj/LXoPhsZTzU9kSr2GgK29/QXqLPuRLvDtnZV+gYG0orWIVNYbLol4olW8ErYejxqPQUzt6Bq8RzW4r+9V4smUXQwn98b0bT/1QvY5Y+EvqqPXR/lYAGxgNSy95cbObrGw1tR8LUdO3kiWviaWsVutaLUVtLRqbR201H2EzalAT9vT0CyquJ6h/at+wVa0YF47xaGGN4kYFBKrBmh8SJSSM1mM1iTnAt9fo7z69inBjzLN4TZO9sl0Nljk5USElJsagZQIGUi5QHgovjmMJf4Dca73m9Qt0f6gg2t7mRtSUgK+JIt9ItsvKYHp8renRNt7jR+2Zfvd4tiqblQ75iyl+93uBRbPRNwLzqNJ4hA59qSk+0k9eqfZogtrN+dnN+2PtDr5Z9/mrdY3Rh0YlRY0GR8pRfnL16unp6XP1uahZ3spetTJvhUoiikWsTDLQKD0cP4FqhrHyYl9ZmVR8Ww9vgy7yd1FTeCiP3S7UQOmqqBBLo/KG6khNGop5KkStkkRy3u6PGlF2caUGb3pV0fEWfJT+qtRdW6Om7PdThKR6enSjQ6jrqMEM0GE+zWv04q3qVAUstUZjD80/T8HKqPOy/Ca0tEXAeM/jnMe4s1Cg8DTU8rV6QvoFqf/78FoFXXkJaqDWa9TI5wa8x3tErQKk42tgFayiVq2kVD1SvIaagqHa0yosWMfygbcFahKo4lBgp6jBN0QNlQjs6pm+oWJp4UstrBDBUJEatVxhpOzod0uv57AIQrlGrapQU7JLxZoMatT+o3Fq4nr48MkuK3s5euj+j9fGfKHWVubHICsDO7yHqzNb8VpJDgNNtlm4VllV0Q7UGHt9fHx8aVAjtALfjrX3+LyKn6FfNfxXoQal1RXU3h5n6O0b0GKyF6o3K4sq/VjJll8V8dolFhgnCLXw22sdcX6PZsdv5At27DHR0Qi+wNEjdKV6ibkK8Pf46vcbW9s6UMMjPNXA8Ot5Q3VIMSDtYD8aZ6YO8vDx8fgSn76Eh582B5oKcAvjFWbTugSgFk75LIQ3vAUh6BnU4n46FPofMSnQR+SnrU3CPEMSxtutv2njgpnP+ppqQN2ah8HOUXJ3Sit3Eyby5XRNXaFJu7oT+n4V4Eg+mx4nfhJ9Fd/kzZuHi4uLhzd4ymkSbjGvhP0w3ae5y6ZRUERsfBofLnZHbBhBShYrCxPwWuJWs1U6kQDUUGgmqOVrp368xmtchtsaNfmnNAkIskxWIo4KVcZn+hrqUo47MoXFhvxqHuNKOl/BwYjabkpQ08Yq05YRWaa+ZXxFSepckuNHTW4r081n7cs0XZDm0y+NQUuTDMwNw1VI6xnI+ghPs9Petjs93CNDVnktocV6LgMvzM7KjNDSvUJILj9Vp+Diyy4vqhhUfpzZsgpmXDhZWkkvVPfkitdTgFmmG5TkbtdP6CrSPhGdNMwSq5SZLZcmbVkXUb2xiKXb3tlqsqu+i63m2e4i0fFWdQnQ+5flw949hsmayH5qXWsOh8PFIrMZdFB0PMl4OR6fDvt9vwfhueGfBv5o8m02m66fUcfj5ZBTco1uSu521HZtdS9YbNIdLasLiyy2WRgOR5PZdDqd8eAF3vF/kEZurExlPC68QJXI5MMx4rtSb08jCWp4XrVsLnnN8lZhwyCCMsVVG/EOK+BA+1FTqn255XJxopU5VRCJknZzwqU5H1KhJmPA3G0uF4ZgVcTqWtEaV9Hy1gG170JFunqGkkUpUe2+dnHvZ2KvjTphp9MPlkpftIZanu9ejtf0Gq/U8ecs9c9tRdfPdufr/DPahVrTaLtKIYXezKQ+JUbpkANlZmTU1EK3/78FNSKuRwFd3wPzXZuh4Z9PjBU6pb8j7chgLesfyqD2B/ylE3jxGYi6HGo0u1Xe35rF/KKowX/juyfOgukPPHaUUivueAMynv1Q0HahVuLayo5AmehZANYU1IsUtTV7bTtqpRdEDQ2i8d2iy0buM7xFz2/Eku3ewHLGP5bXdkhI9CKisMaTq6UfBB+8Ek9Rk34UKkrOgRGTHXva5C7NX2enZPeJLuOf20mJ6m1HZDAy77mTO7e/qTJlK+vE4r8pQ9E7MnC5H88226VFvphk6+/ePpHiszlTKscL7YRZxKA8cnT5lyRKTRv1QhkrcnyztgXFx44vaae9xkyYOhkGg9vKls7iR7f+agcWtVu8Nw62pGNr3wT9+ysfTu+WdzsQ697NraQcKTrxai/qbOWOclk2dXabOj5EYSLVEWdK88ctG0Cxb7x29mj7HpvdR1jQ/J5bagcWvo9tiV3vY7asbxosfFzorZmba1JVCCv42woguoAtW3stN9wiHtYltAgwqEPmu9/SkLUjyR+DmsqtGTQxY5JLt9dBOSJ4K07I8dWYYVx00N2cVwmoXe/qVeCPrsOlm97utsDEo/Se74Cbqkf9KA+ayCRgRtcjH/Ont5yiR8Pr0cISde9v8hoV/dGorfJGNqDG6Jte3VmsTBxx57aGMO9H9U97ombfb8OsnDmf3+6MQT6OB1rIif6gnVKUnMtAmN1vSrkhDXmXI5nRtsvves40pNqLSgaOuL0jtF+/2y4h4dGh68Gjk4hk1jbf6xh3O/Ud767rTAJieXcbagBFpXvnuXey+zyXe1IDnU/d6URKf17gkjaNEL8ULFwrr6sE9WDRFTSI+b5MvuOgEVi6mmbDOVPbv4UxWPORRmNXqiVDdDbKye1n/TPywfWG/c5QxiObKv995Iz4OPBdz9q+OYjRhdMddjq+xDTptG/XTsfUfO32nqA4Bo3KuS2sgYmRO4V7xnGp+/cM8Xk3bvY7/Vv3ftNrwqj5PFg4b/Ko2nLSm0ZPJTfcezUcblXW+fTDPI0sEIOLjkqxTEhEB8LHcxOc6Ix4YZadt1VuM9Lj97zVcl2nHunZTwbccev1kbVdQYBCj99LeNRxnMyW1P86HR0dE1DcUjXLcANq1OJJFXtP+RzRTsvzdO+vN/aT2t26M1xlxaiHbzmN9lWDGCpWRQOsfgbD7fXFcvU2UT7dPEk+mg8wMrO41zZlNGrKWPmWeUZacm+9U9T8VVFtATMeudYOhFkpCQuiQMV2qQlnpgPKMrm1mLRrJHSwymtsGdQUwg40r9F0K1cyngSroFobyR8dlPuQPUQoncRmGuv0dgYiSZ/VTrMukjS0bdmpssuSoDCxo8jODOmOWUNpsOamL6n1jMu493WuBgSXsh2zgKGFDabBaK7DtPDuCy9e2WdT8BM2mGbZV5wkOh18GRrd9GHxmVP4EKk3DzoB0XdR0RlEGdRE5wbzDcNBqMPIUR9uBYxp+KSteYUaDfoAA7HafcXpFqCGQzXvDPqfUvNJ5f3Sead/E7LsYMOlkJpOUgbN63GOBh2LQkuYBdrp9yNzdC21OjedwEwIBm8QLnV5FB1hvx9qMIX6qCL3+PkmFDqMT7Fb0S5fKczsb4W8JuNJX+U+E6vpjnZkMuCLR/fAWjyehSYrAubPohVnWa0UF+QiCO7UWzj2c+7AXBUTp153pMvFou7UlUVxXX8i4r7utCI2AwGY/jYHFbd1B2BpwsURrqe3+Ch3PDGqu/VFihpUMITJgJIPVUpEDQboGm6uO90kbUTJ+7GDNbQG2TU0rM+gJRBrbkRvoY4FFM57uqWpoOLaxXo4ptTQ+R302an3Aj0CPpSMMkeCdVr6VszP4aqlTzghFjF2xfVVT8Z4HavbihqU+kUZOqXJV3WyP2VRT/KWvz0GDZhGGMPBSLf8IFLODBYzmdlGel+gvvedSLTwlFBQ8kGN4u5obrVvZ+FcjsnIRUH5X/eJ9OuRkOPQaXZkiyWjcFHvk+5d5E4/8To8KuPxPGhPv0VzsB+/OQlqoAA4T4SMHBLVMSUQUSN0XO+F82AEs8MoVpjI5HQ782AYO/2lUkBDdwJGbT0UchQ5d2GpJcgnN/bhvukEZMHE6YU2aIUOfBYeqLB2MHZbWvmvj8iotXQrDOuyb4Fm5QY0aLm+ZV3HzpxYLVeOLavThenIyNTpYnUtd7vnD8e7tQytqeWsJOUoNKnW9hj1wXI83Cggda5EuiOfl0ABNJkTKCgHM27seC4nmYUkHZX6sOOiAWN3ASPpxm5djlEk9qafph4O6TUMelR/6rQWYycQXit9NnCuw9K1D8iUHJu28FFQOKFNb/KpxxPUYFq6sNwu6uHQCQ1qwC3dOUq6nttJERrWb9Xy2Xd7mZmOqNGovujE/jVMMK8lWN2VTp1f446HCDhb9CMyRGyHzi21QLyPQN2g0FTrNrhbohbUXQuXYd8dk3EdTSDg3T4Jeh7oDyDYJRfQGGeiH4IVc7c+VLlBJ3Yvk8SIBpqcDJlZqqMkg5z7YsMaqZKNOsvFsVySs4jo1VjhFo30AaHqsP+1zBrqxy2O684cUKOdMAw7o9gZUvrJc91hh8vQdwb9zkLGMvSmYu61UpFD27LlhlN425IzV4/2m8goNIRHnzKo4SiKZhxzYiQkvMnAq7tjsOIG6eSjwde73hCmj9vNSBZEDewKGcdhtydsaF50zqGlSQsApx33OnBLTtNy72FiuIvQkc4wBIE9qQ9pv+XES8er3e+LfkcA0H8ChEpl+ohCgFrdeBoQqFmQjgs1SefOAuG7BTM15tmjz7j0RpHe3AFFCy/1nMhmtMEXCNN3mHWLge55/4EZjVM5kkI0BDjo/eveUSifcw+NizlISHMtcj1Ux8Zuu/T01PJbIxi5edcbwuhnUYM14daFcSPIa0aj7LgqtDRy+hnUAELQFD4BD7FEQkITi1tn9OS0lz2x5XRcb9O5s4YaTm2vDTIMUdO6Ch24UM+FMxpx1q6HLth4bXf854SOeMcZkYDDfJhHvThFDVSVVuz0bIWaShckT4AaE90Y/dnq9SN35ktg3NDdjRpokQYbKbkfCapzBGng45GsOj8EfwlqUHASFioF0TS3u1ftw1nM0yVdKU9jUG/GRSoNDD3Gxg1qTFsALc9Cy9jp9+7+5CMZcwvEXm/WsvSwpbCxWzlyIqJ4TRsAtuxiLXnUFDQ0AH4wqFEyAaFE75ymm/AaRcUjJCDF7TXUUGfwujOQdmrS6DQ525ni7z12/dZwEgeuBwzk3o69dneCvAbLLIg/1otTpyNwhztfuLeImknCQ9TI3Jkigrisk3lcGrrDWy8AXtumtKt3xdwRlGFxz49MAiD8L+zljx+UgJuVPMWSxFMRjNQv1K+ooPEsMDmc5oloPI0KeBVze3nZVtqIa378IRoijoha52Eat2TpFgN7Xrc7YVnU8ITtqddF3uJoWmOqZLjgvRQ1hla20kau8XQbRC3RRmzu9UMxb/G4nXYEZjrwWn8NtVk0RzO9270FLdE0D9r6wp0Cz00c0D6c0HI83GbkBbcuDy4QNRLEIEJ7Mt2RxWi/Ppy05Dj+k+icSo2ahegbZYxM3U8j1+0IlJC7DO6+i8ctlXoLdTqFzgW1M9LRLFigH/aG9vKN4F3ssHkvi9KEgDWDbLO4wBV1g2peo7rbypAa1yVu26HIa3gGIwhKGATRxZNBc7yGMVouQcighFQTYORAF9EBh6gxkqAGaspEkCyvWaABgPIxlilqQFHLmwwoMJG3PDSShnHL8QIq7nk8IGnzoDtKidb6wllMgV8RNWi1NejKiJw76gz2SLY6s5aVeVW/O/3qcf5ncmWJGjGoPbkfeu4A+Xh34ugFR5N6aBN99KgyI6dSrmysV2JU9iZ+P7KVGR19aPb4xmPr+L0vMqnPbLMyg+saDmSscLXqT/MpR9R8ZSOTptIsADU+JyuosalsWQY1VCfqbXvaxTz6sXZA3jmoIvrup069A6j1FAywHtE3nFtP9TByc6i5eHY6BQREarDR0BnO3REYjJLbNF1Ww3p/7uFow4R3F1SjBooVB7GYoEaiWHoys/uRYrih7cqNqIGJ0YLq4MseqDHS5tO+RZJsZUbE4n5D2A11zNibNUfNbz1PGQUb/PuYqTeKskn7Gzg+hNXTXywWt+5EraZ2/drqeYLY/q28g+tj6aA/BBZtzJZd5bV4wpa8FtT9ACQmtRZT9egoVlN94UYdpzMYSw+u+T2MK5FbGQBqpJVF7bzVW6iOTDPSKaoP7dYIeC1GKJaoDQN+i5azG6M41LwG6vACvlwo1ED/CaVc6pAmSUz0tqMW30EN+6Fmh0bR0M6+YLw1uMlLsjjldU1K8j6lG+Ey9Oov9EjU6+6dpVPjfcdpwYwNzHXHa6vDAWQdrS27Vc+i1qsP8BHnL33wAD7aAUFR14/WMRSIxpnjTKhnLqqgAI24UwfOmtWflt07r+sGe0FGKtBRHSMOqnkY25YjzFWH4wk27braCBH8JaHS6/otTrzwrzuz5yN0nZXgPVNmofn49Bei9ldXoYaeAlj6OEpn+6+u2Bm9zxRjxlXYe8aJxlupzIdbzwTSa6PZsaS3nqDHMMJ1Lt2wpD10zLaVJLCz/hU2VxcplhG13x0fZZlH1QFtIghAkUiu6aO+7TBAH5RlL9MWWOappXOEBOhvZGZ3ltkgBS0Fc6o2QQnzKFVfmP4n2Skk7DWeYWbTF8oPW6g3oqZm/ShCgM3sDjykQwtCYPGdIFOw4c9LbaPkUL10HdHxoBzUJhBk3O25OcCM5KE6bmSOZ1gOudKtmEkhyrSRBgNpwal+NNe26g1Jkl/Nhh5GkmTVbD+SCBZLIrNFKbOpY5qZ/VJpKEWLUNW5PX7YR89TPYdIOF37Rcp/RHK2dftaJkZnLK5041Bmq5IBJ7mQ77m6Zs7GYCT/7PLftIJk9abLyxmImPn/0pRnZptTunltadBk+qPQN7WT3OOrsGU2cml4M+5rMwx0a97SGnpUDL3vJR1T2Lw22yPD6kB/lzCjh+9zrOpzCKw8//DjQi3tvwwAAAJTSURBVD+OaB8ZrfgMs3+AWrnUWhx47UeR8I3L8TsTTITwgNqPInv2jOP598eszGX7x25V+P9Nofe9pSMSKP/7ZtQe6G8QGz7n57z2JC6b6FU6SMgfRmLD79XspVdu+jXLiZU5eOJAP4DEqCDr32zZLvPtP9ZQ1ps18qDxUrcoqnag70iM2kU/qsZlz4tRrdjFcpLnU47L6ud7D/SDiRK7uZZAzkteFLXx9Pitukosex8+hZN8SM7rsF0+/wP9Y2JkPsrDhqkJmIMhvk7dzcqKjKXfwWhJJ3uPvO/vDNQc6DsQJdaIZxY3TJAcEpOKPrzHI8MLQOtO2iaOZI/T889AsB7E408hFYLNhGp0FmPKLn1Z6PCKhzR1YNtNniStfrP23rF6oH9COmvEXwaqy/G3JKqqDiIslI/xIt3loH6jFIHlLh6SdhCPP4NMiDCaJolXcmKnPy9FxKxY+cd92cs6oi56sbpDcz79gX4KYRjQHqPzv1zWJ1MnZHcLWQ1RyxplfY5baw6A/VxSwdhBF4+q8L5mMyjmG1DLHSIJz/t8ZJGD9vhTySQzRGNP8kzeGWGFpz9qzcPKOUCElaQEHOhnkck9ITT61s6nD2/0LrcKf1jtQC9A6geKcrTxlKzW1oyeA/1MWjG2GCv+ra7S8hTJA704rcm8+cbz7eTsICH/rRTxNceIisyUy3z60n070CYKXWl+0Rdjbercs+Tw4/UjKQ707yBq+1PO5QpxbzTohPZBQv5LCTcNBIPxCOnu7k79M24HZnvCAbUDHehABzrQy9P/ARqhPz8ErsWaAAAAAElFTkSuQmCC" 
            alt="Triple E Trading" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        


        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA/1BMVEX////ggSU7KBnggSToxKHXfhn59enfexHceA357+HowqDs0bLceQn67d/r6ufz8/IuFQDgn2Lffxyoop40HQWsqKVlV065tLA7JRE2IRAuDwAsAwDJxsIqCQAdAAAgAAAlAAAAAAAWAADY1tQnAAAQAABKOS2CeHLf3djdijvy8e+imZP6+/Tx4c/ddwCYkYt3bGTQzcs3HApcT0XDv7spDwBFMSSLg3xWRz9rX1g0EQDgqXXdhC/koWffs4Pt1Ljfj0XjrHvelE7kuZFJNSTo07Pco2nbjj7cl1Xks3zmyqTltInv3MfZiS3jwZJTQjZ1al1hUEtoWEo4GwBHNyhxTYwGAAAMhklEQVR4nO2deVubzBrGR6Im1gjIKjEJCAYQYoCEhFDb127H7ifdvv9nOc/MQCSt9lTfapZr7j8UGYzzy7PNEGZEiImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJaUW11192Dx5Wexc7Z/sbzHhwMZBqUvPZpjKeX0j12tbWVm2reba9gYwHV5SPSKpvHOP5VaNemwOCGbfqzzaJ8fyweW2/uRqYcSMoz583pV/5sCUbG2HH8+fSDfYrGTfAV/8Z1KTb+EhADnbOl93H+6sP5ulfvmj8jrB5sYevXHZX76ndt5fwtf+kVr8RrlaTGq+wAXc/bi+7q/fUbnPwDlto9339xlQzONuH1v6HZ4MPy+7qPbW7A1Z6uQtHB4fSL9FY33qNnfPTi0atvrY23CGV/QkGuXzVrFVK/laBvkfQ15sQ+n+GWfrb1VHbgAbgS4m477oT1gZ7JFn2P1KeWq3+dp9c8GRAmdedcKuxh/avcMo5eA5mhCpPA3AXPSmS7EYQDna2aTgO6iQAd583DjaLsA4TJlobcAD2X0tSc9MI5+kFtL9Th9HM5hECo3QBHnr+iozjNpIQhjHAckiPN5QQsxxKjHBtxAgZ4eqLETLC1deGEwr8nQgFZ9kdvqvUN/qdCPlOvFaM6mR8fEdCRenk68IoAB/Hje9KyHGGlSfL7vyfSHaBj+NadycExo62+nYUbIO7NyHHdeRlA/xWQaQiocP9G0JRRjwkqdVUECpdIDz+14SGNdOFZdP8qiDiRE78K4RHnDF21RX7PCqIFBH37y8RQs4ROXmF7ChEokj799cI8WFrdbJO2uW4v0/IGaNlg83V7jwMobZssLkYISNkhMsXI2SEjHD5YoSMkBEuX4yQETLC5YsRMkJGuHwxQkbICJcvRsgIGeHyxQgZISNcvv6UsCbhtZQbTCjV8IKSTSVs1urSS7KoefustpmETcr34ayxtXmETSCki9L3z653x4Cz2xtESNaQ7p81t+bCK0s3gBB3X5JeEr7/vGiA/ei6Wbx/y1V/MwilAfFPdPmquiRfGlydI7RbZNU1JpSkHVIf0OXb6vYmUv3wAKG9l81yr4X1JaT5E316N7heil+TpAuw3977nevF62tL2D/AjZ/e1Sv7KdSbxD8/7lS3dFlLQsVMSdN5lU+SGldA3f9HWtgoozYAQstYK0JF8XjcAP4pVfyzTuz3WlrYB6RGd8VKpx1jTQg73HDo+fj0+WGz6p8S5XtWr+LVGvNdv1INGNeB0DSp/c6vpKr9Bji/9Lc/V/nwTlEfMJ8fa234luSmtfqEQUz4Dqr2w/65R/gaN/gncuKOYnRGeDWJk684oVU8t3x+scAn4aq/u/1sIb/gTRYon0VXk5wSOwqIH64s4bCTEfvtvdypxl+D+OeHs4Utv2qNt8Q/k7hV1AmyYoYwZsVT46tGqBTxt3chVe3XxPUBwaSpYr+a1Ngp8kvWFQ1uLmVMGPmoI64coTKkfLsXjXqFZAf7Z//D52rRv44/vMZJwOs0rmVYI2LHcDI2VonQVGh92PtY3X4O4u+A7GcGg9LK2eYZ8U/Hsyyy5pD/mZH6quxaq0OYUr7dj1vV+kC3Ytt/VS2KEJbUfn4sQvwprYKxtcBI47Gvx8uE+lW7/9QqG0FB/GG+yxeLWwrWPxd84yK/KC2yrjKIxKdVxjHx1dXS6/lcCDyyXnuP4+/y1aAafhB/xD/53FauaRQzpoxG1Y5KL16xhU94iFZaqy69x/H36d1ifR/Mx2ft/NSo0pS+qswZxSN51QBBl5/xbSYYn5FZ4fm7xkJ9b3yu7nKZfDWrjIZY2PFUpMmGFtaVU//JjkTHL8DXvKk+VNQetRbsaOWlrxotzV9G9/9IexeU7xDftLhOq40bdw1O8s6CHcvaMU0fu9t31flVc2ECUeSXG9TOrQU7jtdjTf6n5kICre/8bpfZZLTAKPbUx+vo/VXuhljUh/9zdaKNS0YIwLWwISJ7I5MNEgdvb/PPqtpFPLbcVV3DfYP6l2eNWvPzn+6CnGiWoVjhCq37/QP1/3unXdeTabyaFZCJiYmJiYmJiYmJ6UGFP3JwHDrdcRL63XeCspHot7eThOTWuQSf/DSNCpLg3/T1fmpZPMpPyIw16NnkU0NheFJ02rTsHsjuerf3rH1y6xZJ0clPO+/pJ0uYGnNHPFLNDB+mLfoZkWP9KBqNiayC5NHp7dsgtbu3Eobdn+5l6PYS7r5hQt6c4UPP9WzsVrIVFY2KS91McE3SVz/V24XjwWFKLF0SJrpe8PCpSpvCLrFh0NZ1asyS0En1x7uPgwnRrIu9cBg7XdyD2Cw/TFHcwjs9KyVfu6Y9IVEZm12z28HvBCV0XBtOEFeQj+2uPQZ3tIZHogsXfIeW7gz+zEg0lB4Qa/Cz+WgfRxHCDD8V5HR1ZHhwyvheJog5YYytkZmx46uKgSm6GY8crecUhLzRUn0nxnHsmLHPO9NTHsm5mOGHVtykH8jHQKR7LS9EaGpFjpN1vcckTLtgjdDyUQ7vud/Ny0bFpd/bGMtvkSjVbTDPtwk5jQ8JYUYfnJq9EcA1sZETNy3ikFwEWG9Q4aW6HdE37ZHu5xBCXoFAHEGvVYg3vRuWjcZRjKUZLnRVtYnzCkdgjYBYOeqWhD9IICPZ9pEMNkT0X1vRTEPcwJ9MSsLYItcm9iPlVUKItNOAFyGK/J4MPZhnAeOIM4wjY9iawalMHGnaN00jhm17I8UWxwWhYE2g6Zs2M3UkfDVNJSYbQlJCPswnlqnMCaeG9lXTtJEV3tKlvyVBTa4JIzNJe9hESo4m7rxOF3EYRB3onyfGHhG8E1nvRxylqlkSdl3a5OHXaGea2DWcgtAZW3mmJtM5oTv0sGN48UPf9+dPvGvCxAozE4Nlw0S8znJltYBkK4BPzuu3f5zjhnTupZV6yePX48PTuCCMj0mIXhOOrAcmKxX0SEL5PsF9FYzZjOSR1PpiXcfHPJfmkBbatBj4SoYSk3hYVNoQaRZJG9kxT8IZZOYF4RTnXki2c8KsS+JZPX3w6j+1VIH3TmnSzhW6P2UgGuJ1jqsQ+vjNVwXkzCCb+NY0QEF42ioJ29bUR4Jsxzj9ZAISIlw4Qpxh41Mdl8shIeyCZ/pPOQBPO+5DAyKH69p2d0p5VLNLx9fafMgGsiZlxe9BX/lZrzWxMRXKbHFmTnTxNELtHn5rZMvmxJ4m4HpuH086mBW8uDNF/vfum0kvjE0XKqg9VuC0YnNHPfcRPh7m1SgqN8Hls2KklmaVJB5F5ROjGXZLIY0imb4jbfKrSZggPyNO54dRRN2uD21RMUqL8GhAjkIfBTLeizYlf4aXs2wVd99lYmL6+4JcxkNe93GJxseBL+ByXf73Bl/gA/yfH5Aj8L6P84vvO/j2Bh/QX6Yn8AUwZ4RLfIe+EHIcOC/w89sfDplT8nTOiC/0ecEvX+MBJUARn8hIjnUNOScC4vzvCfrioZSj7TbvRUidIMEWvEnuxjBmzXMNciQeefM2xpzOci1CX0ex4qvaGy6P4IVgYJprpqbxmptrZIgQz+Kxg1QlNnBZ0TUXLnRsADx5YEKUp32oWrHud6A0twMFQUX44UKFIK19kU9zPMVpj5AHXbN8v0sa2hoXIF7EhPSRdRGqIS7vGCf7RgZKHWjViiFLMoS2L8IpjBNMUl1luNB5Cu+S9dCEYdSOR8KRj4Z8HmVJjvTczzU+T0tC/juaxTp0yMv4lAv8jq5DrYx1Ty8ItUxXecTlpCCGMDgSJrwCvih04EtOGmEsQZgdPHZzk/JC52mS6A9O6ORe21PBJ3N1yrthiHg3UuWoGKgBIXL12Imh/9kPbeIhfyzDRYHCp19LQi+MAEIdKT7teGFvShjLkT8n9LlFwnEcfzl9aELeFSHovuD/Q5LBFBz++lTxfQXPEgSwVctHHqf33Qm/4KX6cDYD84o4eZCHYx24NvNox+PJbPYVfh0G4HMvTfGtmoi3IKm1/Dmh+BheirQp4vFQ2DlJUXgMRvE4JAwzpKfoRA5b+PYmva+Bb65Yjm+nus6PsKOGvA0eK4yyVE98W227Mul4YPpC0HJIEgMXTvV23xMELko5HYEv5DnCVo0woYln2w9OmIIJyDAzDJCP81yC76I4+LyfYffjQ3yTEC4E+6pOAE4aOXAt8vUgBAU6nNCRH2Up/WUHz2nxxfiRIWgMdQGOgpC0qx60ykDYTukrBw89x2diYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJapv4Hwd/jsNbV38EAAAAASUVORK5CYII=" 
            alt="JW Real Estate" 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        <div class="logo-item flex-shrink-0 w-40 h-20 bg-white rounded-lg shadow-sm flex items-center justify-center p-3 transform transition-transform duration-300 hover:scale-110">
          <img 
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQsAAAC9CAMAAACTb6i8AAAA21BMVEX////+/v7/ZgH+ZQH+ZgH+////ZQH/YgD/j1b/5dT/z7b/dhP/hz7/0bH/wpr//Pj+awD/dyL/bRf/6N3/7eH/+fX/9vD/XQD/5NH+cir/u5T+g0b/8ur/kUf/0L7/y63/28X/q4b/v5X/tob/nGz/yKX+1r3/18H/qnL/rnv+pGn/yKr/n2T/zbL+lkz/vpv/fTT/t5L/i0z/lWH/gT3/qHr/m1f/fSn/cR7/iTb/vqD/xqz/o3D/uJX/jEn/nGf/fyD/oXX/hi//kVv/uov+oF7/hCf/eTX/tYEn85PQAAAgAElEQVR4nO19aWPayLJ2a+luCxuEjRAMkQ8KRGKxCXa8JuMkMxN8J///F92uqt4EeMl5z4c753UnZhGtXqqrnlp6EWNv6S29pbf0lt7SW3pLb+ktvaW39Jbe0lt6S2/pvyn1h53l6R+H3X9mOvzjdNkZ9v8DdAiyyedwMBhIlYSQAl5Voq/wTtfoqr5CL9Lm1j+7PF5O7zLVIN3dolGblCaDtPe76qXN5X4wt0rV/vBzJwv+XwiRFuNTMcBCw/jkn5riMAKiDMTpqkj/XUpk6zvgB3Hy97uD74vpZtL556XJZrr4fvDu7xPkkL/W2b9DjaA4OwJOO3n3YVQXAVeXOOPwH/8o4bedr5SNcS8rXMRf6AJVwbl/J6NcJg99trnMG6MGMPMzfWH6k77DaxF+TYt69P3dCYjO0Vnxy6Toz76HihS/XY0SU5mlEr4EWxe2swTN70EjK90dbN0bbN0UmLfgVZJuKw22i0YyJaOrY0WM+Hv5izharO8US/325zjn2EQoPnCNwy/USPMBX9nOZXO3vT+wxTniUMuDwHxgmJU+eP2yDdiirG2fR2NDS/8vH384Vr26WP8SayQ3XSm7V0AJ7mrUDTR9N9eo27pqSwCTdKvsZ9NFN2o2FzM09n/zeuVd3uY8yzuNSho3BErO87Mr6NhN7/WkKK8U+a6/Zpw5mpv2Bt5AM9MFwyvMjqf9gdmxNb32fw3cpcDrnkde75P32bEb8zpvyMkcsW0p9JlnlxdK9K+GrybFJynCH3UfgMIxns9+XgebotzgS/fd8a9HMZ9cjUoMZzVFwaO5vatBC8eD9pUZ4bGfWb91EAp5UL6SFN8UGz0kDXizpQUuucFi/kXbCUcOT1BsK52sb9N5S9wNPzZIviMjTcIFzTsadQbJ966Q715FjORIWRQ3GdcC4vpnu+0TxMfMwCGD42mHAhYNvOKaUGOgqME8vojpN1dq47rPek6kzHfDOpxnN4oYR8nLpMgVV5ws8ganvyK9Puf/gVQ8KGJ8y1/Mdy5F/JDz5iB5Y7Yn7Yx70LzAti888dWHy0aOffUyf+yfahbbZThUKPkyFvL8JVJMlOl+kFvgZsxK85bAOkjaz0K7FpJ3g/7eUHt+MV6p+1DECq1f1xZM7S/TpOKbcrE6e/rvpeG9kHdZA5MN5Y3assjhrjlF6+WyY8Lcb4HXFwPs3o2mNO+aJ/ymQAcfvn7wUMNCrgexQeBlVSk7FuL4ecj4ppzS2jc1LXPs4cMG+22zuafcGhrHtirwqGPp0Pjus7lTE/Z2yxdWlAxDNahk6vR6ol54O1Ka9TlSdJQ7N3c1+B88qv+z0lMNXip1+YyUFNdCHnLeGGfLAY4xdgANflbM1E/qdp31m+hnmMHdYd8ahe5BvgbvGWF7Ju1tl5Vn+0al8OBQindPeybTEzFocyMbluH34KLjcvpTpn592x1Aij+CI+gJvuHXhrg3GGwLZQPvzwGMf0uwN49p9v7OWTwxMtMeRCejp0iRfZLylDtSelWaunaGSr+l5beBUsZRGCoDd3CapNzeT7eYFgRbomx0ie2O67KnFVwZfld9aGyQwC+xIeJeX9T4fZby4CnGWCslUnIfx3ZqYczRiRlgYrz/pSsFECIMI/VPdqtGjMBXCIHftsBW9jQOPQ1Qwf6vQbBFs6dSLeV9tf+n/IOyTPumPA96twBzt5J0DRFREZokxMk6bQ6IbuS+Up4jRPMGj1OezvSabPgz73+W4sP+wE59LQZjxq0e95kscLwd2AHWbM5ZKxSxSiH8hWGsOET+1uIWc+zdvoWBis0yoZF1ZmrzeMZnKF+g9lGhIVceSZoGi/lWDeR1uZcWl115WHDmwYuv3ffVr1N+J5EdgBQiUiRR5BA/Mu6QwTbX4psSLJ6mqY5pNmwD5gbD9v8p1twioqunyRhuKP1rLOvK7td9PSo+SPnQ57v0tJAd+CNrBF+NbjWIICmsiEQYxfAihJVE1zKjRuEq79W/f/n65fdW4ijkxtMhprPMdtFhv8jZC89LCRTcPx/IP/e5aOU7OWgptRs06nb2ne2T0VyWXJ9liCKiJMVCRiz+7Hu1uubR3b0vV8cxzDcc//iacK83Xi0NkGZbr7sd3UIj93VPfqqCp6vB/kDG2b3s9rbKDPa0wq8B31IFnFGEE0ohvETAH5E8SJhlh6a+CPjqRwx6R+WTMj4YA2407Dtzk9O5jl0MCDWEoqGeAv+Sa2djUOjXXlcej/fQ4mskTwu+xY1bNo4xEYxoQ6E8G4B4hKBTI8UeEYCoQs/rWmcyjXPFVMcSlY6Sq1g5z8cdWxyz3OAQy8qoaUBzNLxBa6Jck2x7SVgcyXAPYOQ3crDAGQDXfYe4O5JjB1KZaAgXYUSdw/dYjfhFbTg88IYWUn0vI2OMhGiOtPl2K032gDUHeA9UeoRxWscfPP/rVqfnA/l+V6tmV3JwlvpMEDA3pg4ADZkdxxBfID1otNWbkhHFF45zXYsCnl9LULsqk3qNlUxF8q5gRpAsqRtG3d60BQk7tNRFNajTJE36ZSA/ZDsFD5UBPmuMhLnb904c01g24alUtIhJqeJ//AZ44Q2v16MJWCN4Q4S0g8w/DXc7yrEtbmr2dvtawPa8PZsLmzUbyIPd+YHZtewOHZM5nNrDYR6OwdtfUmGlgB4KKyGRVHrEOUtOygL+ThAXqVzgwKAKvkuN2cV8a8682voC72XLtHDIYtnJ94csyzlAUS9lKI/KHVrUd6hGPFJ4duOeNloOAfuC7E34rz4hFIj7NeMe3tiR4clvwjNQyYGJ4qFVNHbMmLY68YqZ0/VHfL/0BM0XjyUsn1mO50lXXtQ7RbSO5WHPEw/Hr/7o6DIC00ykRXoooTtCxKRQlSoJ5Y/CG0qPK3n7HphIgws6tupjXJmRbYC0NXiLBBYLNLRcQ56eREd7ef/13qE8bu2nBXcjqDX9Dn+xbVop6pbKWBAGNBQpwkj+1m6IkhtjRYsISSa06gGLRESVI7xnYsALZ8NlVw4G8efKMxGNxfJE550q9Frd+P01tLCddqZbUwQNA3sAG0xi7aRGMSKouB/xp8ZC8UXYSJA/rvh2dsMjxTweoBknB0d1sK/vDQh4kjT7bnueFn5pDXH3RN77qqmWju4FaBOlJfH/3xPGrDoLzCekLs9+k2CYAb5GALN408mQe5zomaCg64lzVJLHVeqgq6EsPS72fjc/Gco61KU//hwtPGDcHiRnAFhD2aNPfXAfmbVo9z/q3QJcoZ9ApYI8RZFBDHGROjJbsYIqigcNQ8hA8s42fJuL2PaSmeavPph697+EFw1G82wqZ/Mx5oZaQwYvqg+fLu7vjy8+faj6JsJnjWLTS7i9AyirCBBGqHWAM+TGFMka1AAvCWiBXg4YZ/J75isKHy94P89VxdwX7C05dxJmvr7EF8YxcMDurB9DZcvEVulylibtal21MdbpEczWbWSrD0saQvReQEYUksqLnJvcnhZRr8UH5QMDvILkKVwRhy3XFU/78zT515f377/8q5dyH8gc+/jiZHM8JyNGDsz47JEU+7n5k14lxuy6NHzhrlHOTuLlMXQwxD9I8n5Xxeu85bUEO8TEARRjfN12H7D84vdvsAp10D3YuzbtSUv+eex0jGcZ3IGpwyhNljR7IfW5wWODNIpMrbuBwkJEDTXc8u6Mc1uuUyDw0joWaIGoFGPmwfuCe+inSZHdxJIUNCxA0jxmx6EBbRr5qHPPYqens7b4dYtJqLD8y4cX0mXhrfjSibPZ91gSDggZX7Ws/vXQyNEiJokCmVLidLNn3PM/YTFuDGEUhSomhy8dFre8HrzMF8bQsQrDYqeVn8DIXP71Xj6fBt2bwmMmQ2Ke/f79GBc9H3//HbnRIK2vC9W/+kKaSJFSq6q38jJnHqNRqk7QxUGFHstuK2XWtLMs4etYU92ztGjQ7KlkdUdxeS98uwm9EZfwNxF+3/WJoZCsbH358qVV4kLcJ+tLfkhhS8fift/NlB+gLaZrDOX569csvqBHPBtpWy97SlS9ZjcngrxNGjjQkRD5BX8E3VDkWiEOMu5pJ60tYFFu2k8Dzu1FZ0A59kgvjU9LSX4betO9upnl3+AA6EiZagrxd7MoJx/+5edtLYuPW4TYGTmePZx4TBHFbvR85gA9+I7WOQSkYozG5Y03+uxBi5bT5JPU5cGr6K5T1sgDafybcNXFcdT1IhKefeG/m6/P61RLBt94YDsSzbPvsaDQDSI8hDkh2KmQTrEDakvy1MBaxAmZICiGL6SM+9YR1d26kBRPxpkGwsUtvFC0iGI0xtA/FHHJrW3E/Pw7BHnevmCeGBjIYR4h9B/vHQBUEeOiow5eO84UGXYW6G2AnS3kRQ34OPx0/9uz6WIccK8Sanx9N5AQKVLFREgKh8Ka88u/JVljYLcpeEX+dnDpYbEvpi/Swktbxqa7jLx1JLdQc0s2COjsp+M2NvpoIJ5L8vBsD4pmC1rMMPjc2v0VrqQH0qtPyNtsJ8tT6QWdugthRkHZr7z3hxQIkDT0Ec2YoeaLyMeI9R9CqMK8+womQYbfpECziX5oviAMf0n5dvUKZOvpfFH1cBPENtBChsmJMCWAILUav7InPr+MnU61G03CrFVgEh92JU0lh0aLxpo1nkyyi8s+sgPZjF40cVYN6qhhYzuANdtPmOft2Db9AFtLs+C2NbYX+3WfXvLZndI0nplnGKMTVsYS1WYcUbAyFPRJAIDFOoCJE0c4XCHGsER3quxxll2FemotJv8s1OEtuikCY4rWzqX9p5OmhTWk8gNlx8Y4bRc/ZG4EHcQGjaE1ry/Y4MY3NbVZzWrYKqgFyQdYeTaejXwOhgaZyig2IXoSIo7I/ojf56r24jtYHSFJFPwQxdqmRIpFYjCFSGmQtk+fTLdW4Zl+pT//PlHlhPfXo9xzRhxoGsro/K/wR5oKrcFkJqWrgZ4R8kBSW9yiYX+LrVieIDWQP3S9H3wZQeKFYkBMni/iwVOW/d3uysys83B19dDZa+Q+nV6Hnb7r4SCH9yvihlBHvNG6vH+3L12fGL4heFTjdpNB2PymK+wihUhzkHmFS4MHsFR5//JeIvB6ZRASh4PDoXMeDcKaHWY+SnpfnFtkbnsNX9gwSZNF4GJ+SRYW/sUEnvJ4vddyKm/uQdfpOTJCxg8JWBDvYwN1NFGyrZEHt7iNp7/+Te5hH4AkeVhq/1dvwGNsJ8jXcB92vVQkybP2haWjQQvf5OXFFOd3tJmJpmYkj8dudyJjemsgfCoufyNiYDAGOUheDaG4y64M0cOOAWJoVhpECkFIccfgAE2d/hkanaEOdoSCloXBP3nYQps+Tf61m5JgT9/9NwOlL8U7HfiaF/slu4EBpTlyNPHARb5YGRa0BNeJ53pgIzTFYcGOGNCOnvXhwCQ5oG3RQnhervLBgPb91bUkYIIpSqxRf1Hm2wo83P7qTpqdz/b9qLXrtfhGu7v8mljOLk2BoR5i7QwKHcRWfTuqmQnFGIvdOjC8P76QMSnYKNY3vKsVlYLx+630Z5cWIggdAv1W4rC3rpFfUDKj2HijsBRKHJ/1KYcUZvYpoliHvKs8PtAqsckoL8uICZ8xw2LOtlAuI2hDq0FoDGmYjb9itJm+XUmK7otTHApeLsbgsudbKQO5oRAE+jDiaAYil87eUU9xXl6v2gCLRoHP8Zc+5rgWZKwg+IBXpIz5SzPJ4BsUge2VYd8X7E7Py3VRLSWbyY+QZndoqR4O0uBqyHjgo7UTl/5YMTEPyiOJ8mR8+ihUWIs53F5kfM3Xh5JgJaRJp+uWMttVAd+aClVLCcwx3X8Fi0VVIYyKR7oDZ3Rv+h6U7nFJgtfJiBN+L5WfwBAitogQzxQSfk+2GchUrJTv8cUXYOIE9mGgFokFWZkSlmGbuCF+AEuS98+OJVqOZjLkYoXxwOH5kZ8OhQYMCKC/R1MEtsiFFAdETEGv9eHZ6JZu6Uv2BWMeFxk5K6+FDg/gBA/8F/KhF1gBaZp6Sh8eS3l8CbPB2S1aZ9plgTJkd+pPn/L0+0MfrO7VBS1rIV0diYsznFwvsqznIuv1tdTTboomJ2iXceU274SQoquk0W2PP5xB/nxca9vkpG+zC0Fk13SHYZA3mRPIwL9D2VOjExjjkynsfM7PBzR5CmNH5nf3Ri8+gb90KeLvhZKHtAa1EaERj37v8ZcUgiVIMLOLPxgeUTwDoxXa/ShOB6huUT3HNK8rPpW2cYGvZR2wPe+PeCrRmmvqx3thVmORmocXjHA789RyE/gsoy4F6ONlDiKwGOjYAqljUAuwv48q6J+Dtv0Bk4MADpE28VFpn6xTbo1gXR3H4AnNxwqMLUMhp4OQNAlGX0OcaLtuNTSqidh5LPLCvJnH7IYsY4B4QWslQpr1FvFN7nGdIb/+NkU7BHBW3hYgBKMBYEVsNCtQ6XtBRMyvYiz10xBQNPkkybUjkonuqM8timsrU3GB1AIBMAmhG6W+bwcOXGOCNHFXcbthrMm/7GVba9tcQ+7smJiDiTZDTHGaMjNDuF0HXwwwwIcYJ/8qQGYqGkq4ldZ04YpxdVt+jtKjMkJUNIBNLMKshEMvfNpnrjNFhrWmigtM4CSSR7j0PP15+wjpc1fqYAqg9NpfpWlDdfblhRhf0zRRLPmTGNxEbQDdBG7I0QUHjbsU7eYDC7JgQh5mIO2trg5ox3oBj5DACcWVMPaKvIMJNEWcUItjjEvbBovcjlDy7VBPvT4OhJ6PjcXgD5puopHj1bE0i8bUv2m/0crAI2zwrB5xGsHSjldICgRMlE/4eD/ROGYJbbAJ3jtdYYCBdtYMwZaYHQuc3SKjCSc7jkq90iTGQIc8xnBnukSnBx0VuDx4KGiugg2/DeThCufx+QJsdloJKAaHiQNIxtrXAiflUZYVrHEPOD3bMXjZ7rRMT/94ek5rQSjQjxaeeJfwHfGw8R9YhiRDsw4YzIBuDbpAmUR6jRbiqpIMefSRZt4ICGN5iBYJW3SFiXghMc4xuhMk3wZC6eMzGunRCVriaHvLwyG3IwK2EAEwWIVK82fMzRM3B/o18yM2P35YnGjAiIQx+b4NvVzbkfKAlxcC7WKAUAhcdMepArHhQSiMkRGRqF8c3QsqFlFVdL8q9cLZ9ETGdAm5ffAR4FFxBcpcuKbd9iALsbZnZbf0m0CTNxqlB1eJN1SOJi/TYitygUw7wkAEaMSYPMZQHs3SbbvCUAVehmpkKLxBO2y60H4OHk1oLlMfjhbXkfZ8sYr4EgSCT+6lcYihusFRxsoLSWEPISCPUtzKNLOTraI7809IyiFepCsRg2+lP1r+0L1ga7ncJoDB0vWF1EubQ+2byetWalea+BVpkidXsYitEx7Lkyno1t6fJ8IGb6BX1+u89Q4xhDycEGNfKlVogtr1s4Oj2dHAVI5WHmiO+p0wq6iV7IxTr5vp5sTEgVRjL1peKCbwUONV6/hspA9vTsfXuPhO6Pkp0JXX474t1P4Zm07V8kCRPMQI9Xai2s959v6EMBh/iQ9qRdDyQAeBaZ5FWfZKTHj7WpJFQzamPDyMKfgDM9aD79BU5ZV90ku/QpyCye1iLVVAR1FTT3iru8epb31qA/HZ+RFHNe8VA/Std1LoMAEtN1OyjiAWOFnyeYOz7OZeGjMTVr92H4DtYJ0CrYsV8uQhAU+UDb/rDZ3EGfJqCOb2jGaVCT4ViU5vuuQawsUB7NSBW68wokThi/svnqQqLf7JSJAiRnfd59zHTWr0a21w0y/CjNmBJD9VWweqdXfr3BcpSwd9pbg8FobNUaLBq2X5l3syNMTxpfZnWPZAPhlRRBkeJfjz5ZU12WPQv8Ulsj0JGcR6QEYRgkgRiZOvgW0wrBcuj03EHjAO5l18EXmd3bk1zLqTwx9me4gVQ/JDm9kc7RmE+LQConD/D8CwdHwowey8Xrmbi/fCziAIWNeH7Us+aDhQPHRRQnnHHgYcYR7eM1MMorvVmuDsGN37mEKucupG17b15TkBXy04LQtDQPNBES4vVG0GP9SESG01hujKvj67ELRUXk8OfYIdKsHsULHYjzJ1xzTx4hJCfGaqVZmgZ8DlJqioWBC4gEMsWM/hA3nGxFQ3J6DAYeC92gEwjk0EAE38w5qbUJUJRb44b+Yl5k00YNPQegn1nABwXvcm504qLD3MLRSMJLnCeV/SPuUf8qbXFN/+GYX4IIwIlIbYF8NTfnC5b4k1YHk4o41rXO6+oBotphAfkOTE6X4qCVGGAJp01OTBYWkh07Lvi/Opu86ZvVDcwExfjLhBMzuie55vA6eGWywnLSnkFOll8xSeYclZ7lMPQ1urY7MEFvoq7i/B+SumXQmk0BMgPJ19Ij8ULb9jXOzJ89GJHIz6TQtY3YjGGsnI4G5oXElLi+AFGfGlaRc1eL4I/X3r+OUgNyTwTH6nypNvktxbXPEcyvsJ0oj5eYhs9Z2kuAVSTpzA9CvLL08GwBW6TTwYwkw9WefKRXyPu1TSqnvZN0Qgx2EBriBOdgMtBkeJoblneQYv+am7qOmndOOFwjXUHfnbOrZvwGBD6CURL/bWAoGcI5cTbFWM36Wjz2VjbHo/DMxC6IBifGmvuRo4ANlyYzb41msEgp16eP06Pmt4mTICDGYIveZDT7Jj/MC4fi4czvPLUY7zorcDnAfFzd2AoEu37NxM0NF86PBAb+/U06ffYSox6AeNxItzO8Ef6bCWsbF0UelDbJdPwfzsbWZ9+qDZxhfjWoGd77FvBgMYHCciItrAbxaoybuEubs0DTnsdrjBswIg2EAAqi3LU8Zd4XQXT0Gge8qFtzOsykL6kXBvKBhJE0+XNItCe/wwrBUYokKOfBmK2PAuurncEw4HZy/ISGDj38zYqxZ0Ay3aZRfN6lAYJyuWx6Xnm2CDePZxoGzlWwxG8qnEIAXpIMWzf+XGWDW0KD5KiJThdhHyAIHUg6Oh0TYN+PpJnUUQH/yVWBMPsxTfJZWBZplyXqzebxT1Ii12kvPhmSX/8Bg9hRAnl0n/H9deFngf/oU7eAdHPVxcVHVxCSzOA8LxGHeZMQIpFJb9z0CGEEHto6UNGhNnpAcXZWANQExJq1D6ZKLXTUJv5eGQtjxqI/ZKUl1IKVgBYzVC0w5ir1/Ht6UqPd5gyZH1D60JunLNDdCc0rD1RwkCw9rHGvHoVd4N/dITyC4ELJdOp/c+7Kmm+r64wtcBOrJjckNxLGR35goDMfOQ+sSY3jtdodz/gXV8n8Aj99fxQXzOoifPPw/0shHlFSlfVIHb7ELY5XoYxZmZFXs8rcnoVF5ZojB0fYw5Q1oDKLurvmkWh9kkJf+woq/WJihkheXwmIcHyRUdoEALV8T9177fp4Yl+QJ28sDwuPNsAwtMBncADc5pnjnW0ftIxmYdKspi+Q6dafhZxjT7VX6KifEFuWp3uGYASkWuQF5QXpmyS6sLjFbi7hIY9bOc5rCC/MsxTM4OYEECH76jqCrujRdnFC0HTRQayxSs19Q0yvljWphe8tkNLfyYrue5Bu4veziR2K+ItnXcv89MFpSJ4QGFX+G8GLnO8SBmmAihxX8YmPiQ6dJTcEDxusAQkY5dUJ/gYoWYobp/N8B508HdjMFkt9AmKATyvgLB+mt04WmVPkyPBM1e+MP8WrzwsCZwzpkHCOBaYuBPh+GOtfturUiK52ljWS5S8me6wt4Rfx8yPWacde7NCngla33goQEGVgloL8xqihziayGtykkpqmlxRaAqyx66ej2ZosXFuNmdPekFu9NztBzKBA3egKRcS+NBq9FcNY9jD3TP9YIVcUMhMOVSamAT8Z89UzAQ4+xO6jCEEglV1tAiYKQKNwafclSvyQKXXfDLipuuXi0ouwgMqnMfdDxDaMfftN/Xye7zS3MCnrnlcGIbVPUKJAjUxfLTjDUQCiGFu/0lX+lsVKDfPaFkTNvGjInGWet6QIvs5QXQlWd/4vyHKvxgFlj3mWN8DYzewa0CFl0ezAl80VvWWA8iC4pAgyPXKBZsfTCj+zq8aFgWHo+ZYqBn/d8vINY1eEjsMiXKQuPIlRhByPyQXGv8PV9TfGWdm/O2DRzNPqFBIj/RWisO4R0M+JWBHVdww2afwKuHOqk8CBcN7lbMeOMKlsA9UFYac011ffCMSfainxo4u8ZyxVZWW0HaupBSYqjOJ5epHIdN3tHhTNoKU665kPHvKXeaSjesvBooUlyBbYVDln8FAcBFkG4gwINTxJDvM72AA8I7wAKeZZoo2B4cJHaNkalhd2Bftjs91RFYU9npEL+sdHbR/eLPt3ucBLfk6xNgVWbjGUppzI67LXO6m6kAf0o+SPFgux7AIX/RjbFPvf4kB/E6tyDdb13AmjF/vIffBt97jdus5JqRNKW9tBaF+bRoUNKXGf15WPpzRg6iqG7enyV2dEzny5IE2d5DpFKe2Q2alKYQ3l+tC2tce+PQm/UdbVma9AJ/z7i6VF4aBe81zRDfjsCLMuIno053xWSr+CDY+t1wrO8H7YqtVxZlzHOvAHBI+87XNsQjUHAmoVegZR5w881V++5sSK/6l9aubXedbxv0zV0dW2uPaVmeewoJlcC9zNzda54osr1BxDznZLv03eqYfRKJ+cGuQDZbTbhZwrLFXi/RwnzziLE4+i9J3zzhN6ruVetyLBTxWxnppaa4W8YEcSMTcrH/tW1kgnSCMofGTMbphFAv14m9fb2ROTYHIzTmvCky3/WcmF5ISafb0SYVvdcuoq05dGwCzkVGehGbnrKlhV9gucdBU1zh26+t4+Mfn9rF8U9LYeDWz2i8+dV1fEH635LcSl6LAr++jm97j7G3Bc7fhezti7NPb9L7O+wjmdzTlZiBTnuvAzn3q3selPmNebDo8NGW27hsN3Bw0/0m0//yOr5dk81Rq/HnqtcGg73PmhCNtX/GErNfReQAABNaSURBVPEirAFjlje9SAr3Ne+exmzvb/A99IZ293jiJVur0UBTKmf9HOenTE+3lKhTdNiLNO/revM8sL/gawpXAq8AbrtJRIKqUhuepGNVlAWf59zOkTsCU/FgTeSBv44P8zm+8QzXXYPr19bxqf/JuGr3giKhpEy6ftLLWZrpCzm99XA+kxd1VSVof5dVVSpbuZckaBzmrJjBlbSn89P9hXLlEzUIucrB096qamVBqkvu9dTPHG9L1W9JFvC81+sjhfNZNS77YKoPx9Ust0hQJDBvxE1rqZbC6UfLgvjxlev4DGOz4XJcVtPheD6CtJiyYPY4rVm2WeCF2+rjWr1Nf2IwJZ+OytV8BlsmpnU9HffT5ehjyrLb6TivNnCld463XS6mS/zQY/PpIwuGH1UBw8uzcj0tslv8ZbpcPHby/mRU14sWy+fTacHqxTmdibvG4pUD0Jq26su1OZydjZeLHiz4osYtlpvpaLSZ9DyL3xvoX13HF9wm/V4+G3VmKJbJnAWTuhzxXtVDJpxMFkiEMU4LrKugSLPzgpfTot8vpsP+PN3UPJsP1+WoyLJi0foJ20p4v5qfwQlQ41F6XnxkQTltt4rJLM3ZWWe4ADnhxc9Np8rHHSU3+W2WT4uqZqvWCL31cs7yfjEqWTLK+jlb2NOHxuMOZPg5RFFLHiuIrbcWhTcxoGnyEi0aJjh9zM7zUacqO4+K/sWstV6wdJ6VU55t1qth0motO4ts1WqdTUtgzUXWqta9VadfrZJOZ7iqinmaPbJskUzH7XIyKc82t6vVMFudTRdVb9Wa5YtimSMt6lbZScadcbEsb1utXrKqlqNq3JsmddVJ6ml/GpRrtqpH4I3z22ymGjVbs6oeVp06uzUIgbRgbDNqtfK6Nbodl/WqDEYrB+W+dnh57Zrzh9RH1bp1dlbNFq3VvJyftYa8/5h0JkW/bI0mk82qVS7ai1arNYM4+Lg93gxb82yeTUvF2qNy2psX+ce+osWyaneGw81wcaboqe6YjUfVZWtaboaPmhbVqqo6w2m9abda0041bY2rSv1fbcrZY/5YbNJyUrQULYDmt4pirU2rU1bt0apcZo+40l51WNNCDdJtb7lqnVWdzWpaZ0uzR4NAMNCc8aq1azYixjvtnz2WnC9WjKmuwUPPsmV7UUFYPlEIELBk0W6jdlG3TXvLHuOqq7XqGleDthjOe+1OuwBaVFXAp9PHvpIYuKMctUteqkG91bSYVJ1OwbNF/ZOzeqJkrmhX7Wm5UOw+bS3KTTEezzQt2p1JmyuoGM/Hk1XK60ln7NECJYzPk4XqbDVRErroP+YGXA16ItO/5nwtmwKmBmZRpGWZsVTRArzq9mbxUEOMeahokSoEabdN9mk5VyhePi4707HC0rL6Wc97HxV+IF8oyvXKUnlE87ZqerlRtOh1Om1Di0XVgTDvdLEMWBtokSkqLmZTJevJfNwZJdP6bIW0YNPhrUKd3vLnbb1Wspmelws97kQL6KyihWpcNWmlbJEtejvexUu21ra/Dtkfg/GCtj9qWkzr20W9drRYtG8vN9MZZN6MN33OlPobT2FredaZtpdZWDwmi+TnuNUbTWFQmabFaFyylRo3IyPz6gzaVfQyNfDEF53xYjwpGE8/lj8nyflYVYi0WALc8n4vq8YdCGw+KkyiHmoZUcnRglflpPaw0+nVV63j81TPY8l6nWnGNS0C9tj7OBnDjJShRV/p8bM1RKIU8GOgtz/edBTZ8smkOs8Oq2qzSNagWcpFnXLkCx6Uk+pxMe8teueWFmN7wCPQgmftqlLAAXHi02Q+Sf6qVrczpMVtfqubrawZdYtSRTpsuI8WrB53LOv6Fu+vruPj2eMkTVejPtFCkeSjkopNR0El4EXKkwXY+yXSYrQZg6ZXGnPS6QMtOp3z7PG2OJ0mnWA8H/Ji3iO+4MGsSosiHy5ypUc40mK9qvV5OUZGqg7QQjXiNFuOep/Xrc+gRwL2Mb0lSGt1iBb9U+7xBUId0IITX8yqTtu4AnpigGz7X13Hx/PqtpV3ZlzTorccd+qfVcn4UNOi/vj4eArnr/dHxBc8RWLxAvli8ZidzpMOD4bzRVFP+lpGZhXLc1Yu+kuPL4yLZWhRTStgMOSL3mNV3f4OOpUjXyik5C2lbznwBdKGcUsL5tHC8IUNBFro+OV1fEpzTM9mZ4Yvqk51+1jVK0sLwE7tYU3HE2WKp8Nhe1qp0hAvVM8VRRQtFEu1F9lDbvFi/fFxmWm+GAItKthZVAx7DjsJL1j/FvBi2qouf0c9sswQL5Kkaq3hJO9bxAsrIyjlHi065aZuuGsmLP6L6/jmHxdKGkZKcWjsXGKQefbFw842usWq7Olw3ue8/uvjZgqyX45BjyzTj8U8eXxUwMPe9+aWFkqPsHWyKBSDs6CeKvJ1xmpoH5anDT2yULQYKjqNklGp0BVpMS1vVT3J6fJ0ZvQII5fMyojDC/WxmGd6asI5qy/4I2xXjbCPhVJfyWR1Zmhx2i/LMpkpPPBoodlp2jtXhSzLhWJ5BSDrcpEoWrBl0k4+rltnKoPHFxulR6rhopgXt1l/o2wJZV/0WO9nvWEWL8C+UJ1VVl6yUeZ2Z9xD7Kw3VaW4bNP6OR6N+3yszA0tAUQLaIyhxSrN5vlt33e97UC/bh2fhhc11LVi7Go9OyO8YOlpcjqZzidVZvGivVS9AJngdVUvs3qZPxSbEpwnZXcuekve3qTDx466MgQZMXpE6VQOtOjUw9vNIpsWq/HZOluUyknjRo+M21U9T+rb9DZXtOBnKw7+CO+fKgSfLerOsKOsukRZKPnidN77fFuvxiPFX52SG/ui83NyO8yW/H8+Tox82D4+cVZ6fSG7CWtQgeaDkyUfz6tCqX6ixRDNzFoNKjd8kdcqbc7A45oX5XyaVlUKnsQ0Gyt/RPFF8ciHi2qmXNtkOM2Z0alt5Issuw2yMq0vednJzuZ1ft7XOlXZneNsmpSLRToe9TfJJVO6B2gR8MdeNt9kyh85a2WjeZI98kWufJ5yvKoz1ZjOwtpaybAuuPLdTouFiW4ZfaJkvyuvZzu0KN9JUbqpOM1O8PEc9rXVm4Knm9Ui553JXNka5VTh3LCzaCu+WOaFUo7jM6iq6oAcn/d5MlUSqsy9dFkueTov6/VwBGvTFqVCrPMKdOpC6aKz1rzmo0lRlIuM5Z2V4swJqKL2tKNkpNpUeQuws/iY54vZJetNyimaD0NlyrNkM8Q/1l+WbD5UnW+NV2eqNXmpzPjlbA7CnajGrRZ9/rlc+DOz1M+ZlJ92n62Q/IBH9OxchnNHH+phC7zQdL1QVuXk540yIXqLxYxlo2UJjuwEEhme6WU1LOclLGPflEoo0nQ6nfCgnm9ayuYoSzA7eHYOwY7yYZOw4WY+SdlouplCk5JNe1ihPVcu1YVc+fU5W3fKUhEsn04VZK0WC4zK8s5mWG5aChDrTT3cTDgfTS975+er2QIb0+FsM52mLJtM1TfY4HU+rbZOmIXTBAbyanf1YvGnHFxurSTWd2brUYXTBXmWK2sjw4VZRdanFxbQ+QMFHTihrLIRlp6WoxFMthZZrrRspnL2Z6NRjQuo4BvrZwX9rKopMqorq0ZnOJFIP0KFLGiNRkOsMVdGXJbpZS/1aF2iPzhcj2AQVbuC1ueWPoE4pwtwV4YNZlin3y2oZbr34U3peyHP872L3jCKDdDBYcGHPhMPPtN1ricL9ZYFuqgPedIZ8UtAkXH0JvUPXP+sX91NrmjeKIgxkzPg/j30lp6dluZsKa9kU+KWJQnLqW+luNwhBWNfuvKPwkXtuZ3itIF9E2F3kX0bvW/OnLp5TBsptl+4d58t1c0leLd4YWUzsdCYjODeDADlzE5vcjsV4eZY9SFPfnm6L9mhPPmyhxZwzPA4+Uen1mnn1244k/oRU1spu1I/HPyj06frH792w7WUV3tPrXsPx1X8f5ai8P0+UrDxsTAnN9ECSTxDElf24tFp5ukQ+qQrOsvUzrDTQR94liXta9JHANPjziI64xSXAtMMe6y3d+gNnjFtaKcT90JzPJk+Q4p2SNDjBek3OhxAn9VG2xxjeq4atsqcTEWH/MV6swYtgdXNxl1+ofht36Pe8JxRajudYxSbY2GE20Yk8CwP2hRDVNK7LfVzmHDpHR1DHOpnvuG2Cm8zJ61VoJ3x5rxPXXakjzEL7Zme+jZBZ+hQ32PdKdhjpdundwRGtG4aD5bVi6rpmLPQGzJ9YKhuu/zxxMGO77u0R5rWP+hzTGjDFp1kb7enh271BHXDP8RIb6SIaO8h7omM9GGG+C0yGxljuwwj1kcYevv+Y7Nuw6spCv3PjozUSOJZ3VR6iJR7SGPsWuc3vDvdTwp6qIPeHmNOYNG0iPRJUqF9OIQp2jTHG3TTE/fF34ZED0Azq1vcQbm6Z7ZAI5Ku4Lj5xWsb7udtHMBs2EDn0keymc08ZpWMvN41wHV6iOhBH5E5Xxq5EHfX6w90LAo9b8ke+RXp5TMox8IwdUiL2wWe1hbqRdp03K3QG26Rw3FxDdUX08lEeJCy3goT0eZ52sKPJdAhy5F5qk2kKzMggofV68PK9BIeqkbos+1DWt+DrYgfniIFHEYf2mMh9RY7fOgjPbLPHSpFW8QjW7JjFk0hkslQH5pED60iFNHjFYV6k6s+CYRaH+kCQoMXhMSh0DtKaAyE3muGB5/oc2vonASBx49gN2mUaId1qE+bCfW4EP0VW/z9JFsoxjDqwpwNSQUJ3UJz0Z6PolFSeOISheZc4yg2MkP9cIxutvpGFuzNqiyNbLFWZbpAJ5Ee+xvSO0ghlYQKIvaGwskEDmocGUkW8fxpUrDswp4JhrATes+UNu0QdmdcrDdaRU3Y0JUZMsT0orcXWmBFJjCqBi8JQg6za0QjbOhOFIFyDdkjT/JpW19MGG6BziIr8ZhRaR5VxfWzpwN3upEtzGwbjO3h3/rkyDi06Lq7jq+Bnv5fTBsRDU3cUr7IH+/InokbmkOyNII6oLSoGuv9I/pXrEeYSxY9Y2cWmAfz4W+iWz1HCuXlS4QVkg48MpHEMdw9j09ozDQnJJKg2pWHgh4Kqg8P0Wc86vP4EFbNnlwCJjxuSkOUPY9PUCZBcCv0viSNBvoVG2CXMpJtRbCp0cw8aUAbLwgwADfy/HlSKCkx+6hFbM54EUawzS/utGvqd2TQVXc8ck9mMmszzV5dMmz9E/ZDbSrR0USRs7ZEaA7jp5WcET3yTVOTjCh9uDgpjFCfgKg1kD47I9QmBzaV9vAiSeT1i49sqe/xWGJtQGmdYvcAazQ124IF8STpKnc0MdkPts3anAczy57HFxkAMPKszQTNyCTiMWGdEQ2dNfYkIDamFIqLffa1Po8vtFCCzfNBN5T35UukYKzq+k9tCK2aCN1Vz57x/0xDIt9cs1dMHmE6ZIHPAQRZULqnsYUW0/dGZxooGDd/dIRDKA7J2LckjGFT1gtggSlYw8kRFsW9dmqfaqs1FgBN8w20emd/NwA2avZjuwKskqzo2F6MLFlCm8f/H5sd4mYIItMcM25xaA86U5flyfoVpIBJUdxFbM5LsnhEDzpFviSxiYXGVVu5t/9Un2CMbg2KfuxMBdr+HcUGhej5ut6RY7HWufrImJg+EUiTc0qeGAEpnWFIh7zFhvlMMVQOGbeWdeThOn2ZEEiML8dSY7WzsvRTqTSPx7anukWmk4L6qYdS0NdImxHYfGJWYtw40gAhtFkRa2cbj5Cjg3nIjtdgpUll5CxuHCruUiScG2ewzjPa5F21+/Dtp4ixMsfcGNTFjmKYgc6gs3qFLuh3zRJECeMIGdHyzC0j0Oa7ZQhSM8JFOIxx55k0pLwaii30LSvNEbERGw/5NCHpLPXXprT8LvBE0KYqjfTzKpFXm5hJz6onL8p6GTGJCD1WOTLHd4fCOBmGkKF2rTT3RKY8slPMqEahZkPsOIYphK7JHBSovQS0a+h3ZE4tzDiwQorv5S+QAmYwLg+lMJES02CNnbEWjFhE20Q32dxZF1voH9JdNos1x22y0Oo96SamaFisgUcriNC86dBCZNWvYw9jmJNdAyc2H17+4nM5lJyUt0LaYoX1yYy/HpHLqP+I5KE+OZyUmFHssXmAjbkqNAjjI1hMOCByRKTIldBna5HfCx6pZrlQey1Co7EwZpV+3oC262LyHLXy0MEIGZ6Xr4YKL+WrI3yginahPRvcfabWRvayRTgylvzhdrrOg7HYfI79TJQx1sSLImPXedrbaCo7VGHk9CmNgzttJqQ4TyTlUXt3luyVvNE+kgPpONjHCIo3aq5vqPGYTo9xTngYezJmO6PVTRhqdBSROYxVs7OxJ7QuIajyzMeI+uvLIZngJrwgTKuxRNWT09a/wxM2ZYtD/UQMP0XGW9MH1hObaNZoXIjMkfZ0m/bocPuX0M8x0md6RzouRlvKzK3W79Mf9O+2Zvtxp4G6eswt5WBw+POXcWIPOTqPfx12XceeS9EzX3XXdQv3/d68EpmePFW6LcoQLIq8MkzmKOoe/nVe/QcIoVOaDev2PzPVw+yXVOhbektv6S29pbf0lt7SW3pLb+ktvaW39Jb+r6X/BShI9rNHHALNAAAAAElFTkSuQmCC" 
            alt="State Construction Co., Ltd." 
            class="max-h-full max-w-full object-contain filter grayscale hover:grayscale-0 transition-all duration-300"
            loading="lazy"
          >
        </div>
        
        
      </div>
      
      <!-- Gradient overlays for better visual effect -->
      <div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-gray-50 to-transparent z-10"></div>
      <div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-gray-50 to-transparent z-10"></div>
    </div>

    <div class="flex justify-center mt-8">
    <a href="#contact"><span class="inline-block bg-ruby hover:bg-ruby-dark text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg">ร่วมงานกับเรา</span></a>
    </div>
  </div>
</section>
<style>
.logo-carousel-container {
    position: relative;
    width: 100%;
    margin: 0 auto;
  }
  
  .logo-carousel {
    width: max-content;
  }
  
  @keyframes scroll {
    0% {
      transform: translateX(0);
    }
    100% {
      transform: translateX(calc(-40px * 24)); /* Adjust based on logo width and count */
    }
  }
  
  .animate-scroll {
    animation: scroll 60s linear infinite;
  }
  
  .paused {
    animation-play-state: paused;
  }
  
  .logo-item {
    transition: all 0.3s ease;
  }
  
  .logo-item:hover {
    z-index: 20;
  }
  
  /* Responsive adjustments */
  @media (max-width: 640px) {
    .logo-item {
      width: 120px;
      height: 60px;
    }
    
    @keyframes scroll {
      0% {
        transform: translateX(0);
      }
      100% {
        transform: translateX(calc(-120px * 24)); /* Adjust for mobile */
      }
    }
  }
  </style> 
<script>

document.addEventListener('DOMContentLoaded', function() {
    const carousel = document.querySelector('.logo-carousel');
    const pauseButton = document.getElementById('pauseButton');
    const pauseText = pauseButton.querySelector('.pause-text');
    const playText = pauseButton.querySelector('.play-text');
    
    pauseButton.addEventListener('click', function() {
      carousel.classList.toggle('paused');
      pauseText.classList.toggle('hidden');
      playText.classList.toggle('hidden');
    });
    
    // Pause on hover (optional)
    carousel.addEventListener('mouseenter', function() {
      carousel.classList.add('paused');
    });
    
    carousel.addEventListener('mouseleave', function() {
      if (!playText.classList.contains('hidden')) return; // Don't resume if manually paused
      carousel.classList.remove('paused');
    });
    
    // Handle broken image URLs
    const images = document.querySelectorAll('.logo-item img');
    images.forEach(img => {
      img.addEventListener('error', function() {
        // Create a text-based fallback for broken image URLs
        const companyName = this.alt;
        this.onerror = null;
        this.src = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="160" height="80" viewBox="0 0 160 80"><rect width="100%" height="100%" fill="%23f8f9fa"></rect><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="14" fill="%23495057">${companyName}</text></svg>`;
      });
    });
  });
  



    document.addEventListener('DOMContentLoaded', function() {
  // Get all filter buttons and gallery items
  const filterButtons = document.querySelectorAll('.filter-button');
  const galleryItems = document.querySelectorAll('.gallery-item');

  // Add click event listener to each filter button
  filterButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Remove active class from all buttons
      filterButtons.forEach(btn => {
        btn.classList.remove('bg-red-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-800');
      });
      
      // Add active class to clicked button
      this.classList.remove('bg-gray-100', 'text-gray-800');
      this.classList.add('bg-red-600', 'text-white');
      
      // Get the filter value from data attribute
      const filterValue = this.getAttribute('data-filter');
      
      // Show or hide gallery items based on filter value
      galleryItems.forEach(item => {
        // If filter is 'all' or item has the filter class, show it
        if (filterValue === 'all' || item.classList.contains(filterValue)) {
          item.style.display = 'block';
          
          // Add animation for smooth appearance
          setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'scale(1)';
          }, 50);
        } else {
          // Hide items that don't match the filter
          item.style.opacity = '0';
          item.style.transform = 'scale(0.8)';
          
          // After animation completes, set display to none
          setTimeout(() => {
            item.style.display = 'none';
          }, 300);
        }
      });
    });
  });

  // Set "All" as default active filter on page load
  document.querySelector('[data-filter="all"]').click();
});

</script>


















    <!-- FAQ Section -->
    <section id="faq" class="py-16 bg-gray-100">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">คำถามที่พบบ่อย</h2>
            
            <div class="max-w-3xl mx-auto space-y-6">
                <!-- FAQ Item 1 -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <button class="faq-toggle w-full flex justify-between items-center p-6 focus:outline-none" onclick="toggleFAQ(this)" aria-expanded="false" aria-controls="faq-content-1">
                        <span class="font-semibold text-lg">เครื่องพ่นปูนฉาบ RB-M30L ใช้กับปูนแบบไหนได้บ้าง?</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary faq-icon transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="faq-content-1" class="faq-content px-6 pb-6 hidden">
                        <p class="text-gray-700">เครื่องพ่นปูนฉาบ RB-M30L สามารถใช้ได้กับปูนฉาบทั่วไป ปูนฉาบสำเร็จรูป และปูนฉาบแต่งผิวบาง โดยสามารถปรับความหนืดได้ตามความเหมาะสมของงาน ทำให้สามารถใช้งานได้หลากหลายรูปแบบ</p>
                    </div>
                </div>
                
                <!-- FAQ Item 2 -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <button class="faq-toggle w-full flex justify-between items-center p-6 focus:outline-none" onclick="toggleFAQ(this)" aria-expanded="false" aria-controls="faq-content-2">
                        <span class="font-semibold text-lg">เครื่องหนักไหม ย้ายสะดวกหรือไม่?</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary faq-icon transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="faq-content-2" class="faq-content px-6 pb-6 hidden">
                        <p class="text-gray-700">เครื่องมีน้ำหนัก 120 กิโลกรัม แต่มีล้อสำหรับเคลื่อนย้ายที่ออกแบบมาเป็นพิเศษ ทำให้สามารถเคลื่อนย้ายได้สะดวก แม้ในพื้นที่ก่อสร้าง นอกจากนี้ยังสามารถถอดแยกชิ้นส่วนได้เพื่อความสะดวกในการขนย้ายขึ้นที่สูง</p>
                    </div>
                </div>
                
                <!-- FAQ Item 3 -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <button class="faq-toggle w-full flex justify-between items-center p-6 focus:outline-none" onclick="toggleFAQ(this)" aria-expanded="false" aria-controls="faq-content-3">
                        <span class="font-semibold text-lg">ถ้าเครื่องมีปัญหา มีอะไหล่หรือบริการหลังการขายหรือไม่?</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary faq-icon transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="faq-content-3" class="faq-content px-6 pb-6 hidden">
                        <p class="text-gray-700">RUBYSHOP มีศูนย์บริการและจำหน่ายอะไหล่ทั่วประเทศ พร้อมทีมช่างผู้เชี่ยวชาญที่พร้อมให้คำปรึกษาและแก้ไขปัญหา โดยรับประกันเครื่อง 1 ปีเต็ม และมีอะไหล่สำรองพร้อมให้บริการตลอด 5 ปี</p>
                    </div>
                </div>
                
                <!-- FAQ Item 4 -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <button class="faq-toggle w-full flex justify-between items-center p-6 focus:outline-none" onclick="toggleFAQ(this)" aria-expanded="false" aria-controls="faq-content-4">
                        <span class="font-semibold text-lg">ต้องมีทักษะพิเศษในการใช้งานหรือไม่?</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary faq-icon transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="faq-content-4" class="faq-content px-6 pb-6 hidden">
                        <p class="text-gray-700">ไม่จำเป็นต้องมีทักษะพิเศษ เครื่องถูกออกแบบมาให้ใช้งานง่าย มีคู่มือภาษาไทยอย่างละเอียด และเรามีวิดีโอสอนการใช้งานให้ดูฟรี นอกจากนี้ยังมีการอบรมการใช้งานฟรีสำหรับลูกค้าที่ซื้อเครื่อง</p>
                    </div>
                </div>
                
                <!-- FAQ Item 5 -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <button class="faq-toggle w-full flex justify-between items-center p-6 focus:outline-none" onclick="toggleFAQ(this)" aria-expanded="false" aria-controls="faq-content-5">
                        <span class="font-semibold text-lg">ใช้ไฟฟ้าเท่าไร คุ้มค่ากับการใช้งานหรือไม่?</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary faq-icon transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div id="faq-content-5" class="faq-content px-6 pb-6 hidden">
                        <p class="text-gray-700">เครื่องใช้ไฟฟ้า 4000W (5.5HP) แต่ด้วยประสิทธิภาพการทำงานที่เร็วกว่าแรงงานคน 5 เท่า ทำให้ประหยัดค่าใช้จ่ายในระยะยาว โดยเฉลี่ยแล้ว การใช้เครื่องพ่นปูนฉาบ RB-M30L จะคืนทุนภายในโครงการแรกที่ใช้งาน</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

   





















   
   
   
   
   


    <!-- Buy Now Section -->
    <section id="buy-now" class="py-16 bg-gray-900 text-white relative">
        <div class="absolute top-0 left-0 w-full h-full bg-ruby opacity-10"></div>
        <div class="container mx-auto px-4 relative z-10">
            <div class="max-w-4xl mx-auto bg-white text-gray-800 rounded-2xl shadow-2xl overflow-hidden">
                <div class="p-8 md:p-12">
                    <div class="text-center mb-8">
                        <span class="inline-block bg-ruby text-white px-4 py-1 rounded-full text-sm font-bold mb-4">ข้อเสนอพิเศษ! ลดราคา 10%</span>
                        <h2 class="text-4xl md:text-5xl font-extrabold mb-4">เครื่องพ่นปูนฉาบ <span class="text-ruby">RUBYSHOP</span></h2>
                        <p class="text-xl text-gray-600">พร้อมอุปกรณ์ครบชุดและของแถมมูลค่า 3,500 บาท</p>
                    </div>

                    <div class="flex flex-col md:flex-row justify-center items-center mb-8">
                        <div class="text-center md:text-right md:pr-8 md:border-r md:border-gray-300">
                            <span class="block text-gray-500 line-through text-2xl">ราคาปกติ ฿99,000</span>
                            <span class="block text-ruby font-extrabold text-5xl">฿89,900</span>
                            <span class="text-green-600 font-bold">ประหยัด ฿10,000 (10%)</span>
                        </div>
                        <div class="mt-6 md:mt-0 md:pl-8 text-center md:text-left">
                            <div class="flex items-center justify-center md:justify-start mb-2">
                                <i class="fas fa-truck text-green-600 mr-2"></i>
                                <span class="font-medium">จัดส่งทั่วประเทศ</span>
                            </div>
                            <div class="flex items-center justify-center md:justify-start mb-2">
                                <i class="fas fa-shield-alt text-green-600 mr-2"></i>
                                <span class="font-medium">รับประกัน 1 ปีเต็ม</span>
                            </div>
                            <!-- <div class="flex items-center justify-center md:justify-start">
                                <i class="fas fa-sync-alt text-green-600 mr-2"></i>
                                <span class="font-medium">คืนสินค้าได้ใน 30 วัน</span>
                            </div> -->
                        </div>
                    </div>

                    <div class="bg-gray-100 p-6 rounded-xl mb-8">
                        <div class="flex items-center justify-between mb-4">
                            <span class="font-bold">เหลือเพียง <span id="remaining-items-bottom" class="text-ruby">2</span> เครื่องเท่านั้น!</span>
                            <div class="flex items-center">
                                <span class="mr-2">เวลาที่เหลือ:</span>
                                <div id="countdown-bottom" class="countdown-box bg-ruby">05:00:00</div>
                            </div>
                        </div>
                        <div class="w-full bg-gray-300 rounded-full h-3">
                            <div class="bg-ruby h-3 rounded-full" style="width: 80%"></div>
                        </div>
                    </div>

                    <div class="mb-8">
                        <label for="quantity" class="block font-bold mb-2">จำนวน:</label>
                        <div class="flex">
                            <button id="decrease" class="bg-gray-200 px-4 py-2 rounded-l-lg">-</button>
                            <input type="number" id="quantity" value="1" min="1" class="w-16 text-center border-t border-b border-gray-300">
                            <button id="increase" class="bg-gray-200 px-4 py-2 rounded-r-lg">+</button>
                        </div>
                    </div>

                    <div class="flex flex-col space-y-4">
                       <button  class="cta-button bg-ruby hover:bg-ruby-dark text-white font-bold py-4 px-8 rounded-lg text-xl text-center glow shake">
                            <a href="#contact">สั่งซื้อเลย - ลด 10% วันนี้เท่านั้น!</a>
                        </button>
                        <button  class="bg-gray-800 hover:bg-gray-700 text-white font-bold py-4 px-8 rounded-lg text-xl text-center">
                        <a href="https://www.rubyshop.co.th/products/rubyshop-rb-m30l-30-1">เพิ่มลงตะกร้า</a>
                        </button>
                    </div>

                    <div class="mt-6 text-center text-gray-600 text-sm">
                        <p>เมื่อคลิก "สั่งซื้อเลย" หรือ "เพิ่มลงตะกร้า" ถือว่าท่านยอมรับ <a href="https://www.rubyshop.co.th/cookie-policy" class="text-ruby underline">เงื่อนไขและข้อตกลง</a> ของเรา</p>
                    </div>

                    <div class="mt-8 flex justify-center space-x-4">
                        <img src="https://cdn-icons-png.flaticon.com/512/196/196578.png" alt="Visa" class="h-8">
                        <img src="https://cdn-icons-png.flaticon.com/512/196/196561.png" alt="MasterCard" class="h-8">
                        <img src="https://cdn-icons-png.flaticon.com/512/5968/5968299.png" alt="PayPal" class="h-8">
                 
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="py-16 bg-ruby">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center text-white">
                <h2 class="text-4xl md:text-5xl font-extrabold mb-6">อย่าพลาดโอกาสสุดท้าย!</h2>
                <p class="text-xl mb-8">รับส่วนลด 10% พร้อมของแถมมูลค่า 3,500 บาท เฉพาะวันนี้เท่านั้น!</p>
                <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                    <a href="#contact" class="cta-button bg-white text-ruby hover:bg-gray-100 font-bold py-4 px-8 rounded-lg text-xl text-center">
                        สั่งซื้อเลย - ลด 10% วันนี้เท่านั้น!
                    </a>
                    <a href="#contact" class="bg-transparent border-2 border-white text-white font-bold py-4 px-8 rounded-lg text-xl text-center hover:bg-white hover:text-ruby transition">
                        ติดต่อเรา
                    </a>
                </div>
                <div class="mt-8 flex justify-center space-x-6">
                    <a href="https://www.facebook.com/rubyshopcoth" class="text-white hover:text-gray-200 transition">
                        <i class="fab fa-facebook-f text-2xl"></i>
                    </a>
                    <a href="https://www.instagram.com/rubyshop_168/" class="text-white hover:text-gray-200 transition">
                        <i class="fab fa-line text-2xl"></i>
                    </a>
                    <a href="https://page.line.me/rubyshop168?openQrModal=true" class="text-white hover:text-gray-200 transition">
                        <i class="fab fa-instagram text-2xl"></i>
                    </a>
                    <a href="https://www.youtube.com/@rubyshoppowertoolsthailand8941" class="text-white hover:text-gray-200 transition">
                        <i class="fab fa-youtube text-2xl"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>






       <!-- Locations Section -->
       <section id="locations" class="py-16 bg-light-gray">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center text-primary-blue mb-4">จุดจำหน่ายและศูนย์บริการ</h2>
            <p class="text-center text-gray-600 mb-12 max-w-3xl mx-auto">RUBYSHOP จัดจำหน่ายและบริการจัดส่งทั่วประเทศ เพื่อให้คุณสามารถเข้าถึงสินค้าและบริการของเราได้อย่างสะดวก</p>
            
            <div class="flex flex-col md:flex-row mb-12">
                <div class="md:w-1/2 mb-8 md:mb-0">
                    <div class="bg-white p-6 rounded-lg shadow-md h-full">
                        <h3 class="text-xl font-semibold mb-4 text-primary-blue">สำนักงานใหญ่</h3>
                        <div class="space-y-4">
                            <div class="flex items-start">
                                <i class="fas fa-map-marker-alt text-primary-blue mt-1 mr-3"></i>
                                <a href="https://maps.app.goo.gl/j61AcMSir21ZsMMD8"><p class=" hover:underline pointer">หมู่4 97/60 โกสุมรวมใจ ซ. 39 แขวงดอนเมือง ดอนเมือง กรุงเทพมหานคร 10210</p></a>

                            </div>
                            <div class="flex items-start">
                                <i class="fas fas fa-phone-alt text-primary-blue mt-1 mr-3"></i>
                                <a href="tel:0896667802"><p class=" hover:underline pointer">089-666-7802</p></a>
                            </div>
                         
                            <div class="flex items-start">
                                <i class="fas fa-envelope text-primary-blue mt-1 mr-3"></i>
                                <a href="mailto:saleruby.benjavan@gmail.com"><p class=" hover:underline pointer">info@rubyshop.co.th</p></a>
                            </div>
                            <div class="flex items-start">
                                <i class="fas fa-clock text-primary-blue mt-1 mr-3"></i>
                                <p>เปิดทำการ: จันทร์-เสาร์ 08:30-17:30 น.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="md:w-1/2 md:pl-8">
                    <div class="bg-white p-6 rounded-lg shadow-md h-full">
                        <h3 class="text-xl font-semibold mb-4 text-primary-blue">ศูนย์บริการซ่อมบำรุง</h3>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="border-b border-gray-200 pb-3">
                                <h4 class="font-medium">กรุงเทพมหานคร ฯ </h4>
                                <p class="text-sm text-gray-600">1 สาขา</p>
                            </div>
                      
                        </div>
                        <div class="mt-4">
                
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Map -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d265.0367494374583!2d100.57427880173434!3d13.910647748453929!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e28301fbf17fbd%3A0x806362f26ffe576f!2z4Lir4LiI4LiBLuC4o-C4ueC4muC4teC5ieC4iuC5iuC4reC4mw!5e0!3m2!1sth!2sth!4v1743047312116!5m2!1sth!2sth" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </section>

   

  














<div class="flex flex-col md:flex-row pl-8 pr-8" id="contact">
    <div class="md:w-1/2 mb-8 md:mb-0 md:pr-8">
        <div class="bg-light-gray p-6 rounded-lg shadow-md">
            <h3 class="text-xl font-semibold mb-6">{{ __('ส่งข้อความถึงเรา') }}</h3>
            
            {!! Form::open(['route' => 'public.send.contact', 'class' => 'contact-form', 'method' => 'POST', 'id' => 'contactFormForContact']) !!}
                {!! apply_filters('pre_contact_form', null) !!}
                
                <div class="mb-4">
                    <label for="name" class="block text-gray-700 font-medium mb-2">{{ __('ชื่อ-นามสกุล') }} *</label>
                    <input type="text" id="name" name="name" value="{{ old('name') }}" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue" required>
                </div>
                
                <div class="mb-4">
                    <label for="phone" class="block text-gray-700 font-medium mb-2">{{ __('เบอร์โทรศัพท์') }} *</label>
                    <input type="tel" id="phone" name="phone" value="{{ old('phone') }}" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue" required>
                </div>
                
                <div class="mb-4">
                    <label for="email" class="block text-gray-700 font-medium mb-2">{{ __('อีเมล') }}</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue">
                </div>
                
                <div class="mb-4">
                    <label for="subject" class="block text-gray-700 font-medium mb-2">{{ __('เรื่องที่ต้องการติดต่อ') }} *</label>
                    <select id="subject" name="subject" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue" required>
                        <option value="">{{ __('กรุณาเลือก') }}</option>
                        <option value="สอบถามข้อมูลสินค้า" {{ old('subject') == 'สอบถามข้อมูลสินค้า' ? 'selected' : '' }}>{{ __('สอบถามข้อมูลสินค้า') }}</option>
                        <option value="ขอใบเสนอราคา" {{ old('subject') == 'ขอใบเสนอราคา' ? 'selected' : '' }}>{{ __('ขอใบเสนอราคา') }}</option>
                        <option value="บริการหลังการขาย" {{ old('subject') == 'บริการหลังการขาย' ? 'selected' : '' }}>{{ __('บริการหลังการขาย') }}</option>
                        <option value="อื่นๆ" {{ old('subject') == 'อื่นๆ' ? 'selected' : '' }}>{{ __('อื่นๆ') }}</option>
                    </select>
                </div>
                
                <div class="mb-6">
                    <label for="content" class="block text-gray-700 font-medium mb-2">{{ __('ข้อความ') }} *</label>
                    <textarea id="content" name="content" rows="5" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-red" required>{{ old('content') }}</textarea>
                </div>

                {!! apply_filters('after_contact_form', null) !!}

                <div class="hidden">
                    <input name="address" value="{{ old('address') }}" type="text">
                    {!! apply_filters('form_extra_fields_render', null, \Botble\Contact\Forms\Fronts\ContactForm::class) !!}
                </div>

                <!-- Success and Error Messages -->
                <div id="contactSuccessAlertForContact" class="contact-message contact-success-message hidden mb-4 p-4 text-sm text-green-700 bg-green-100 rounded-lg">
                    {{ __('ขอบคุณสำหรับข้อความของคุณ เราจะติดต่อกลับโดยเร็วที่สุด') }}
                </div>
                <div class="contact-message contact-error-message hidden mb-4 p-4 text-sm text-red-700 bg-red-100 rounded-lg"></div>

                <button type="submit" class="bg-ruby text-white font-medium py-3 px-6 rounded-md shadow-md hover:bg-green-600 transition w-full">
                    <i class="fas fa-paper-plane mr-2"></i>{{ __('ส่งข้อความ') }}
                </button>
            {!! Form::close() !!}
        </div>
    </div>
    
  

    <div class="md:w-1/2 pl-8">
        
    
    
                    <div class="bg-light-gray p-6 rounded-lg shadow-md mb-8 mr-10 pr-10">
                        <h3 class="text-xl font-semibold mb-4">ช่องทางการติดต่อ</h3>
                        <div class="space-y-4">
                            <div class="flex items-start">
                                <i class="fas fa-headset text-primary-blue text-xl mt-1 mr-4"></i>
                                <div>
                                    <h4 class="font-medium">ฝ่ายขายและบริการลูกค้า</h4>
                                    <p class="text-gray-600 hover:underline">089-666-7802</p>
                                    <a href="mailto:saleruby.benjavan@gmail.com"><p class="text-gray-600 hover:underline">saleruby.benjavan@gmail.com</p></a>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <i class="fas fa-tools text-primary-blue text-xl mt-1 mr-4"></i>
                                <div>
                                    <h4 class="font-medium">ฝ่ายบริการซ่อมบำรุง</h4>
                                    <a href="tel:0896667802"><p class="text-gray-600 hover:underline">089-666-7802</p></a>
                                    <a href="mailto:saleruby.benjavan@gmail.com hover:underline"><p class="text-gray-600 hover:underline">service@rubyshop.co.th</p></a>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <i class="fas fa-building text-primary-blue text-xl mt-1 mr-4"></i>
                                <div>
                                    <h4 class="font-medium">สำนักงานใหญ่</h4>
                                    <a href="https://maps.app.goo.gl/j61AcMSir21ZsMMD8"><p class="text-gray-600 hover:underline pointer">หมู่4 97/60 โกสุมรวมใจ ซ. 39 แขวงดอนเมือง ดอนเมือง กรุงเทพมหานคร 10210</p></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-light-gray p-6 rounded-lg shadow-md">
                        <h3 class="text-xl font-semibold mb-4">ติดตามเรา</h3>
                        <div class="flex space-x-4">
                            <a href="https://www.facebook.com/rubyshopcoth" class="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-700 transition">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.youtube.com/@rubyshoppowertoolsthailand8941" class="bg-red-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-red-700 transition">
                                <i class="fab fa-youtube"></i>
                            </a>
                            <a href="https://page.line.me/rubyshop168?openQrModal=true" class="bg-green-500 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-green-600 transition">
                                <i class="fab fa-line"></i>
                            </a>
                            <a href="https://x.com/RUBYSHOP168" class="bg-blue-400 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-500 transition">
                                <i class="fab fa-twitter"></i>
                            </a>
                        </div>
                        
                        <div class="mt-6">
                            <a href="https://page.line.me/rubyshop168?openQrModal=true"><h4 class="font-medium mb-3">LINE Official Account</h4>
                            <img src="https://res.cloudinary.com/dhcsqglul/image/upload/v1743047922/rubyshop168_line-QRCODE_r5lknp.png" alt="LINE QR Code" class="w-32 h-32"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>















    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle form submission with AJAX
        const contactForm = document.getElementById('contactFormForContact');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const submitBtn = this.querySelector('button[type="submit"]');
                const successMessage = document.querySelector('.contact-success-message');
                const errorMessage = document.querySelector('.contact-error-message');
                
                // Convert FormData to JSON object
                const formDataObj = {};
                formData.forEach((value, key) => {
                    formDataObj[key] = value;
                });
                
                // Add timestamp and additional metadata
                formDataObj.timestamp = new Date().toISOString();
                formDataObj.source = 'promotion1_page';
                formDataObj.user_agent = navigator.userAgent;
                formDataObj.page_url = window.location.href;
                
                // Add loading state to button
                const originalBtnText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>{{ __("กำลังส่ง...") }}';
                
                // Send to both original Laravel route and webhook
                Promise.all([
                    // Original Laravel submission
                    fetch(this.action, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    }),
                    // Webhook submission
                    fetch('{{ config("app.webhook_url", "https://ecommerce.karinssk.com/webhook") }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Webhook-Source': 'rubyshop-contact-form'
                        },
                        body: JSON.stringify(formDataObj)
                    })
                ])
                .then(async ([laravelResponse, webhookResponse]) => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                    
                    const laravelData = await laravelResponse.json();
                    
                    if (laravelData.error) {
                        errorMessage.innerHTML = laravelData.message;
                        errorMessage.classList.remove('hidden');
                        successMessage.classList.add('hidden');
                    } else {
                        successMessage.classList.remove('hidden');
                        errorMessage.classList.add('hidden');
                        contactForm.reset();
                        
                        // Scroll to success message
                        successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        
                        // Log webhook status (optional)
                        if (webhookResponse.ok) {
                            console.log('Webhook sent successfully');
                        } else {
                            console.warn('Webhook failed but form submitted successfully');
                        }
                    }
                })
                .catch(error => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                    
                    // Try webhook only if Laravel submission fails
                    fetch('{{ config("app.webhook_url", "https://ecommerce.karinssk.com/webhook") }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Webhook-Source': 'rubyshop-contact-form-fallback'
                        },
                        body: JSON.stringify({
                            ...formDataObj,
                            error_fallback: true,
                            original_error: error.message
                        })
                    })
                    .then(() => {
                        successMessage.classList.remove('hidden');
                        errorMessage.classList.add('hidden');
                        contactForm.reset();
                    })
                    .catch(() => {
                        errorMessage.innerHTML = '{{ __("เกิดข้อผิดพลาด โปรดลองอีกครั้ง") }}';
                        errorMessage.classList.remove('hidden');
                        successMessage.classList.add('hidden');
                    });
                });
            });
        }
    });
</script>






<!-- 
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle form submission with AJAX
        const contactForm = document.getElementById('contactFormForContact');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const submitBtn = this.querySelector('button[type="submit"]');
                const successMessage = document.querySelector('.contact-success-message');
                const errorMessage = document.querySelector('.contact-error-message');
                
                // Add loading state to button
                const originalBtnText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>{{ __("กำลังส่ง...") }}';
                
                fetch(this.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                    
                    if (data.error) {
                        errorMessage.innerHTML = data.message;
                        errorMessage.classList.remove('hidden');
                        successMessage.classList.add('hidden');
                    } else {
                        successMessage.classList.remove('hidden');
                        errorMessage.classList.add('hidden');
                        contactForm.reset();
                        
                        // Scroll to success message
                        successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                })
                .catch(error => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                    errorMessage.innerHTML = '{{ __("เกิดข้อผิดพลาด โปรดลองอีกครั้ง") }}';
                    errorMessage.classList.remove('hidden');
                    successMessage.classList.add('hidden');
                });
            });
        }
    });
</script> -->

















    

    <!-- Footer -->
    <footer class="bg-gray-900 text-white pt-16 pb-8">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                <div>
                    <img src="https://www.rubyshop.co.th/storage/logo/rubyshop-no-bg-white.png" alt="RUBYSHOP Logo" class="h-12 mb-6">
                    <p class="text-gray-400 mb-6">
                        RUBYSHOP ผู้นำเข้าและจัดจำหน่ายอุปกรณ์ก่อสร้างคุณภาพสูง มุ่งมั่นนำเสนอนวัตกรรมและเทคโนโลยีล่าสุดเพื่อตอบสนองความต้องการของลูกค้า
                    </p>
                    <div class="flex space-x-4">
                        <a href="https://www.facebook.com/rubyshopcoth" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://page.line.me/rubyshop168?openQrModal=true" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-line"></i>
                        </a>
                        <a href="https://www.instagram.com/rubyshop_168/" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="https://www.youtube.com/channel/UCxiaZiIC8qs2C228jwIjcHg" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-6">เมนูหลัก</h4>
                    <ul class="space-y-3">
                        <li>
                            <a href="#hero" class="text-gray-400 hover:text-white transition-colors">หน้าแรก</a>
                        </li>
                        <li>
                            <a href="#features" class="text-gray-400 hover:text-white transition-colors">คุณสมบัติ</a>
                        </li>
                      
                        <li>
                            <a href="#testimonials" class="text-gray-400 hover:text-white transition-colors">รีวิวจากลูกค้า</a>
                        </li>
                        <li>
                            <a href="#contact" class="text-gray-400 hover:text-white transition-colors">ติดต่อเรา</a>
                        </li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-6">ผลิตภัณฑ์อื่นๆ</h4>
                    <ul class="space-y-3">
                        <li>
                            <a href="https://www.rubyshop.co.th/products/rubyshop-rb-32-3000-rebar-bending-machine"" class="text-gray-400 hover:text-white transition-colors">เครื่องตัดเหล็ก</a>
                        </li>
                        <li>
                            <a href="https://www.rubyshop.co.th/product-categories/airless-sprayer-professional" class="text-gray-400 hover:text-white transition-colors">เครื่องพ่นสี</a>
                        </li>
                        <li>
                            <a href="https://www.rubyshop.co.th/products?layout=product-full-width&categories%5B%5D=70&page=2" class="text-gray-400 hover:text-white transition-colors">อุปกรณ์เสริม</a>
                        </li>
                        <li>
                            <a href="https://www.rubyshop.co.th/products?layout=product-full-width&categories%5B%5D=70&page=1" class="text-gray-400 hover:text-white transition-colors">อะไหล่</a>
                        </li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-6">ติดต่อเรา</h4>
                    <ul class="space-y-3">
                        <li class="flex items-start">
                            <i class="fas fa-map-marker-alt mt-1 mr-3 text-red-500"></i>
                            <a 
                            class=" hover:text-white transition-colors hover:underline"
                            href="https://www.google.com/maps/place/%E0%B8%AB%E0%B8%88%E0%B8%81.%E0%B8%A3%E0%B8%B9%E0%B8%9A%E0%B8%B5%E0%B9%89%E0%B8%8A%E0%B9%8A%E0%B8%AD%E0%B8%9B/@13.9105948,100.5740356,20z/data=!4m6!3m5!1s0x30e28301fbf17fbd:0x806362f26ffe576f!8m2!3d13.9104803!4d100.5742382!16s%2Fg%2F12m9309nd?entry=ttu&g_ep=EgoyMDI1MDMyNC4wIKXMDSoASAFQAw%3D%3D">
                                <span class="text-gray-400">
97/60 โกสุมรวมใจ ซ. 39 แขวงดอนเมือง ดอนเมือง กรุงเทพมหานคร 10210</span>
                              </a>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-phone-alt mt-1 mr-3 text-red-500"></i>
                            <a 
                            class=" hover:text-white transition-colors hover:underline" 
                            href="tel:0896667802"><span class="text-gray-400">
                            089-666-7802</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-envelope mt-1 mr-3 text-red-500"></i>
                            <a 
                            class=" hover:text-white transition-colors hover:underline"
                            href="mailto:saleruby.benjavan@gmail.com"><span class="text-gray-400">info@rubyshop.co.th</span></a>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-clock mt-1 mr-3 text-red-500"></i>
                            <span class="text-gray-400">เปิดทำการ: จันทร์-เสาร์ 08:30-17:30 น.</span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-gray-800 text-center text-gray-400">
                <p class="mb-4">
                    &copy; 2025 RUBYSHOP. All rights reserved.
                </p>
                <div class="flex justify-center space-x-4 text-sm">
                    <a href="https://www.rubyshop.co.th/cookie-policy" class="hover:text-white transition-colors">นโยบายความเป็นส่วนตัว</a>
                    <span>|</span>
                    <a href="https://www.rubyshop.co.th/cookie-policy" class="hover:text-white transition-colors">เงื่อนไขการใช้บริการ</a>
                    <span>|</span>
                    <a href="https://www.rubyshop.co.th/cookie-policy" class="hover:text-white transition-colors">นโยบายการคืนสินค้า</a>
                </div>
            </div>
        </div>
    </footer>




    <!-- JavaScript -->
    <script>
        // FAQ Accordion
        document.querySelectorAll('.faq-button').forEach(button => {
            button.addEventListener('click', () => {
                const answer = button.nextElementSibling;
                const icon = button.querySelector('i');
                
                if (answer.classList.contains('hidden')) {
                    answer.classList.remove('hidden');
                    icon.style.transform = 'rotate(180deg)';
                } else {
                    answer.classList.add('hidden');
                    icon.style.transform = 'rotate(0)';
                }
            });
        });

        // Quantity Selector
        const quantityInput = document.getElementById('quantity');
        document.getElementById('decrease').addEventListener('click', () => {
            if (quantityInput.value > 1) {
                quantityInput.value = parseInt(quantityInput.value) - 1;
            }
        });
        document.getElementById('increase').addEventListener('click', () => {
            quantityInput.value = parseInt(quantityInput.value) + 1;
        });

        // Countdown Timer
        function updateCountdown() {
            const hoursElement = document.getElementById('hours');
            const minutesElement = document.getElementById('minutes');
            const secondsElement = document.getElementById('seconds');
            const countdownBottom = document.getElementById('countdown-bottom');
            
            let hours = parseInt(hoursElement.innerText);
            let minutes = parseInt(minutesElement.innerText);
            let seconds = parseInt(secondsElement.innerText);
            
            seconds--;
            
            if (seconds < 0) {
                seconds = 59;
                minutes--;
                
                if (minutes < 0) {
                    minutes = 59;
                    hours--;
                    
                    if (hours < 0) {
                        hours = 5;
                        minutes = 0;
                        seconds = 0;
                    }
                }
            }

            
            // Update the display
            hoursElement.innerText = hours.toString().padStart(2, '0');
            minutesElement.innerText = minutes.toString().padStart(2, '0');
            secondsElement.innerText = seconds.toString().padStart(2, '0');
            
            // Update bottom countdown
            countdownBottom.innerText = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        
        // Update countdown every second
        setInterval(updateCountdown, 1000);
        
        // Remaining Items Counter
        function updateRemainingItems() {
            const remainingItemsTop = document.getElementById('remaining-items');
            const remainingItemsBottom = document.getElementById('remaining-items-bottom');
            
            let currentItems = parseInt(remainingItemsTop.innerText);
            
            // Random chance to decrease remaining items
            if (Math.random() < 0.1 && currentItems > 1) {
                currentItems--;
                remainingItemsTop.innerText = currentItems;
                remainingItemsBottom.innerText = currentItems;
                
                // Show notification
                showNotification();
            }
        }
        
        // Check remaining items periodically
        setInterval(updateRemainingItems, 30000);
        
      
    </script>

    <style>
        /* Custom CSS */
        .bg-ruby {
            background-color: #ed1d24   ;
        }
        
        .bg-ruby-dark {
            background-color: #ed1d24   ;
        }
        
        .text-ruby {
            color: #ed1d24   ;
        }
        
        .border-ruby {
            border-color:#ed1d24   ;
        }
        
        .countdown-box {
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            color: white;
            font-weight: bold;
        }
        
        .cta-button {
            transition: all 0.3s ease;
        }
        
        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(229, 33, 79, 0.3);
        }
        
        .glow {
            animation: glow 2s infinite alternate;
        }
        
        @keyframes glow {
            from {
                box-shadow: 0 0 5px rgba(229, 33, 79, 0.5);
            }
            to {
                box-shadow: 0 0 20px rgba(229, 33, 79, 0.8);
            }
        }
        
        .shake {
            animation: shake 5s infinite;
            animation-delay: 3s;
        }
        
        @keyframes shake {
            0% { transform: translateX(0); }
            2% { transform: translateX(-3px); }
            4% { transform: translateX(3px); }
            6% { transform: translateX(-3px); }
            8% { transform: translateX(3px); }
            10% { transform: translateX(-3px); }
            12% { transform: translateX(0); }
            100% { transform: translateX(0); }
        }
        
        .animate-bounce-slow {
            animation: bounce 3s infinite;
        }
        
        @keyframes bounce {
            0%, 100% {
                transform: translateY(-5%);
                animation-timing-function: cubic-bezier(0.8, 0, 1, 1);
            }
            50% {
                transform: translateY(0);
                animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
            }
        }
        
        .notification-animation {
            animation: slideIn 0.5s forwards;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .fade-out {
            animation: fadeOut 0.5s forwards;
        }
        
        @keyframes fadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }
    </style>




   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    <!-- Back to Top Button -->
    <button id="back-to-top" class="fixed bottom-6 left-6 bg-ruby hover:bg-rubydark text-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition duration-300 opacity-0 invisible">
        <i class="fas fa-chevron-up"></i>
    </button>
    <!-- JavaScript -->
    <script>
        // Back to Top Button
        const backToTopButton = document.getElementById('back-to-top');
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopButton.classList.remove('opacity-0', 'invisible');
                backToTopButton.classList.add('opacity-100', 'visible');
            } else {
                backToTopButton.classList.remove('opacity-100', 'visible');
                backToTopButton.classList.add('opacity-0', 'invisible');
            }
        });
        
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
    <!-- JavaScript -->
    <script>
        // Countdown Timer
        function updateCountdown() {
            const endDate = new Date();
            endDate.setDate(endDate.getDate() + 3); // 3 days from now
            endDate.setHours(23, 59, 59, 0);
            
            const now = new Date().getTime();
            const distance = endDate - now;
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            document.getElementById("days").innerHTML = days.toString().padStart(2, '0');
            document.getElementById("hours").innerHTML = hours.toString().padStart(2, '0');
            document.getElementById("minutes").innerHTML = minutes.toString().padStart(2, '0');
            document.getElementById("seconds").innerHTML = seconds.toString().padStart(2, '0');
        }
        
        setInterval(updateCountdown, 1000);
        updateCountdown();
        
        // FAQ Toggle
        function toggleFAQ(element) {
            const content = element.nextElementSibling;
            const icon = element.querySelector('.faq-icon');
            const isExpanded = element.getAttribute('aria-expanded') === 'true';
            
            // Close all other FAQs
            document.querySelectorAll('.faq-toggle').forEach(toggle => {
                if (toggle !== element) {
                    toggle.setAttribute('aria-expanded', 'false');
                    toggle.nextElementSibling.classList.add('hidden');
                    toggle.querySelector('.faq-icon').style.transform = 'rotate(0)';
                }
            });
            
            // Toggle current FAQ
            if (isExpanded) {
                element.setAttribute('aria-expanded', 'false');
                content.classList.add('hidden');
                icon.style.transform = 'rotate(0)';
            } else {
                element.setAttribute('aria-expanded', 'true');
                content.classList.remove('hidden');
                icon.style.transform = 'rotate(180deg)';
            }
        }
        
        // Form Validation and Submission
        document.getElementById('order-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Basic form validation
            const name = document.getElementById('name').value.trim();
            const phone = document.getElementById('phone').value.trim();
            
            if (!name) {
                alert('กรุณากรอกชื่อ-นามสกุล');
                document.getElementById('name').focus();
                return;
            }
            
            if (!phone) {
                alert('กรุณากรอกเบอร์โทรศัพท์');
                document.getElementById('phone').focus();
                return;
            }
            
            // Phone number validation (Thai format)
            const phoneRegex = /^[0-9]{9,10}$/;
            if (!phoneRegex.test(phone)) {
                alert('กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง (9-10 หลัก)');
                document.getElementById('phone').focus();
                return;
            }
            
            // Email validation if provided
            const email = document.getElementById('email').value.trim();
            if (email) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    alert('กรุณากรอกอีเมลให้ถูกต้อง');
                    document.getElementById('email').focus();
                    return;
                }
            }
            
            // If all validations pass, show success message
            alert('ขอบคุณสำหรับการสั่งซื้อ! ทีมงานของเราจะติดต่อกลับโดยเร็วที่สุด');
            this.reset();
            
            // Here you would typically send the form data to a server
            // using fetch or XMLHttpRequest
        });
        
        // Smooth Scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    // Add offset for fixed header
                    const headerOffset = 80;
                    const elementPosition = targetElement.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                    
                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                    
                    // Update URL hash without jumping
                    history.pushState(null, null, targetId);
                }
            });
        });
        
        // Mobile menu toggle (for smaller screens)
        function toggleMobileMenu() {
            const mobileMenu = document.getElementById('mobile-menu');
            if (mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.remove('hidden');
            } else {
                mobileMenu.classList.add('hidden');
            }
        }
        
        // Add mobile menu functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Create mobile menu button if it doesn't exist
            if (!document.getElementById('mobile-menu-button')) {
                const header = document.querySelector('header .container');
                const mobileButton = document.createElement('button');
                mobileButton.id = 'mobile-menu-button';
                mobileButton.className = 'md:hidden text-gray-700 focus:outline-none';
                mobileButton.setAttribute('aria-label', 'Toggle menu');
                mobileButton.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                `;
                mobileButton.onclick = toggleMobileMenu;
                
                // Create mobile menu
                const mobileMenu = document.createElement('div');
                mobileMenu.id = 'mobile-menu';
                mobileMenu.className = 'md:hidden bg-white w-full py-2 px-4 mt-2 shadow-md rounded-b-lg hidden absolute left-0 right-0 z-50';
                
                // Clone navigation links
                const navLinks = document.querySelector('header .md\\:flex').cloneNode(true);
                navLinks.className = 'flex flex-col space-y-3 py-3';
                mobileMenu.appendChild(navLinks);
                
                // Insert elements
                header.appendChild(mobileButton);
                header.parentNode.insertBefore(mobileMenu, header.nextSibling);
            }
        });
        
        // Lazy loading for images
        document.addEventListener('DOMContentLoaded', function() {
            const lazyImages = [].slice.call(document.querySelectorAll('img[data-src]'));
            
            if ('IntersectionObserver' in window) {
                const lazyImageObserver = new IntersectionObserver(function(entries, observer) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            const lazyImage = entry.target;
                            lazyImage.src = lazyImage.dataset.src;
                            lazyImage.removeAttribute('data-src');
                            lazyImageObserver.unobserve(lazyImage);
                        }
                    });
                });
                
                lazyImages.forEach(function(lazyImage) {
                    lazyImageObserver.observe(lazyImage);
                });
            } else {
                // Fallback for browsers without IntersectionObserver support
                lazyImages.forEach(function(lazyImage) {
                    lazyImage.src = lazyImage.dataset.src;
                    lazyImage.removeAttribute('data-src');
                });
            }
        });
    </script>
  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-WSR5H4YBF2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-WSR5H4YBF2');
</script>
<!-- Messenger Float Button -->
<a href="https://m.me/816184855086392" target="_blank" rel="noopener noreferrer" id="messenger-float-btn" title="Chat with us on Messenger" style="position:fixed;bottom:24px;right:24px;width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#0695FF,#A334FA,#FF6968);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.25);z-index:9998;text-decoration:none;transition:transform 0.3s,box-shadow 0.3s;">
    <svg width="32" height="32" viewBox="0 0 36 36" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M18 3C9.716 3 3 9.146 3 16.5c0 4.243 2.117 8.025 5.42 10.504V33l5.783-3.175c1.217.338 2.508.525 3.797.525 8.284 0 15-6.146 15-13.5S26.284 3 18 3zm1.488 18.182l-3.822-4.08-7.46 4.08 8.2-8.707 3.915 4.08 7.367-4.08-8.2 8.707z"/></svg>
</a>
</body>
</html>

