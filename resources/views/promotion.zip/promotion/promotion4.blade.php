<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
     <title>เครื่องพ่นสีแรงดันสูง RB-899 - พ่นสีเนียน ประสิทธิภาพสูง | RUBYSHOP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="เครื่องพ่นสีแรงดันสูง RB899 - พ่นสีเนียน ประสิทธิภาพสูง | RUBYSHOP">
    <meta name="description" content="เครื่องพ่นสีแรงดันสูง RB899 ให้แรงพ่นสีสม่ำเสมอ ประหยัดเวลา ใช้งานง่าย เหมาะสำหรับงานพ่นสีทุกประเภท สั่งซื้อได้ที่ RUBYSHOP วันนี้!">
    <meta name="keywords" content="เครื่องพ่นสี, เครื่องพ่นสีแรงดันสูง, RB899, พ่นสีไฟฟ้า, พ่นสีกำแพง, พ่นสีบ้าน, RUBYSHOP,พ่นสี ,airless">
    <meta name="author" content="RUBYSHOP">
    <meta name="robots" content="index, follow">
    <script src="https://analytics.ahrefs.com/analytics.js" data-key="+yln8X9wf8523X4GDZmCqA" async></script>
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="product">
    <meta property="og:title" content="เครื่องพ่นสีแรงดันสูง RB899 - พ่นสีเนียน ประสิทธิภาพสูง | RUBYSHOP">
    <meta property="og:description" content="เครื่องพ่นสีแรงดันสูง RB899 ให้แรงพ่นสีสม่ำเสมอ ประหยัดเวลา ใช้งานง่าย เหมาะสำหรับงานพ่นสีทุกประเภท สั่งซื้อได้ที่ RUBYSHOP วันนี้!">
    <meta property="og:image" content="https://www.rubyshop.com/images/rb899.jpg">
    <meta property="og:url" content="https://www.rubyshop.com/products/rb899">
    <meta property="og:site_name" content="RUBYSHOP">
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="เครื่องพ่นสีแรงดันสูง RB899 - พ่นสีเนียน ประสิทธิภาพสูง | RUBYSHOP">
    <meta name="twitter:description" content="เครื่องพ่นสีแรงดันสูง RB899 ให้แรงพ่นสีสม่ำเสมอ ประหยัดเวลา ใช้งานง่าย เหมาะสำหรับงานพ่นสีทุกประเภท สั่งซื้อได้ที่ RUBYSHOP วันนี้!">
    <meta name="twitter:image" content="https://www.rubyshop.com/images/rb899.jpg">
    <meta name="twitter:site" content="@rubyshop">
    
   
    
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0PWGSWH0P4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-0PWGSWH0P4');
</script>




<link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-NHBT4DYH7D"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-NHBT4DYH7D');
</script>


    <!-- Canonical URL -->
    <link rel="canonical" href="https://www.example.com/rb899">
    
    <!-- Preload Critical Resources -->
    <link rel="preload" href="fonts/thaisans-neue.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="images/rb899-hero.webp" as="image">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Custom CSS -->








    <style>
    * {
        font-family: 'Prompt', sans-serif;
    }
        
        .lazy-image {
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .lazy-image.loaded {
            opacity: 1;
        }
        
        /* Improve CLS */
        .hero-image-container {
            aspect-ratio: 16/9;
        }
        
        /* Smooth scroll */
        html {
            scroll-behavior: smooth;
        }
    </style>
    
    <!-- Structured Data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": "เครื่องพ่นสีแรงดันสูง RB899",
        "image": "https://www.example.com/images/rb899-main.jpg",
        "description": "เครื่องพ่นสีแรงดันสูง RB899 ออกแบบสำหรับมืออาชีพ ให้ความแม่นยำและประสิทธิภาพสูงสุดในการพ่นสี",
        "brand": {
            "@type": "Brand",
            "name": "RUBYSHOP"
        },
        "offers": {
            "@type": "Offer",
            "url": "https://www.example.com/rb899",
            "priceCurrency": "THB",
            "price": "12900",
            "priceValidUntil": "2024-12-31",
            "availability": "https://schema.org/InStock",
            "seller": {
                "@type": "Organization",
                "name": "RUBYSHOP"
            }
        },
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "127"
        }
    }
    </script>
</head>
<body class="bg-gray-50 text-gray-800">
  <!-- Header -->
<!-- Header -->
<header class="bg-white shadow-md sticky top-0 z-50">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <!-- Logo -->
        <a href="/"><div class="flex items-center">
        <img src="https://www.rubyshop.co.th/storage/logo/new-logo.png" alt="RUBYSHOP Logo" class="h-12"></a>
        </div>
        
        <!-- Desktop Navigation -->
        <nav class="hidden lg:flex space-x-2 xl:space-x-6">
            <a href="#features" class="font-medium text-sm xl:text-base px-2 py-1 hover:text-red-600 hover:bg-red-50 rounded transition duration-200">จุดเด่น</a>
            <a href="#specs" class="font-medium text-sm xl:text-base px-2 py-1 hover:text-red-600 hover:bg-red-50 rounded transition duration-200">สเปค</a>
            <a href="#use-cases" class="font-medium text-sm xl:text-base px-2 py-1 hover:text-red-600 hover:bg-red-50 rounded transition duration-200">ข้อดี</a>
            <a href="#testimonials" class="font-medium text-sm xl:text-base px-2 py-1 hover:text-red-600 hover:bg-red-50 rounded transition duration-200">รีวิว</a>
            <a href="#faq" class="font-medium text-sm xl:text-base px-2 py-1 hover:text-red-600 hover:bg-red-50 rounded transition duration-200">คำถามที่พบบ่อย</a>
        </nav>
        
        <!-- CTA Button -->
        <div class="flex items-center">
            <a href="#contact" class="bg-red-600 text-white px-3 sm:px-4 py-2 text-sm sm:text-base rounded-lg font-medium hover:bg-red-700 transition shadow-sm hover:shadow">สั่งซื้อเลย</a>
            
            <!-- Mobile Menu Button -->
            <button 
                class="lg:hidden ml-4 text-gray-500 hover:text-red-600 focus:outline-none focus:text-red-600 transition" 
                id="mobile-menu-button"
                aria-label="เปิดเมนู"
            >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
        </div>
    </div>
    
    <!-- Mobile Menu -->
    <div class="lg:hidden hidden bg-white border-t border-gray-100 shadow-inner" id="mobile-menu">
        <div class="container mx-auto px-4 py-2">
            <a href="/" class="block py-3 px-4 font-medium border-b border-gray-100 hover:bg-red-50 hover:text-red-600 transition">หน้าหลัก</a>
            <a href="#features" class="block py-3 px-4 font-medium border-b border-gray-100 hover:bg-red-50 hover:text-red-600 transition">จุดเด่น</a>
            <a href="#specs" class="block py-3 px-4 font-medium border-b border-gray-100 hover:bg-red-50 hover:text-red-600 transition">สเปค</a>
            <a href="#benefits" class="block py-3 px-4 font-medium border-b border-gray-100 hover:bg-red-50 hover:text-red-600 transition">ข้อดี</a>
            <a href="#testimonials" class="block py-3 px-4 font-medium border-b border-gray-100 hover:bg-red-50 hover:text-red-600 transition">รีวิว</a>
            <a href="#faq" class="block py-3 px-4 font-medium hover:bg-red-50 hover:text-red-600 transition">คำถามที่พบบ่อย</a>
        </div>
    </div>
</header>

<!-- Separate JavaScript file for Mobile Menu Toggle -->
<script>
    // Wait for the DOM to be fully loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Get the menu button and mobile menu elements
        const menuButton = document.getElementById('mobile-menu-button');
        const mobileMenu = document.getElementById('mobile-menu');
        
        // Make sure both elements exist
        if (menuButton && mobileMenu) {
            // Add click event listener to the menu button
            menuButton.addEventListener('click', function() {
                // Toggle the 'hidden' class on the mobile menu
                mobileMenu.classList.toggle('hidden');
                
                // Check if the menu is now visible
                const isMenuVisible = !mobileMenu.classList.contains('hidden');
                
                // Update the button's aria-expanded attribute
                menuButton.setAttribute('aria-expanded', isMenuVisible ? 'true' : 'false');
                
                // Change the button icon based on menu state
                if (isMenuVisible) {
                    // X icon when menu is open
                    menuButton.innerHTML = `
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    `;
                } else {
                    // Hamburger icon when menu is closed
                    menuButton.innerHTML = `
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    `;
                }
            });
            
            // Close mobile menu when clicking on a menu item
            const menuLinks = mobileMenu.querySelectorAll('a');
            menuLinks.forEach(link => {
                link.addEventListener('click', function() {
                    mobileMenu.classList.add('hidden');
                    menuButton.setAttribute('aria-expanded', 'false');
                    menuButton.innerHTML = `
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    `;
                });
            });
        }
    });
</script>



    <main>
     <!-- Hero Section -->
<section class="bg-gradient-to-r from-red-600 to-red-800 text-black py-12 md:py-20 lg:py-24">
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row items-center gap-8 lg:gap-12">
            <div class="md:w-1/2 mb-8 md:mb-0">
                <h1 class="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 leading-tight">เครื่องพ่นสีแรงดันสูง RB899</h1>
                <h2 class="text-xl sm:text-2xl md:text-3xl font-semibold mb-4 md:mb-6">นวัตกรรมการพ่นสีระดับมืออาชีพ</h2>
                <p class="text-base md:text-lg mb-6 md:mb-8 max-w-xl">เครื่องพ่นสีประสิทธิภาพสูง ออกแบบมาสำหรับมืออาชีพที่ต้องการความแม่นยำและคุณภาพงานที่เหนือชั้น ด้วยเทคโนโลยีล่าสุดที่ช่วยให้การพ่นสีเรียบเนียนสม่ำเสมอ</p>
                
                <div class="flex flex-col sm:flex-row gap-4">
                    <a href="#contact" class="bg-white hover:bg-gray-100 text-gray-900 font-bold py-3 px-6 md:px-8 rounded-lg text-center transition transform hover:scale-105 shadow-md">
                        สั่งซื้อเลย | ฿39,900
                    </a>
                    <a href="#video-demo" class="bbg-white hover:bg-gray-100 text-gray-900 py-3 px-6 md:px-8 rounded-lg text-center flex items-center justify-center gap-2 transition transform hover:scale-105 shadow-md">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd" />
                        </svg>
                        ดูวิดีโอสาธิต
                    </a>
                </div>
            </div>
            
            <div class="md:w-1/2 hero-image-container">
                <img
                    src="https://res.cloudinary.com/dhcsqglul/image/upload/v1742870620/01._%E0%B8%9E%E0%B9%88%E0%B8%99%E0%B8%AA%E0%B8%B5899_hjnbgv.webp"
                    alt="เครื่องพ่นสีแรงดันสูง RB899"
                    class="w-full h-auto rounded-lg shadow-xl mx-auto max-w-md lg:max-w-lg"
                    width="600"
                    height="400"
                    loading="eager"
                >
            </div>
        </div>
    </div>
</section>

<!-- Trust Badges -->
<section class="bg-white py-6 md:py-8">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 justify-items-center">
            <div class="flex items-center bg-gray-50 px-4 py-3 rounded-lg w-full max-w-xs justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-600 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
                <span class="text-sm md:text-base">รับประกัน 1 ปี</span>
            </div>
            
            <div class="flex items-center bg-gray-50 px-4 py-3 rounded-lg w-full max-w-xs justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-600 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
                </svg>
                <span class="text-sm md:text-base">จัดส่งฟรีทั่วประเทศ</span>
            </div>
            
            
            
            <div class="flex items-center bg-gray-50 px-4 py-3 rounded-lg w-full max-w-xs justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-600 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                <span class="text-sm md:text-base">สินค้าของแท้ 100%</span>
            </div>
        </div>
    </div>
</section>


        <!-- Features Section -->
        <section id="features" class="py-16 bg-gray-50">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">จุดเด่นของเครื่องพ่นสี RB899</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                        <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-center mb-3">แรงดันสูงถึง 300 bar</h3>
                        <p class="text-gray-600 text-center">แรงดันสูงช่วยให้พ่นสีได้เรียบเนียนและครอบคลุมพื้นที่ได้มากกว่า ลดเวลาการทำงานได้ถึง 40%</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                        <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-center mb-3">ระบบปั๊มโลหะทนทาน</h3>
                        <p class="text-gray-600 text-center">มอบความคงทนและยืดอายุการใช้งาน</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                        <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-center mb-3">ประหยัดเวลาถึง 50%</h3>
                        <p class="text-gray-600 text-center">ทำงานได้เร็วกว่าเครื่องพ่นสีทั่วไปถึง 50% ด้วยอัตราการพ่นสีที่สูงถึง 0.8 ลิตรต่อนาที</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
                <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
    <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
        <!-- Paint/Color compatibility icon -->
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
        </svg>
    </div>
    <h3 class="text-xl font-semibold text-center mb-3">รองรับการพ่นทุกประเภทสี</h3>
    <p class="text-gray-600 text-center">ทั้งน้ำ น้ำมัน และสารละลายต่างๆ</p>
</div>

<div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
    <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
        <!-- Spray nozzle/tip icon -->
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-4.9-6H5.95a1 1 0 01-.8-.4l-.975-1.3A3 3 0 012 9.5V9a3 3 0 013-3h.1L8 7.5 7.5 6.9A1.998 1.998 0 016 5h-.5a2 2 0 01-2-2c0-1.1.9-2 2-2H9a2 2 0 012 2v.5" />
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11v.01M16 14v.01M19 14v.01M15 17v.01M16 20v.01M19 20v.01" />
        </svg>
    </div>
    <h3 class="text-xl font-semibold text-center mb-3">มีตัวเลือกขนาดหัวพ่นให้เลือกตามความเหมาะสม</h3>
    <p class="text-gray-600 text-center">ขนาดหัวทิปสูงสุดคือ 0.025"</p>
</div>

                    
                    <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition">
                        <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-center mb-3">มอเตอร์ประสิทธิภาพสูง</h3>
                        <p class="text-gray-600 text-center">มอเตอร์ไร้แปรงถ่าน 1,500W ทนทานต่อการใช้งานหนัก อายุการใช้งานยาวนานกว่า 5,000 ชั่วโมง</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="video-demo" class="py-16 bg-white">
    <div class="container mx-auto px-4">
        <h2 class="text-3xl md:text-4xl font-bold text-center mb-8">ชมการทำงานจริง</h2>
        <p class="text-lg text-center text-gray-600 mb-10 max-w-3xl mx-auto">ดูวิดีโอสาธิตการใช้งานเครื่องพ่นสี RB899 ในสถานการณ์จริง เพื่อให้เห็นประสิทธิภาพและความแม่นยำในการทำงาน</p>
        
        <div class="max-w-4xl mx-auto rounded-xl overflow-hidden shadow-xl">
            <!-- Video container with proper aspect ratio -->
            <div class="relative" style="padding-bottom: 56.25%;">
                <iframe 
                    class="absolute top-0 left-0 w-full h-full"
                    src="https://www.youtube.com/embed/QRgxhWQvfU8" 
                    title="เครื่องพ่นสีแรงดันสูง Airless Paint Sprayers RB899 พ่นงานอาคาร ที่สีลม" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                    referrerpolicy="strict-origin-when-cross-origin" 
                    allowfullscreen>
                </iframe>
            </div>
        </div>
    </div>
</section>

   


<!-- Use Cases Section -->
<section class="py-20 bg-white" id="use-cases">
    <div class="container mx-auto px-4">
        <h2 class="text-4xl font-bold text-center text-dark mb-12 relative after:content-[''] after:absolute after:bottom-[-10px] after:left-1/2 after:w-20 after:h-1 after:bg-primary after:transform after:translate-x-[-50%]">เหมาะสำหรับงาน </h2>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div class="text-center">
                <img src="https://res.cloudinary.com/dhcsqglul/image/upload/w_1000,ar_16:9,c_fill,g_auto,e_sharpen/v1742809301/DSC04841_iexf7c.webp" alt="งานพ่นสีกันสนิม เคลือบกันสนิมบนโครงเหล็กและเครื่องจักร" class="rounded-lg shadow-md mb-4 transition-transform hover:scale-105 w-full h-48 object-cover">
                <h3 class="text-xl font-semibold text-dark mb-2">งานพ่นสีกันสนิม</h3>
                <p class="text-gray-600">เหมาะสำหรับการทาสีผนังภายในบ้าน ห้องนอน ห้องนั่งเล่น</p>
            </div>
            
            <div class="text-center">
                <img src="https://res.cloudinary.com/dhcsqglul/image/upload/w_1000,ar_16:9,c_fill,g_auto,e_sharpen/v1742809300/DSC04902-2_s4vg50.webp" alt="ทาสีภายนอก" class="rounded-lg shadow-md mb-4 transition-transform hover:scale-105 w-full h-48 object-cover">
                <h3 class="text-xl font-semibold text-dark mb-2">งานพ่นสีสะพานและโครงสร้างขนาดใหญ่</h3>
                <p class="text-gray-600">ลดเวลาทำงานและให้การเคลือบสีที่สม่ำเสมอ</p>
            </div>
            
            <div class="text-center">
                <img src="https://res.cloudinary.com/dhcsqglul/image/upload/w_1000,ar_16:9,c_fill,g_auto,e_sharpen/v1742809300/DSC06576_bnr53b.webp" alt="งานพ่นสีเหล็กโครงสร้าง สำหรับงานก่อสร้างที่ใช้เหล็กเป็นส่วนประกอบหลัก" class="rounded-lg shadow-md mb-4 transition-transform hover:scale-105 w-full h-48 object-cover">
                <h3 class="text-xl font-semibold text-dark mb-2">งานพ่นสีเหล็กโครงสร้าง</h3>
                <p class="text-gray-600">สำหรับงานก่อสร้างที่ใช้เหล็กเป็นส่วนประกอบหลัก</p>
            </div>
            
            <div class="text-center">
                <img src="https://res.cloudinary.com/dhcsqglul/image/upload/w_1000,ar_16:9,c_fill,g_auto,e_sharpen/v1742809299/DSC07063-1_fc0rc5.webp" alt="งานช่างทั่วไป" class="rounded-lg shadow-md mb-4 transition-transform hover:scale-105 w-full h-48 object-cover">
                <h3 class="text-xl font-semibold text-dark mb-2">งานช่างทั่วไป</h3>
                <p class="text-gray-600">เหมาะสำหรับช่างทาสี รับเหมาก่อสร้าง และงานทาสีทั่วไป</p>
            </div>
        </div>
    </div>
</section>
















<section id="specs" class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">ข้อมูลจำเพาะ</h2>
        
        <div class="max-w-5xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-red-600 text-white">
                            <th class="py-3 px-4 text-left w-1/2">คุณสมบัติ</th>
                            <th class="py-3 px-4 text-center font-bold bg-red-700 w-1/2">
                                RB899 <br><span class="text-yellow-300">แนะนำ</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">กำลังมอเตอร์</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">1,500W</td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">แรงดันสูงสุด</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">300 bar</td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">อัตราการพ่นสี</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">0.8 ลิตร/นาที</td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">พ่นสีอะคริลิค</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">พ่นสีกันไฟ</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">พ่นสีน้ำมัน</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">พ่นสีน้ำ</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">พ่นสีอีพ็อกซี่</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">พ่นสีรูฟชีล</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">ความยาวสายฉีด</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">15 เมตร</td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">การรับประกัน</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">1 ปี</td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4 font-medium w-1/2">ราคา</td>
                            <td class="py-4 px-4 text-center font-medium text-red-600 w-1/2">฿39,900</td>
                        </tr>
                        <tr class="bg-gray-100">
                            <td class="py-4 px-4 font-medium w-1/2">ความคุ้มค่าโดยรวม</td>
                            <td class="py-4 px-4 text-center font-bold text-red-600 w-1/2">
                                <div class="flex justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                    </svg>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>



        <!-- Testimonials Section -->
        <section id="testimonials" class="py-16 bg-white">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">ลูกค้าของเราพูดถึงเรา</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    <div class="bg-gray-50 p-6 rounded-xl shadow-md">
                        <div class="flex items-center mb-4">
                            <div class="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center mr-4">
                                <span class="text-red-600 font-bold text-xl">ส</span>
                            </div>
                            <div>
                                <h4 class="font-semibold">สมชาย วงศ์ประดิษฐ์</h4>
                                <p class="text-sm text-gray-600">ช่างทาสีมืออาชีพ</p>
                            </div>
                        </div>
                        <div class="mb-4">
                            <div class="flex">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                            </div>
                        </div>
                        <p class="text-gray-600">"ผมใช้เครื่องพ่นสีมาหลายรุ่นแล้ว แต่ RB899 เป็นเครื่องที่ดีที่สุดที่เคยใช้มา แรงดันสูง ทำงานได้เร็ว และที่สำคัญคือพ่นได้เรียบเนียนมาก ลูกค้าชมว่างานเนี้ยบทุกครั้ง"</p>
                    </div>
                    
                    <div class="bg-gray-50 p-6 rounded-xl shadow-md">
                        <div class="flex items-center mb-4">
                            <div class="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center mr-4">
                                <span class="text-red-600 font-bold text-xl">ว</span>
                            </div>
                            <div>
                                <h4 class="font-semibold">วิชัย สุขสมบูรณ์</h4>
                                <p class="text-sm text-gray-600">เจ้าของบริษัทรับเหมาก่อสร้าง</p>
                            </div>
                        </div>
                        <div class="mb-4">
                            <div class="flex">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                            </div>
                        </div>
                        <p class="text-gray-600">"บริษัทของเราซื้อเครื่องพ่นสี RB899 มาใช้ในโครงการก่อสร้างหลายโครงการ ช่วยประหยัดเวลาและต้นทุนได้มาก ทำงานได้เร็วกว่าเดิม 3 เท่า คุ้มค่ากับการลงทุนมาก"</p>
                    </div>
                    
                    <div class="bg-gray-50 p-6 rounded-xl shadow-md">
                        <div class="flex items-center mb-4">
                            <div class="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center mr-4">
                                <span class="text-red-600 font-bold text-xl">น</span>
                            </div>
                            <div>
                                <h4 class="font-semibold">นภา จันทร์เจริญ</h4>
                                <p class="text-sm text-gray-600">เจ้าของร้านเฟอร์นิเจอร์</p>
                            </div>
                        </div>
                        <div class="mb-4">
                            <div class="flex">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                            </div>
                        </div>
                        <p class="text-gray-600">"เราใช้ RB899 ในการพ่นสีเฟอร์นิเจอร์ ผลลัพธ์ออกมาดีมาก ผิวเรียบเนียนสวย ไม่มีรอยแปรง ลูกค้าชอบมาก และที่สำคัญคือประหยัดสีได้เยอะเลย"</p>
                    </div>
                </div>
                
                <div class="mt-12 text-center">
                    <a href="#" class="inline-block bg-red-600 hover:bg-red-700 text-white font-medium py-3 px-6 rounded-lg transition duration-300">
                        ดูรีวิวทั้งหมด
                    </a>
                </div>
            </div>
        </section>

    <!-- FAQ Section -->
<section id="faq" class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">คำถามที่พบบ่อย</h2>
        
        <div class="max-w-3xl mx-auto space-y-6">
            <!-- FAQ Item 1 -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden faq-item">
                <button class="w-full px-6 py-4 text-left font-medium flex justify-between items-center focus:outline-none focus:bg-gray-50">
                    <span>เครื่องพ่นสี RB899 เหมาะกับงานประเภทใดบ้าง?</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 transform transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="px-6 pb-4 faq-content hidden">
                    <p class="text-gray-600">เครื่องพ่นสี RB899 เหมาะกับงานหลากหลายประเภท ทั้งงานทาสีอาคาร งานตกแต่งภายใน งานทาสีเฟอร์นิเจอร์ งานพ่นสีรถยนต์ งานเคลือบป้องกัน งานพ่นสีอุตสาหกรรม และงานพ่นสีเชิงพาณิชย์ ด้วยกำลังมอเตอร์ 1,800W และแรงดันสูงสุด 3,000 PSI ทำให้สามารถรองรับงานได้หลากหลายรูปแบบ</p>
                </div>
            </div>
            
            <!-- FAQ Item 2 -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden faq-item">
                <button class="w-full px-6 py-4 text-left font-medium flex justify-between items-center focus:outline-none focus:bg-gray-50">
                    <span>เครื่องพ่นสี RB899 ใช้งานยากหรือไม่?</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 transform transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="px-6 pb-4 faq-content hidden">
                    <p class="text-gray-600">เครื่องพ่นสี RB899 ออกแบบมาให้ใช้งานง่าย มีหน้าจอดิจิทัลที่แสดงค่าต่างๆ อย่างชัดเจน ระบบควบคุมแรงดันอัตโนมัติช่วยให้ผู้ใช้สามารถปรับแต่งได้ตามต้องการ มาพร้อมคู่มือการใช้งานภาษาไทยที่เข้าใจง่าย และมีวิดีโอสอนการใช้งานให้ดูฟรี ทำให้แม้ผู้ที่ไม่เคยใช้เครื่องพ่นสีมาก่อนก็สามารถใช้งานได้อย่างมีประสิทธิภาพ</p>
                </div>
            </div>
            
            <!-- FAQ Item 3 -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden faq-item">
                <button class="w-full px-6 py-4 text-left font-medium flex justify-between items-center focus:outline-none focus:bg-gray-50">
                    <span>เครื่องพ่นสี RB899 รองรับสีประเภทใดบ้าง?</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 transform transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="px-6 pb-4 faq-content hidden">
                    <p class="text-gray-600">เครื่องพ่นสี RB899 รองรับสีได้หลากหลายประเภท ทั้งสีน้ำ สีน้ำมัน สีอะคริลิค สีลาเท็กซ์ สีอีพ็อกซี่ สีโพลียูรีเทน และสีเคลือบเงาต่างๆ ด้วยระบบปรับแรงดันอัตโนมัติ ทำให้สามารถปรับให้เหมาะกับความหนืดของสีแต่ละประเภทได้อย่างแม่นยำ</p>
                </div>
            </div>
            
            <!-- FAQ Item 4 -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden faq-item">
                <button class="w-full px-6 py-4 text-left font-medium flex justify-between items-center focus:outline-none focus:bg-gray-50">
                    <span>การบำรุงรักษาเครื่องพ่นสี RB899 ทำอย่างไร?</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 transform transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="px-6 pb-4 faq-content hidden">
                    <p class="text-gray-600">การบำรุงรักษาเครื่องพ่นสี RB899 ทำได้ง่าย เพียงทำความสะอาดหัวฉีดและถังบรรจุสีหลังการใช้งานทุกครั้ง ตรวจสอบและเปลี่ยนไส้กรองตามระยะเวลาที่กำหนด หล่อลื่นชิ้นส่วนที่เคลื่อนไหวเป็นประจำ และเก็บในที่แห้งเมื่อไม่ได้ใช้งาน นอกจากนี้ยังมีชุดอะไหล่สำรองที่หาซื้อได้ง่าย และมีศูนย์บริการทั่วประเทศไทยพร้อมให้คำปรึกษาและบริการหลังการขาย</p>
                </div>
            </div>
            
            <!-- FAQ Item 5 -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden faq-item">
                <button class="w-full px-6 py-4 text-left font-medium flex justify-between items-center focus:outline-none focus:bg-gray-50">
                    <span>เครื่องพ่นสี RB899 มีการรับประกันอย่างไร?</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 transform transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="px-6 pb-4 faq-content hidden">
                    <p class="text-gray-600">เครื่องพ่นสี RB899 มีการรับประกันสินค้า 3 ปีเต็ม ครอบคลุมทั้งมอเตอร์และอะไหล่สำคัญ พร้อมบริการซ่อมฟรีในช่วงรับประกัน มีศูนย์บริการกระจายอยู่ทั่วประเทศไทย และมีทีมช่างผู้เชี่ยวชาญพร้อมให้คำปรึกษาตลอด 24 ชั่วโมง นอกจากนี้ยังมีบริการตรวจเช็คสภาพฟรี 1 ครั้งในช่วง 6 เดือนแรกหลังการซื้อ</p>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    // Improved FAQ Accordion
    document.addEventListener('DOMContentLoaded', function() {
        const faqItems = document.querySelectorAll('.faq-item');
        
        faqItems.forEach(item => {
            const button = item.querySelector('button');
            const content = item.querySelector('.faq-content');
            const icon = button.querySelector('svg');
            
            // Add click event to each FAQ button
            button.addEventListener('click', function() {
                // Toggle the current item
                content.classList.toggle('hidden');
                
                // Rotate the icon when expanded
                if (content.classList.contains('hidden')) {
                    icon.classList.remove('rotate-180');
                } else {
                    icon.classList.add('rotate-180');
                }
                
                // Optional: Close other items when opening a new one
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        const otherContent = otherItem.querySelector('.faq-content');
                        const otherIcon = otherItem.querySelector('svg');
                        
                        otherContent.classList.add('hidden');
                        otherIcon.classList.remove('rotate-180');
                    }
                });
            });
        });
    });
</script>

<!-- CTA Section -->
<!-- <section class="py-12 sm:py-16 md:py-20 bg-gradient-to-r from-red-700 to-red-600">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4 md:mb-6 leading-tight">
            พร้อมยกระดับงานพ่นสีของคุณแล้วหรือยัง?
        </h2>
        
        <p class="text-lg sm:text-xl text-red-100 mb-6 md:mb-8 max-w-3xl mx-auto leading-relaxed">
            สั่งซื้อเครื่องพ่นสี RB899 วันนี้ รับส่วนลดพิเศษ 15% พร้อมของแถมมูลค่ารวมกว่า 5,000 บาท
        </p>
        
        <div class="flex flex-col sm:flex-row justify-center gap-4 sm:gap-6 mb-6">
            <a href="#order" class="inline-block bg-yellow-500 hover:bg-yellow-400 text-red-900 font-bold py-3 sm:py-4 px-6 sm:px-8 rounded-lg transition duration-300 text-base sm:text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                สั่งซื้อตอนนี้ - ลด 15%
            </a>
            
            <a href="#contact" class="inline-block bg-white hover:bg-gray-100 text-red-600 font-bold py-3 sm:py-4 px-6 sm:px-8 rounded-lg transition duration-300 text-base sm:text-lg border-2 border-transparent hover:border-white">
                สอบถามข้อมูลเพิ่มเติม
            </a>
        </div>
        
        <div class="flex justify-center">
            <p class="text-red-200 text-sm sm:text-base px-4 py-2 bg-red-800 bg-opacity-30 rounded-full inline-block">
                * ข้อเสนอพิเศษมีระยะเวลาจำกัด สิ้นสุดวันที่ 31 เมษายน 2567
            </p>
        </div>
    </div>
</section> -->


        <!-- Order Section -->
        <!-- <section id="order" class="py-16 bg-white">
            <div class="container mx-auto px-4">
                <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">สั่งซื้อเครื่องพ่นสี RB899</h2>
                
                <div class="max-w-5xl mx-auto">
                    <div class="bg-gray-50 rounded-xl shadow-md overflow-hidden">
                        <div class="md:flex">
                            <div class="md:w-1/2 p-6 md:p-8">
                                <h3 class="text-2xl font-bold mb-4">ข้อมูลการสั่งซื้อ</h3>
                                
                                <form>
                                    <div class="mb-4">
                                        <label class="block text-gray-700 font-medium mb-2" for="name">ชื่อ-นามสกุล</label>
                                        <input type="text" id="name" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="block text-gray-700 font-medium mb-2" for="phone">เบอร์โทรศัพท์</label>
                                        <input type="tel" id="phone" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="block text-gray-700 font-medium mb-2" for="email">อีเมล</label>
                                        <input type="email" id="email" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="block text-gray-700 font-medium mb-2" for="address">ที่อยู่จัดส่ง</label>
                                        <textarea id="address" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required></textarea>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="block text-gray-700 font-medium mb-2">วิธีการชำระเงิน</label>
                                        <div class="space-y-2">
                                            <div class="flex items-center">
                                                <input type="radio" id="payment1" name="payment" class="mr-2" checked>
                                                <label for="payment1">โอนเงินผ่านธนาคาร</label>
                                            </div>
                                            <div class="flex items-center">
                                                <input type="radio" id="payment2" name="payment" class="mr-2">
                                                <label for="payment2">บัตรเครดิต/เดบิต</label>
                                            </div>
                                            <div class="flex items-center">
                                                <input type="radio" id="payment3" name="payment" class="mr-2">
                                                <label for="payment3">เก็บเงินปลายทาง (+3%)</label>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                                        ยืนยันการสั่งซื้อ
                                    </button>
                                </form>
                            </div>
                            <div class="md:w-1/2 bg-gray-100 p-6 md:p-8">
                                <h3 class="text-2xl font-bold mb-4">สรุปรายการสั่งซื้อ</h3>
                                
                                <div class="bg-white rounded-lg p-4 mb-4">
                                    <div class="flex items-center">
                                        <img src="https://www.rubyshop.co.th/storage/ads/70l/70l-9-1.webp" alt="เครื่องพ่นสี RB899" class="w-20 h-20 object-cover rounded mr-4">
                                        <div>
                                            <h4 class="font-bold">เครื่องพ่นสี RB899 </h4>
                                            <p class="text-gray-600">รุ่นล่าสุด 2025</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="space-y-3 mb-6">
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">ราคาสินค้า</span>
                                        <span>฿43,000</span>
                                    </div>
                                    <div class="flex justify-between text-green-600">
                                        <span>ส่วนลด 15%</span>
                                        <span>-฿4,900</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">ค่าจัดส่ง</span>
                                        <span>ฟรี</span>
                                    </div>
                                    <div class="border-t pt-3 flex justify-between font-bold">
                                        <span>ยอดรวมทั้งสิ้น</span>
                                        <span class="text-red-600 text-xl">฿39,000</span>
                                    </div>
                                </div>
                                
                                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                                    <h4 class="font-bold text-yellow-800 mb-2">ของแถมพิเศษ!</h4>
                                    <ul class="text-gray-700 space-y-2">
                                        <li class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                            </svg>
                                            หัวฉีดพิเศษสำหรับงานละเอียด มูลค่า 1,590 บาท
                                        </li>
                                        <li class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                            </svg>
                                            สายฉีดเสริมความยาว 5 เมตร มูลค่า 990 บาท
                                        </li>
                                        <li class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                            </svg>
                                            ชุดทำความสะอาดอุปกรณ์ มูลค่า 1,290 บาท
                                        </li>
                                        <li class="flex items-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                            </svg>
                                            คูปองส่วนลดซื้ออะไหล่ 20% มูลค่า 1,000 บาท
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->





 <!-- Contact Section -->
 <section id="contact" class="py-16 bg-gray-50">
  <div class="container mx-auto px-4">
    <h2 class="text-3xl md:text-4xl font-bold text-center mb-12">ติดต่อขอใบเสนอราคา</h2>
    <div class="max-w-5xl mx-auto">
      <div class="bg-white rounded-xl shadow-md overflow-hidden">
        <div class="md:flex">
          <div class="md:w-1/2 p-6 md:p-8">
            <h3 class="text-2xl font-bold mb-4">ส่งข้อความถึงเรา</h3>
            
           
            
            <form id="contactFormForContact">
              <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2" for="name">ชื่อ-นามสกุล</label>
                <input type="text" id="name" name="name" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
              </div>
              
              <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2" for="email">อีเมล</label>
                <input type="email" id="email" name="email" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
              </div>
              
              <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2" for="phone">โทรศัพท์</label>
                <input type="tel" id="phone" name="phone" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
              </div>
              
              <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2" for="product">หัวข้อ</label>
                <select id="product" name="product" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required>
                  <option value="">เลือกหัวข้อ</option>
                  <option value="sales">สอบถามข้อมูลสินค้า</option>
                  <option value="support">ขอรับบริการหลังการขาย</option>
                  <option value="warranty">เคลมประกัน</option>
                  <option value="other">อื่นๆ</option>
                </select>
              </div>
              
              <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2" for="message">ข้อความ</label>
                <textarea id="message" name="message" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500" required></textarea>
              </div>
               <!-- Success Alert (Hidden by default) -->
            <div id="contactSuccessAlertForContact" class="hidden mb-4 p-4 text-sm text-green-700 bg-green-100 rounded-lg">
              ขอบคุณสำหรับข้อความของคุณ เราจะติดต่อกลับโดยเร็วที่สุด
            </div>
              <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                ส่งข้อความ
              </button>
            </form>
          </div>
          

          <script>
// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Get the form element
  const contactForm = document.getElementById('contactFormForContact');
  
  // Check if the form exists
  if (!contactForm) {
    console.error("Contact form element not found!");
    return;
  }
  
  // Google Form mapping
  const googleFormURL = 'https://docs.google.com/forms/d/e/1FAIpQLScQ3LjJBELRFViTGhNwJ4YnekoT063jlEwa0gvIlVUfe_lQLQ/formResponse';
  const fieldMapping = {
    'name': 'entry.1303366296',
    'email': 'entry.680103493',
    'phone': 'entry.1516457013',
    'product': 'entry.1804196759',
    'message': 'entry.1925420914'
  };
  
  // Add submit handler
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Form validation
    let isValid = true;
    const requiredFields = contactForm.querySelectorAll('[required]');
    requiredFields.forEach(field => {
      if (!field.value.trim()) {
        isValid = false;
        field.classList.add('border-red-500');
        field.classList.add('bg-red-50');
      } else {
        field.classList.remove('border-red-500');
        field.classList.remove('bg-red-50');
      }
    });
    
    if (!isValid) {
      alert('กรุณากรอกข้อมูลให้ครบถ้วน');
      return;
    }
    
    // Get form values
    const formData = new FormData(contactForm);
    const formValues = {};
    for (const [key, value] of formData.entries()) {
      formValues[key] = value;
    }
    
    // Show loading state
    const submitButton = contactForm.querySelector('button[type="submit"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = '<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> กำลังส่ง...';
    submitButton.disabled = true;
    
    // Create hidden iframe for form submission
    const iframe = document.createElement('iframe');
    iframe.name = 'hidden_iframe';
    iframe.style.display = 'none';
    document.body.appendChild(iframe);
    
    // Create form for submission
    const hiddenForm = document.createElement('form');
    hiddenForm.method = 'POST';
    hiddenForm.action = googleFormURL;
    hiddenForm.target = 'hidden_iframe';
    

    const success = document.getElementById('contactSuccessAlertForContact');
    if (success) { 
      
      setTimeout(() => {
        success.classList.remove('hidden');;
      },2000);
    
      setTimeout(() => {
        success.classList.add('hidden');
      },6000);
    }

      
    // Add form fields
    for (const fieldId in fieldMapping) {
      if (formValues[fieldId]) {
        const input = document.createElement('input');
        input.type = 'text';
        input.name = fieldMapping[fieldId];
        input.value = formValues[fieldId];
        hiddenForm.appendChild(input);
      }
    }
    
    // Submit the form
    document.body.appendChild(hiddenForm);
    hiddenForm.submit();
    
    // Show success message
    setTimeout(() => {
      // Reset form
      contactForm.reset();
      
      // Show success alert
      const successAlert = document.getElementById('contactSuccessAlert');
      if (successAlert) {
        successAlert.classList.remove('hidden');
      }
      
      // Reset button
      submitButton.innerHTML = originalButtonText;
      submitButton.disabled = false;
      
      // Clean up
      document.body.removeChild(hiddenForm);
      document.body.removeChild(iframe);
      
      // Auto-hide success message after 5 seconds
      setTimeout(() => {
        const alert = document.getElementById('contactSuccessAlert');
        if (alert && !alert.classList.contains('hidden')) {
          alert.classList.add('hidden');
        }
      }, 5000);
    }, 1000);
  });
});
</script>



<div class="md:w-1/2 bg-gray-100 p-6 md:p-8">
                                <h3 class="text-2xl font-bold mb-4">ข้อมูลติดต่อ</h3>
                                
                                <div class="space-y-6">
                                    <div class="flex items-start">
                                      
                                       <div class="bg-red-100 rounded-full p-3 mr-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                            </svg>
                                        </div>
                                        <div>
                                        <a href="https://maps.app.goo.gl/PHN4FcxYn8fuRr22A" target="_blank" rel="noopener" class="hover:underline">
                                            <h4 class="font-bold text-gray-800">ที่อยู่</h4>
                                            <p class="text-gray-600">97/60 ม.4 หมู่บ้านหลักสี่แลนด์ ซอยโกสุมร่วมใจ 39 แขวงดอนเมือง เขตดอนเมือง กรุงเทพ 10210</p>
                                            </a>
                                        </div> 
                                      
                                    </div>
                                    
                                    <div class="flex items-start">
                                        <div class="bg-red-100 rounded-full p-3 mr-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                            </svg>
                                        </div>
                                        <div>
                                            <a href="tel:0896667802" class="hover:underline">
                                            <h4 class="font-bold text-gray-800">โทรศัพท์</h4>
                                            <p class="text-gray-600">089-666-7802</p>
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <div class="flex items-start">
                                        <div class="bg-red-100 rounded-full p-3 mr-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                            </svg>
                                        </div>
                                        <div>
                                        <a href="mailto:saleruby.benjavan@gmail.com" class="hover:underline">
                                            <h4 class="font-bold text-gray-800">อีเมล</h4>
                                            <p class="text-gray-600">saleruby.benjavan@gmail.com</p>
                                            <p class="text-gray-600">info@rubyshop.com</p>
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <div class="flex items-start">
                                        <div class="bg-red-100 rounded-full p-3 mr-4">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                        </div>
                                        <div>
                                        <h4 class="font-bold text-gray-800">เวลาทำการ</h4>
                                            <p class="text-gray-600">จันทร์ - ศุกร์: 8:30 - 17:30 น.</p>
                                            <p class="text-gray-600">เสาร์: 8:30 - 17:30 น.</p>
                                            <p class="text-gray-600">อาทิตย์: ปิดทำการ</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-8">
                                    <h4 class="font-bold text-gray-800 mb-3">ติดตามเรา</h4>
                                    <div class="flex space-x-4">
                                        <a href="https://www.facebook.com/rubyshopcoth" class="bg-red-600 text-white p-2 rounded-full hover:bg-red-700 transition duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                                            </svg>
                                        </a>
                                        <a href="https://x.com/RUBYSHOP168" class="bg-red-400 text-white p-2 rounded-full hover:bg-red-500 transition duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                                            </svg>
                                        </a>
                                        <a href="https://www.youtube.com/channel/UCxiaZiIC8qs2C228jwIjcHg" class="bg-red-600 text-white p-2 rounded-full hover:bg-red-700 transition duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z" />
                                            </svg>
                                        </a>
                                        <a href="https://www.instagram.com/rubyshop_168/" class="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-2 rounded-full hover:from-purple-600 hover:to-pink-600 transition duration-300">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                                            </svg>
                                        </a>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>





<!-- Footer Section -->
<footer class="bg-white border-t border-gray-200">
  <div class="container mx-auto px-4 py-8">
    <div class="text-center">
      <img 
        src="https://www.rubyshop.co.th/storage/logo/rubyshop-no-bg-250pxx100px.jpg" 
        alt="Rubyshop Logo" 
        class="h-12 mx-auto mb-6"
        width="150"
        height="60"
        loading="lazy"
      >
      
      <p class="text-gray-800 font-bold">COPYRIGHT © RUBYSHOP 2025</p>
      
      <p class="text-gray-700 mt-3 max-w-3xl mx-auto text-sm">
        เครื่องหมายการค้าต่อไปนี้เป็นของ เครื่องพ่นสีแรงดันสูง เครื่องผสมสี
        <br>เครื่องพ่นสีกันไฟ เครื่องพ่นปูนฉาบ เครื่องตีเส้นถนน เครื่องกรีดผนัง เครื่องปั่นหน้าปูนและอื่นๆ ของ RUBYSHOP:
        <br>โทนสีแดง-เทา และลวดลายบนพื้นผิวของเครื่องมือ หจก. รูบี้ช๊อป
      </p>
      
      <!-- Social Media Icons -->
      <div class="flex justify-center items-center mt-6 space-x-6">
        <a href="https://www.facebook.com/rubyshopcoth" target="_blank" aria-label="Facebook" class="text-gray-600 hover:text-blue-600 transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
          </svg>
        </a>
        
        <a href="https://www.instagram.com/rubyshop_168" target="_blank" aria-label="Instagram" class="text-gray-600 hover:text-pink-600 transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
          </svg>
        </a>
        
        <a href="https://www.youtube.com/channel/UCxiaZiIC8qs2C228jwIjcHg" target="_blank" aria-label="YouTube" class="text-gray-600 hover:text-red-600 transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
          </svg>
        </a>
        
        <a href="https://x.com/RUBYSHOP168" target="_blank" aria-label="Twitter" class="text-gray-600 hover:text-gray-900 transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
          </svg>
        </a>
      </div>
    </div>
  </div>
  
  <!-- Bottom Footer -->
  <div class="bg-black text-red-400 py-3">
    <div class="container mx-auto px-4">
      <div class="flex flex-wrap justify-center space-x-2 md:space-x-4 text-sm">
        <a href="https://www.rubyshop.co.th/contact" class="hover:underline whitespace-nowrap py-1">Accessibility Statement</a>
        <span class="hidden md:inline">|</span>
        <a href="https://www.rubyshop.co.th/privacy-policy" class="hover:underline whitespace-nowrap py-1">Privacy Policy</a>
        <span class="hidden md:inline">|</span>
        <a href="https://www.rubyshop.co.th/cookie-policy" class="hover:underline whitespace-nowrap py-1">Cookies</a>
        <span class="hidden md:inline">|</span>
        <a href="https://www.rubyshop.co.th/products" class="hover:underline whitespace-nowrap py-1">Power Tools Institute</a>
        <span class="hidden md:inline">|</span>
        <a href="https://www.rubyshop.co.th/products" class="hover:underline whitespace-nowrap py-1">Shop</a>
      </div>
    </div>
  </div>
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-WSR5H4YBF2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-WSR5H4YBF2');
</script>
</footer>

<!-- Back to Top Button -->
<button id="backToTop" class="fixed bottom-4 right-4 p-3 bg-red-500 text-white rounded-full shadow-lg hover:bg-red-600 transition duration-300 transform scale-100 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-red-400" style="display:none;" aria-label="Back to top">
  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7" />
  </svg>
</button>











    </main>

   



<!-- Load non-critical CSS and JS -->
<script>
// Load non-critical CSS
const loadStylesheet = (src) => {
    const link = document.createElement('link');
    link.href = src;
    link.rel = 'stylesheet';
    document.head.appendChild(link);
};

// Use requestIdleCallback or setTimeout as fallback
const onIdle = window.requestIdleCallback || 
    function(cb) {
        const start = Date.now();
        return setTimeout(function() {
            cb({
                didTimeout: false,
                timeRemaining: function() {
                    return Math.max(0, 50 - (Date.now() - start));
                }
            });
        }, 1);
    };

// Load non-critical CSS when browser is idle
onIdle(() => {
    // Load your output.css file
    loadStylesheet('{{ url("css/output.css") }}');
});
</script>

    <script>
 
</script>

<!-- Messenger Float Button -->
<a href="https://m.me/816184855086392" target="_blank" rel="noopener noreferrer" id="messenger-float-btn" title="Chat with us on Messenger" style="position:fixed;bottom:24px;right:24px;width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#0695FF,#A334FA,#FF6968);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.25);z-index:9998;text-decoration:none;transition:transform 0.3s,box-shadow 0.3s;">
    <svg width="32" height="32" viewBox="0 0 36 36" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M18 3C9.716 3 3 9.146 3 16.5c0 4.243 2.117 8.025 5.42 10.504V33l5.783-3.175c1.217.338 2.508.525 3.797.525 8.284 0 15-6.146 15-13.5S26.284 3 18 3zm1.488 18.182l-3.822-4.08-7.46 4.08 8.2-8.707 3.915 4.08 7.367-4.08-8.2 8.707z"/></svg>
</a>
</body>
</html>







